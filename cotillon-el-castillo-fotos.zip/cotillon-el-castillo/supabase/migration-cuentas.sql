-- =====================================================================
-- Migración: Cuentas de clientes (registro / login en la tienda)
-- =====================================================================
-- Es aditiva: no borra nada. Supabase → SQL Editor → New query → pegar → Run.
-- Corré esto ANTES de publicar los cambios, si no el registro va a fallar.
-- =====================================================================

create table if not exists customer_accounts (
  id text primary key,
  name text not null,
  email text not null unique,
  phone text not null,
  password_hash text not null,
  created_at timestamptz not null default now()
);

-- Cada pedido puede quedar asociado a la cuenta que lo hizo (los pedidos
-- de invitados siguen funcionando y quedan con customer_id en null).
alter table orders
  add column if not exists customer_id text references customer_accounts(id) on delete set null;
create index if not exists orders_customer_id_idx on orders (customer_id);

-- Contiene hashes de contraseña: sin policy pública, solo se accede con la
-- service role key desde server actions (igual que admin_users).
alter table customer_accounts enable row level security;
