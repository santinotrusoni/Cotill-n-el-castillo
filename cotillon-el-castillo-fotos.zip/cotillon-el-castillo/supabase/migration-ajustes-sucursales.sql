-- =====================================================================
-- Migración: Sucursales + Ajustes generales
-- =====================================================================
-- Es aditiva: correr esto no toca nada de lo que ya tenías. Supabase →
-- tu proyecto → SQL Editor → New query → pegar → Run.
-- =====================================================================

create table if not exists branches (
  id text primary key,
  name text not null,
  address text not null,
  phone text,
  hours text,
  active boolean not null default true
);

-- Fila única (siempre id = 'default') con los datos generales del negocio
-- que hoy se muestran en el footer, /contacto y los links de WhatsApp.
create table if not exists site_settings (
  id text primary key default 'default',
  store_name text not null default 'Cotillón El Castillo',
  whatsapp_number text not null default '5491100000000',
  contact_email text not null default 'hola@elcastillocotillon.com.ar',
  address text not null default 'Villa Dominico, Buenos Aires, Argentina',
  hours text not null default 'Lun a Sáb de 9 a 19 h'
);

insert into site_settings (id) values ('default')
  on conflict (id) do nothing;

alter table branches enable row level security;
create policy "Lectura pública de sucursales" on branches for select using (true);

-- site_settings NO tiene policy pública de lectura: no hace falta, porque
-- el footer y /contacto son Server Components que siempre leen con la
-- service role key (nunca desde el navegador) — mismo criterio que
-- price_history o price_rules.
alter table site_settings enable row level security;
