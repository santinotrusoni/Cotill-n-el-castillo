-- =====================================================================
-- Migración: Pedidos (checkout real)
-- =====================================================================
-- Ya corriste supabase/schema.sql antes, así que correspondería correr
-- SOLO esto (es aditivo, no toca nada de lo que ya existe).
-- Supabase → tu proyecto → SQL Editor → New query → pegar → Run.
-- =====================================================================

create table if not exists orders (
  id text primary key,
  order_number bigint generated always as identity,
  customer_name text not null,
  customer_phone text not null,
  delivery_method text not null default 'retiro',
  address text,
  payment_method text not null default 'efectivo',
  notes text,
  items jsonb not null default '[]',
  subtotal numeric not null default 0,
  discount numeric not null default 0,
  total numeric not null default 0,
  status text not null default 'pendiente',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists orders_status_idx on orders (status);
create index if not exists orders_created_at_idx on orders (created_at desc);

-- Los pedidos tienen datos personales del cliente (nombre, teléfono) y no
-- hace falta leerlos desde el navegador: tanto el checkout público (crea
-- el pedido) como el admin (lo lee/actualiza) pasan siempre por server
-- actions con la service role key, que ignora RLS. Por eso no hace falta
-- ninguna policy de lectura pública acá — igual que price_history y
-- price_rules.
alter table orders enable row level security;
