-- Crea la categoría "Halloween" (slug: halloween). Es segura de correr más de una vez.
insert into categories (id, name, slug, description, image)
values (
  'cat-halloween',
  'Halloween',
  'halloween',
  'Disfraces, decoración y todo para tu fiesta de Halloween.',
  'https://placehold.co/600x600/DBCED0/2FAECD?text=Halloween&font=roboto'
)
on conflict (slug) do nothing;
