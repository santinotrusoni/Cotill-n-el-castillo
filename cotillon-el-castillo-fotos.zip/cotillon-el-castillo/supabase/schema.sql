-- =====================================================================
-- Cotillón El Castillo — schema de Supabase
-- =====================================================================
-- Correlo UNA VEZ en el SQL Editor de tu proyecto de Supabase
-- (Supabase → tu proyecto → SQL Editor → New query → pegar → Run).
-- Después corré seed.sql para cargar los datos de muestra.
--
-- Los IDs son texto (no uuid) a propósito: son los mismos IDs legibles
-- que ya usaba la app en memoria ("prod-001", "cat-cotillon", etc.),
-- así no hay que tocar ninguna lógica de la UI.
-- =====================================================================

create table if not exists categories (
  id text primary key,
  name text not null,
  slug text not null unique,
  description text not null default '',
  image text not null default ''
);

create table if not exists brands (
  id text primary key,
  name text not null,
  slug text not null unique
);

create table if not exists products (
  id text primary key,
  sku text not null,
  barcode text not null unique,
  slug text not null unique,
  name text not null,
  short_description text not null default '',
  description text not null default '',
  features text[] not null default '{}',
  category_id text not null references categories(id),
  brand_id text not null references brands(id),
  price numeric not null,
  previous_price numeric,
  cost numeric,
  stock integer not null default 0,
  min_stock integer not null default 0,
  status text not null default 'activo',
  featured boolean not null default false,
  is_new boolean not null default false,
  on_offer boolean not null default false,
  images text[] not null default '{}',
  tags text[] not null default '{}',
  attribute_values jsonb not null default '[]',
  created_at timestamptz not null default now()
);

create index if not exists products_category_id_idx on products (category_id);
create index if not exists products_brand_id_idx on products (brand_id);
create index if not exists products_barcode_idx on products (barcode);

create table if not exists price_history (
  id text primary key,
  date timestamptz not null default now(),
  "user" text not null default 'Administrador',
  type text not null,
  value numeric not null,
  rounding integer not null default 0,
  rule_name text,
  affected_product_ids text[] not null default '{}',
  previous_prices jsonb not null default '{}',
  reverted boolean not null default false
);

create table if not exists price_rules (
  id text primary key,
  name text not null,
  category_id text references categories(id),
  brand_id text references brands(id),
  type text not null,
  value numeric not null,
  rounding integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  last_applied_at timestamptz
);

create table if not exists admin_activity (
  id text primary key,
  message text not null,
  date timestamptz not null default now(),
  type text not null
);

create index if not exists admin_activity_date_idx on admin_activity (date desc);

create table if not exists orders (
  id text primary key,
  order_number bigint generated always as identity,
  customer_name text not null,
  customer_phone text not null,
  delivery_method text not null default 'retiro',
  address text,
  payment_method text not null default 'efectivo',
  notes text,
  items jsonb not null default '[]',
  subtotal numeric not null default 0,
  discount numeric not null default 0,
  total numeric not null default 0,
  status text not null default 'pendiente',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists orders_status_idx on orders (status);
create index if not exists orders_created_at_idx on orders (created_at desc);

create table if not exists branches (
  id text primary key,
  name text not null,
  address text not null,
  phone text,
  hours text,
  active boolean not null default true
);

create table if not exists site_settings (
  id text primary key default 'default',
  store_name text not null default 'Cotillón El Castillo',
  whatsapp_number text not null default '5491100000000',
  contact_email text not null default 'hola@elcastillocotillon.com.ar',
  address text not null default 'Villa Dominico, Buenos Aires, Argentina',
  hours text not null default 'Lun a Sáb de 9 a 19 h'
);

insert into site_settings (id) values ('default')
  on conflict (id) do nothing;

-- =====================================================================
-- Row Level Security
-- =====================================================================
-- El panel /admin escribe siempre con la service role key (server-side,
-- nunca llega al navegador), así que ignora RLS por diseño — no hace
-- falta ninguna policy de escritura para que el admin funcione.
--
-- Solo dejamos lectura pública (anon key) de catálogo por si en algún
-- momento se quiere leer el catálogo desde el cliente sin pasar por un
-- Server Component. Si no vas a hacer eso, podés omitir este bloque.
alter table categories enable row level security;
alter table brands enable row level security;
alter table products enable row level security;

create policy "Lectura pública de categorías" on categories for select using (true);
create policy "Lectura pública de marcas" on brands for select using (true);
create policy "Lectura pública de productos" on products for select using (true);

-- price_history, price_rules y admin_activity NO son públicas: no se
-- habilita RLS con policy de select, así que sin la service role key
-- (que ignora RLS) quedan inaccesibles con la anon key. Correcto: son
-- datos internos del admin.
alter table price_history enable row level security;
alter table price_rules enable row level security;
alter table admin_activity enable row level security;

-- Los pedidos tampoco son públicos: tienen datos personales del cliente
-- (nombre, teléfono) y tanto crearlos (checkout) como leerlos/editarlos
-- (admin) pasan siempre por server actions con la service role key.
alter table orders enable row level security;

alter table branches enable row level security;
create policy "Lectura pública de sucursales" on branches for select using (true);

create table if not exists attributes (
  id text primary key,
  name text not null,
  values text[] not null default '{}'
);

alter table attributes enable row level security;
create policy "Lectura pública de atributos" on attributes for select using (true);

create table if not exists admin_users (
  id text primary key,
  name text not null,
  email text not null unique,
  password_hash text not null,
  role text not null default 'editor',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- Sin policy pública: contiene hashes de contraseña, solo accesible con
-- la service role key desde server actions (login, gestión de usuarios).
alter table admin_users enable row level security;

-- site_settings NO tiene policy pública de lectura: no hace falta, porque
-- el footer y /contacto son Server Components que siempre leen con la
-- service role key (nunca desde el navegador) — mismo criterio que
-- price_history o price_rules.
alter table site_settings enable row level security;
