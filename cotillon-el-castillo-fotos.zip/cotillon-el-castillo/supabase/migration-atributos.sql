-- =====================================================================
-- Migración: Atributos de producto + fix del campo "Costo"
-- =====================================================================
-- Es aditiva: correr esto no borra ni pisa nada de lo que ya tenías.
-- Supabase → tu proyecto → SQL Editor → New query → pegar → Run.
-- =====================================================================

-- 1) Atributos reutilizables (ej: "Color" con valores Rojo/Azul/Verde),
--    para asignarle características estructuradas a un producto además
--    de la descripción libre.
create table if not exists attributes (
  id text primary key,
  name text not null,
  values text[] not null default '{}'
);

alter table attributes enable row level security;
create policy "Lectura pública de atributos" on attributes for select using (true);

-- 2) Guarda qué valor de cada atributo tiene asignado cada producto
--    (ej: este producto tiene Color = "Rojo").
alter table products add column if not exists attribute_values jsonb not null default '[]';

-- 3) Fix: el campo "Costo" del formulario de producto nunca tuvo columna
--    en la base — se perdía en silencio al guardar. Esto lo arregla; no
--    afecta ningún producto existente (van a quedar con costo vacío
--    hasta que lo carges).
alter table products add column if not exists cost numeric;
