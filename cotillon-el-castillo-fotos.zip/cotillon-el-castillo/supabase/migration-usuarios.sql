-- =====================================================================
-- Migración: Usuarios administrativos (reemplaza el passcode único)
-- =====================================================================
-- Es aditiva: correr esto no borra nada de lo que ya tenías. Supabase →
-- tu proyecto → SQL Editor → New query → pegar → Run.
--
-- IMPORTANTE: después de correr esto necesitás crear tu primer usuario
-- con `npm run create-admin` (ver README) — la tabla arranca vacía a
-- propósito, nunca con una contraseña por defecto embebida acá.
-- =====================================================================

create table if not exists admin_users (
  id text primary key,
  name text not null,
  email text not null unique,
  password_hash text not null,
  role text not null default 'editor',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- Sin policy pública: contiene hashes de contraseña, solo accesible con
-- la service role key desde server actions (login, gestión de usuarios).
alter table admin_users enable row level security;
