/**
 * csv.ts
 * -----------------------------------------------------------------
 * Parser/generador de CSV mínimo, sin librerías externas. Soporta
 * comillas, comas y saltos de línea dentro de un campo (RFC 4180
 * básico) — suficiente para exportar/importar catálogos de producto,
 * que es lo único que necesita esta app. Funciones puras: no tocan
 * ningún store, así que se pueden usar tanto en cliente (wizard de
 * importación, botón de descarga) como en servidor si hiciera falta.
 * -----------------------------------------------------------------
 */

export function parseCSV(text: string): { headers: string[]; rows: string[][] } {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;

  const pushField = () => {
    row.push(field);
    field = "";
  };
  const pushRow = () => {
    rows.push(row);
    row = [];
  };

  const normalized = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];
    if (inQuotes) {
      if (char === '"') {
        if (normalized[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field += char;
      }
    } else if (char === '"') {
      inQuotes = true;
    } else if (char === ",") {
      pushField();
    } else if (char === "\n") {
      pushField();
      pushRow();
    } else {
      field += char;
    }
  }
  if (field.length > 0 || row.length > 0) {
    pushField();
    pushRow();
  }

  const nonEmpty = rows.filter((r) => r.length > 1 || (r.length === 1 && r[0].trim() !== ""));
  const [headerRow, ...dataRows] = nonEmpty;
  return { headers: (headerRow ?? []).map((h) => h.trim()), rows: dataRows };
}

function escapeCSVField(value: string): string {
  if (/[",\n]/.test(value)) return `"${value.replace(/"/g, '""')}"`;
  return value;
}

export function toCSV(headers: string[], rows: (string | number)[][]): string {
  const lines = [headers.map((h) => escapeCSVField(String(h))).join(",")];
  for (const row of rows) {
    lines.push(row.map((cell) => escapeCSVField(String(cell))).join(","));
  }
  return lines.join("\n");
}

/** Dispara la descarga de un archivo CSV desde el navegador. Incluye BOM para que Excel reconozca los acentos. */
export function downloadCSV(filename: string, csvContent: string) {
  const blob = new Blob([`\uFEFF${csvContent}`], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
