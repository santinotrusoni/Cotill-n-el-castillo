/**
 * mock-service.ts
 * -----------------------------------------------------------------
 * Capa única de acceso a datos. Habla con Supabase (Postgres) a
 * través de `supabaseAdmin` (service role, server-only — ver
 * lib/supabase/server.ts). Ningún componente de la UI debería
 * importar Supabase directamente, siempre pasan por acá.
 *
 * Todas las funciones son async porque ahora hacen una consulta de
 * red real. El nombre y la forma de cada función se mantuvo igual
 * a como estaban cuando esto era un array en memoria — por eso
 * algunas cosas (como recalcular un slug único) se resuelven en JS
 * después de traer los datos, en vez de en SQL puro: es el mismo
 * comportamiento de siempre, solo que ahora persiste de verdad.
 * -----------------------------------------------------------------
 */

import { supabaseAdmin } from "@/lib/supabase/server";
import bcrypt from "bcryptjs";
import {
  Product,
  ProductStatus,
  Category,
  Brand,
  CategoryInput,
  BrandInput,
  AdminActivityEntry,
  PriceHistoryEntry,
  PriceRule,
  PriceRuleInput,
  PriceUpdateType,
  RoundingOption,
  ProductImportRow,
  ProductImportResult,
  Order,
  OrderItem,
  OrderStatus,
  CreateOrderInput,
  Branch,
  BranchInput,
  SiteSettings,
  SiteSettingsInput,
  Attribute,
  AttributeInput,
  Customer,
  AdminUser,
  AdminUserInput,
  AdminRole,
} from "@/lib/types";
import { slugify, placeholderImage, formatPrice } from "@/lib/utils";
import { computeNewPrice, changeLabel } from "@/lib/pricing";

function generateId(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
}

function uniqueSlug(base: string, existing: string[]): string {
  const root = slugify(base) || generateId("item");
  if (!existing.includes(root)) return root;
  let n = 2;
  while (existing.includes(`${root}-${n}`)) n += 1;
  return `${root}-${n}`;
}

async function logActivity(type: AdminActivityEntry["type"], message: string): Promise<void> {
  const { error } = await supabaseAdmin
    .from("admin_activity")
    .insert({ id: generateId("act"), message, date: new Date().toISOString(), type });
  if (error) console.error("logActivity:", error.message);
}

function assertNoError(context: string, error: { message: string } | null): void {
  if (error) throw new Error(`${context}: ${error.message}`);
}

/* --------------------------------------------------------------- */
/* Mapeo fila de DB (snake_case) ↔ tipos de la app (camelCase)      */
/* --------------------------------------------------------------- */
function rowToProduct(row: any): Product {
  return {
    id: row.id,
    sku: row.sku,
    barcode: row.barcode,
    slug: row.slug,
    name: row.name,
    shortDescription: row.short_description,
    description: row.description,
    features: row.features ?? [],
    categoryId: row.category_id,
    brandId: row.brand_id,
    price: Number(row.price),
    previousPrice: row.previous_price === null || row.previous_price === undefined ? undefined : Number(row.previous_price),
    cost: row.cost === null || row.cost === undefined ? undefined : Number(row.cost),
    stock: row.stock,
    minStock: row.min_stock,
    status: row.status as ProductStatus,
    featured: row.featured,
    isNew: row.is_new,
    onOffer: row.on_offer,
    images: row.images ?? [],
    tags: row.tags ?? [],
    attributeValues: row.attribute_values ?? [],
    createdAt: row.created_at,
  };
}

/** Convierte un ProductInput (parcial o completo) a columnas de la tabla `products`. Solo incluye las claves presentes. */
function productInputToRow(input: Partial<Product>): Record<string, any> {
  const row: Record<string, any> = {};
  if (input.sku !== undefined) row.sku = input.sku;
  if (input.barcode !== undefined) row.barcode = input.barcode;
  if (input.slug !== undefined) row.slug = input.slug;
  if (input.name !== undefined) row.name = input.name;
  if (input.shortDescription !== undefined) row.short_description = input.shortDescription;
  if (input.description !== undefined) row.description = input.description;
  if (input.features !== undefined) row.features = input.features;
  if (input.categoryId !== undefined) row.category_id = input.categoryId;
  if (input.brandId !== undefined) row.brand_id = input.brandId;
  if (input.price !== undefined) row.price = input.price;
  if (input.previousPrice !== undefined) row.previous_price = input.previousPrice;
  if (input.cost !== undefined) row.cost = input.cost;
  if (input.stock !== undefined) row.stock = input.stock;
  if (input.minStock !== undefined) row.min_stock = input.minStock;
  if (input.status !== undefined) row.status = input.status;
  if (input.featured !== undefined) row.featured = input.featured;
  if (input.isNew !== undefined) row.is_new = input.isNew;
  if (input.onOffer !== undefined) row.on_offer = input.onOffer;
  if (input.images !== undefined) row.images = input.images;
  if (input.tags !== undefined) row.tags = input.tags;
  if (input.attributeValues !== undefined) row.attribute_values = input.attributeValues;
  if (input.createdAt !== undefined) row.created_at = input.createdAt;
  return row;
}

function rowToPriceHistory(row: any): PriceHistoryEntry {
  return {
    id: row.id,
    date: row.date,
    user: row.user,
    type: row.type,
    value: Number(row.value),
    rounding: row.rounding as RoundingOption,
    ruleName: row.rule_name ?? undefined,
    affectedProductIds: row.affected_product_ids ?? [],
    previousPrices: row.previous_prices ?? {},
    reverted: row.reverted,
  };
}

function rowToPriceRule(row: any): PriceRule {
  return {
    id: row.id,
    name: row.name,
    categoryId: row.category_id ?? undefined,
    brandId: row.brand_id ?? undefined,
    type: row.type,
    value: Number(row.value),
    rounding: row.rounding as RoundingOption,
    active: row.active,
    createdAt: row.created_at,
    lastAppliedAt: row.last_applied_at ?? undefined,
  };
}

function rowToOrder(row: any): Order {
  return {
    id: row.id,
    orderNumber: Number(row.order_number),
    customerName: row.customer_name,
    customerPhone: row.customer_phone,
    deliveryMethod: row.delivery_method,
    address: row.address ?? undefined,
    paymentMethod: row.payment_method,
    notes: row.notes ?? undefined,
    items: row.items ?? [],
    subtotal: Number(row.subtotal),
    discount: Number(row.discount),
    total: Number(row.total),
    status: row.status as OrderStatus,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

/* --------------------------------------------------------------- */
/* Productos — lectura                                              */
/* --------------------------------------------------------------- */
/**
 * Supabase (PostgREST) devuelve como máximo 1000 filas por consulta,
 * sin importar cuántas haya en la tabla — es un límite de la plataforma,
 * no algo que se pueda "pedir de más" en una sola llamada. Con más de
 * 1000 productos cargados, un `.select("*")` sin paginar devuelve solo
 * los primeros 1000 y listo, sin ningún error — así que hay que pedirlos
 * de a tandas y juntarlos acá.
 */
async function fetchAllProductRows(
  select: string,
  applyFilters: (query: any) => any = (q) => q
): Promise<any[]> {
  const PAGE_SIZE = 1000;
  const rows: any[] = [];
  let from = 0;
  while (true) {
    const { data, error } = await applyFilters(
      supabaseAdmin.from("products").select(select).order("created_at", { ascending: false })
    ).range(from, from + PAGE_SIZE - 1);
    assertNoError("fetchAllProductRows", error);
    if (!data || data.length === 0) break;
    rows.push(...data);
    if (data.length < PAGE_SIZE) break;
    from += PAGE_SIZE;
  }
  return rows;
}

/** Igual que arriba pero para buscar productos por id — trocea la lista en tandas de 500 para no chocar con el mismo límite de 1000 filas de respuesta. */
async function fetchProductsByIds(ids: string[], select: string = "*"): Promise<any[]> {
  const CHUNK_SIZE = 500;
  const rows: any[] = [];
  for (let i = 0; i < ids.length; i += CHUNK_SIZE) {
    const chunk = ids.slice(i, i + CHUNK_SIZE);
    const { data, error } = await supabaseAdmin.from("products").select(select).in("id", chunk);
    assertNoError("fetchProductsByIds", error);
    rows.push(...(data ?? []));
  }
  return rows;
}

export async function getProducts(): Promise<Product[]> {
  const rows = await fetchAllProductRows("*");
  return rows.map(rowToProduct);
}

export async function getProductById(id: string): Promise<Product | undefined> {
  const { data, error } = await supabaseAdmin.from("products").select("*").eq("id", id).maybeSingle();
  assertNoError("getProductById", error);
  return data ? rowToProduct(data) : undefined;
}

export async function getProductBySlug(slug: string): Promise<Product | undefined> {
  const { data, error } = await supabaseAdmin.from("products").select("*").eq("slug", slug).maybeSingle();
  assertNoError("getProductBySlug", error);
  return data ? rowToProduct(data) : undefined;
}

export async function getProductByBarcode(barcode: string): Promise<Product | undefined> {
  const { data, error } = await supabaseAdmin.from("products").select("*").eq("barcode", barcode).maybeSingle();
  assertNoError("getProductByBarcode", error);
  return data ? rowToProduct(data) : undefined;
}

export async function getFeaturedProducts(limit?: number): Promise<Product[]> {
  let query = supabaseAdmin
    .from("products")
    .select("*")
    .eq("featured", true)
    .neq("status", "sin_stock")
    .order("created_at", { ascending: false });
  if (limit) query = query.limit(limit);
  const { data, error } = await query;
  assertNoError("getFeaturedProducts", error);
  return (data ?? []).map(rowToProduct);
}

export async function getOfferProducts(limit?: number): Promise<Product[]> {
  let query = supabaseAdmin.from("products").select("*").eq("on_offer", true).order("created_at", { ascending: false });
  if (limit) query = query.limit(limit);
  const { data, error } = await query;
  assertNoError("getOfferProducts", error);
  return (data ?? []).map(rowToProduct);
}

/**
 * Productos de la sección Halloween: los de la categoría "Halloween" (slug
 * "halloween") y también los que tengan el tag "halloween".
 */
export async function getHalloweenProducts(limit?: number): Promise<Product[]> {
  const { data: cat } = await supabaseAdmin.from("categories").select("id").eq("slug", "halloween").maybeSingle();
  const filter = cat ? `tags.cs.{halloween},category_id.eq.${cat.id}` : "tags.cs.{halloween}";
  let query = supabaseAdmin
    .from("products")
    .select("*")
    .or(filter)
    .neq("status", "inactivo")
    .order("created_at", { ascending: false });
  if (limit) query = query.limit(limit);
  const { data, error } = await query;
  assertNoError("getHalloweenProducts", error);
  return (data ?? []).map(rowToProduct);
}

export async function getRelatedProducts(product: Product, limit = 4): Promise<Product[]> {
  const { data, error } = await supabaseAdmin
    .from("products")
    .select("*")
    .eq("category_id", product.categoryId)
    .neq("id", product.id)
    .limit(limit);
  assertNoError("getRelatedProducts", error);
  return (data ?? []).map(rowToProduct);
}

/* --------------------------------------------------------------- */
/* Productos — escritura (Panel Admin)                              */
/* --------------------------------------------------------------- */
export type ProductInput = Omit<Product, "id" | "createdAt" | "slug"> & { slug?: string };

export async function createProduct(input: ProductInput): Promise<Product> {
  const { data: existingSlugs, error: slugError } = await supabaseAdmin.from("products").select("slug");
  assertNoError("createProduct (slugs)", slugError);

  const slug = uniqueSlug(input.slug || input.name, (existingSlugs ?? []).map((r) => r.slug));
  const id = generateId("prod");
  const createdAt = new Date().toISOString();
  const row = productInputToRow({ ...input, id, slug, createdAt } as Product);
  row.id = id;

  const { data, error } = await supabaseAdmin.from("products").insert(row).select("*").single();
  assertNoError("createProduct", error);

  const product = rowToProduct(data);
  await logActivity("producto", `Se creó el producto "${product.name}".`);
  return product;
}

export async function updateProduct(id: string, input: Partial<ProductInput>): Promise<Product> {
  const current = await getProductById(id);
  if (!current) throw new Error(`updateProduct: no existe el producto ${id}`);

  let nextSlug = current.slug;
  if (input.slug !== undefined || (input.name && input.name !== current.name)) {
    const { data: existingSlugs, error: slugError } = await supabaseAdmin
      .from("products")
      .select("slug")
      .neq("id", id);
    assertNoError("updateProduct (slugs)", slugError);
    nextSlug = uniqueSlug(input.slug || input.name || current.name, (existingSlugs ?? []).map((r) => r.slug));
  }

  const row = productInputToRow({ ...input, slug: nextSlug });
  const { data, error } = await supabaseAdmin.from("products").update(row).eq("id", id).select("*").single();
  assertNoError("updateProduct", error);

  const updated = rowToProduct(data);
  await logActivity("producto", `Se editó el producto "${updated.name}".`);
  return updated;
}

export async function deleteProduct(id: string): Promise<void> {
  const product = await getProductById(id);
  const { error } = await supabaseAdmin.from("products").delete().eq("id", id);
  assertNoError("deleteProduct", error);
  if (product) await logActivity("producto", `Se eliminó el producto "${product.name}".`);
}

/* --------------------------------------------------------------- */
/* Categorías                                                       */
/* --------------------------------------------------------------- */
export async function getCategories(): Promise<Category[]> {
  const { data, error } = await supabaseAdmin.from("categories").select("*").order("name");
  assertNoError("getCategories", error);
  return data ?? [];
}

export async function getCategoryBySlug(slug: string): Promise<Category | undefined> {
  const { data, error } = await supabaseAdmin.from("categories").select("*").eq("slug", slug).maybeSingle();
  assertNoError("getCategoryBySlug", error);
  return data ?? undefined;
}

export async function getCategoryById(id: string): Promise<Category | undefined> {
  const { data, error } = await supabaseAdmin.from("categories").select("*").eq("id", id).maybeSingle();
  assertNoError("getCategoryById", error);
  return data ?? undefined;
}

export async function createCategory(input: CategoryInput): Promise<Category> {
  const { data: existingSlugs, error: slugError } = await supabaseAdmin.from("categories").select("slug");
  assertNoError("createCategory (slugs)", slugError);
  const slug = uniqueSlug(input.slug || input.name, (existingSlugs ?? []).map((r) => r.slug));
  const category: Category = { ...input, id: generateId("cat"), slug };

  const { error } = await supabaseAdmin.from("categories").insert(category);
  assertNoError("createCategory", error);
  await logActivity("categoria", `Se creó la categoría "${category.name}".`);
  return category;
}

export async function updateCategory(id: string, input: Partial<CategoryInput>): Promise<Category> {
  const current = await getCategoryById(id);
  if (!current) throw new Error(`updateCategory: no existe la categoría ${id}`);

  let nextSlug = current.slug;
  if (input.slug !== undefined || (input.name && input.name !== current.name)) {
    const { data: existingSlugs, error: slugError } = await supabaseAdmin
      .from("categories")
      .select("slug")
      .neq("id", id);
    assertNoError("updateCategory (slugs)", slugError);
    nextSlug = uniqueSlug(input.slug || input.name || current.name, (existingSlugs ?? []).map((r) => r.slug));
  }

  const updated: Category = { ...current, ...input, id: current.id, slug: nextSlug };
  const { error } = await supabaseAdmin.from("categories").update(updated).eq("id", id);
  assertNoError("updateCategory", error);
  await logActivity("categoria", `Se editó la categoría "${updated.name}".`);
  return updated;
}

/** Lanza error si la categoría tiene productos asociados: evitamos dejar productos huérfanos. */
export async function deleteCategory(id: string): Promise<void> {
  const category = await getCategoryById(id);
  const { count, error: countError } = await supabaseAdmin
    .from("products")
    .select("id", { count: "exact", head: true })
    .eq("category_id", id);
  assertNoError("deleteCategory (check)", countError);
  if (count && count > 0) {
    throw new Error("No se puede eliminar: hay productos asignados a esta categoría. Reasignalos primero.");
  }
  const { error } = await supabaseAdmin.from("categories").delete().eq("id", id);
  assertNoError("deleteCategory", error);
  if (category) await logActivity("categoria", `Se eliminó la categoría "${category.name}".`);
}

export async function productCountByCategory(categoryId: string): Promise<number> {
  const { count, error } = await supabaseAdmin
    .from("products")
    .select("id", { count: "exact", head: true })
    .eq("category_id", categoryId);
  assertNoError("productCountByCategory", error);
  return count ?? 0;
}

/* --------------------------------------------------------------- */
/* Marcas                                                           */
/* --------------------------------------------------------------- */
export async function getBrands(): Promise<Brand[]> {
  const { data, error } = await supabaseAdmin.from("brands").select("*").order("name");
  assertNoError("getBrands", error);
  return data ?? [];
}

export async function getBrandById(id: string): Promise<Brand | undefined> {
  const { data, error } = await supabaseAdmin.from("brands").select("*").eq("id", id).maybeSingle();
  assertNoError("getBrandById", error);
  return data ?? undefined;
}

export async function createBrand(input: BrandInput): Promise<Brand> {
  const { data: existingSlugs, error: slugError } = await supabaseAdmin.from("brands").select("slug");
  assertNoError("createBrand (slugs)", slugError);
  const slug = uniqueSlug(input.slug || input.name, (existingSlugs ?? []).map((r) => r.slug));
  const brand: Brand = { ...input, id: generateId("brand"), slug };

  const { error } = await supabaseAdmin.from("brands").insert(brand);
  assertNoError("createBrand", error);
  await logActivity("marca", `Se creó la marca "${brand.name}".`);
  return brand;
}

export async function updateBrand(id: string, input: Partial<BrandInput>): Promise<Brand> {
  const current = await getBrandById(id);
  if (!current) throw new Error(`updateBrand: no existe la marca ${id}`);

  let nextSlug = current.slug;
  if (input.slug !== undefined || (input.name && input.name !== current.name)) {
    const { data: existingSlugs, error: slugError } = await supabaseAdmin.from("brands").select("slug").neq("id", id);
    assertNoError("updateBrand (slugs)", slugError);
    nextSlug = uniqueSlug(input.slug || input.name || current.name, (existingSlugs ?? []).map((r) => r.slug));
  }

  const updated: Brand = { ...current, ...input, id: current.id, slug: nextSlug };
  const { error } = await supabaseAdmin.from("brands").update(updated).eq("id", id);
  assertNoError("updateBrand", error);
  await logActivity("marca", `Se editó la marca "${updated.name}".`);
  return updated;
}

export async function deleteBrand(id: string): Promise<void> {
  const brand = await getBrandById(id);
  const { count, error: countError } = await supabaseAdmin
    .from("products")
    .select("id", { count: "exact", head: true })
    .eq("brand_id", id);
  assertNoError("deleteBrand (check)", countError);
  if (count && count > 0) {
    throw new Error("No se puede eliminar: hay productos asignados a esta marca. Reasignalos primero.");
  }
  const { error } = await supabaseAdmin.from("brands").delete().eq("id", id);
  assertNoError("deleteBrand", error);
  if (brand) await logActivity("marca", `Se eliminó la marca "${brand.name}".`);
}

export async function productCountByBrand(brandId: string): Promise<number> {
  const { count, error } = await supabaseAdmin
    .from("products")
    .select("id", { count: "exact", head: true })
    .eq("brand_id", brandId);
  assertNoError("productCountByBrand", error);
  return count ?? 0;
}

/* --------------------------------------------------------------- */
/* Dashboard admin                                                   */
/* --------------------------------------------------------------- */
export async function getDashboardStats() {
  const [
    productRows,
    categories,
    { count: brandsCount },
    { count: activeRulesCount },
    { count: pendingOrdersCount },
  ] = await Promise.all([
    fetchAllProductRows("id, status, stock, featured, on_offer, category_id, name"),
    getCategories(),
    supabaseAdmin.from("brands").select("id", { count: "exact", head: true }),
    supabaseAdmin.from("price_rules").select("id", { count: "exact", head: true }).eq("active", true),
    supabaseAdmin.from("orders").select("id", { count: "exact", head: true }).eq("status", "pendiente"),
  ]);

  const products = productRows;
  const total = products.length;
  const enStock = products.filter((p) => p.status !== "sin_stock" && p.stock > 0).length;
  const sinStock = products.filter((p) => p.status === "sin_stock" || p.stock === 0).length;
  const destacados = products.filter((p) => p.featured).length;
  const ofertas = products.filter((p) => p.on_offer).length;

  const stockPorCategoria = categories
    .map((c) => ({
      category: c,
      count: products.filter((p) => p.category_id === c.id).length,
    }))
    .sort((a, b) => b.count - a.count);

  const sinStockList = products
    .filter((p) => p.status === "sin_stock" || p.stock === 0)
    .slice(0, 6)
    .map((p) => ({ id: p.id as string, name: p.name as string }));

  return {
    total,
    enStock,
    sinStock,
    categorias: categories.length,
    marcas: brandsCount ?? 0,
    destacados,
    ofertas,
    reglasActivas: activeRulesCount ?? 0,
    pedidosPendientes: pendingOrdersCount ?? 0,
    stockPorCategoria,
    sinStockList,
  };
}

export async function getRecentActivity(limit = 8): Promise<AdminActivityEntry[]> {
  const { data, error } = await supabaseAdmin
    .from("admin_activity")
    .select("*")
    .order("date", { ascending: false })
    .limit(limit);
  assertNoError("getRecentActivity", error);
  return data ?? [];
}

/* --------------------------------------------------------------- */
/* Actualización masiva de precios + historial                     */
/* --------------------------------------------------------------- */
export interface ApplyPriceUpdateInput {
  productIds: string[];
  type: PriceUpdateType;
  value: number;
  rounding: RoundingOption;
  /** Presente cuando la actualización la disparó una regla automática. */
  ruleName?: string;
}

export async function getPriceHistory(): Promise<PriceHistoryEntry[]> {
  const { data, error } = await supabaseAdmin.from("price_history").select("*").order("date", { ascending: false });
  assertNoError("getPriceHistory", error);
  return (data ?? []).map(rowToPriceHistory);
}

export async function getPriceHistoryById(id: string): Promise<PriceHistoryEntry | undefined> {
  const { data, error } = await supabaseAdmin.from("price_history").select("*").eq("id", id).maybeSingle();
  assertNoError("getPriceHistoryById", error);
  return data ? rowToPriceHistory(data) : undefined;
}

/**
 * Aplica una actualización masiva: nunca se llama "en automático" desde la
 * UI sin que el admin haya confirmado explícitamente el preview. Guarda el
 * precio anterior de cada producto afectado para poder revertir después.
 */
export async function applyPriceUpdate(input: ApplyPriceUpdateInput): Promise<PriceHistoryEntry> {
  const { productIds, type, value, rounding, ruleName } = input;
  const targets = await fetchProductsByIds(productIds, "id, price");
  if (!targets || targets.length === 0) {
    throw new Error("No hay productos que coincidan con la selección.");
  }

  const previousPrices: Record<string, number> = {};
  // Upsert parcial (solo id + price): como estas filas ya existen, Postgres
  // toma siempre la rama ON CONFLICT DO UPDATE — nunca intenta un insert
  // "real" que necesitaría las demás columnas NOT NULL.
  const priceUpdates = targets.map((p) => {
    previousPrices[p.id] = Number(p.price);
    return { id: p.id, price: computeNewPrice(Number(p.price), type, value, rounding) };
  });
  const { error: updateError } = await supabaseAdmin.from("products").upsert(priceUpdates);
  assertNoError("applyPriceUpdate (write)", updateError);

  const entry: PriceHistoryEntry = {
    id: generateId("price"),
    date: new Date().toISOString(),
    user: "Administrador",
    type,
    value,
    rounding,
    ruleName,
    affectedProductIds: targets.map((p) => p.id),
    previousPrices,
    reverted: false,
  };
  const { error: historyError } = await supabaseAdmin.from("price_history").insert({
    id: entry.id,
    date: entry.date,
    user: entry.user,
    type: entry.type,
    value: entry.value,
    rounding: entry.rounding,
    rule_name: entry.ruleName ?? null,
    affected_product_ids: entry.affectedProductIds,
    previous_prices: entry.previousPrices,
    reverted: entry.reverted,
  });
  assertNoError("applyPriceUpdate (history)", historyError);

  await logActivity(
    "precio",
    `Actualización de precios (${changeLabel(type, value)}) aplicada a ${targets.length} producto${
      targets.length === 1 ? "" : "s"
    }${ruleName ? ` — regla "${ruleName}"` : ""}.`
  );

  return entry;
}

/** Restaura los precios previos de todos los productos afectados por una actualización. */
export async function revertPriceUpdate(historyId: string): Promise<PriceHistoryEntry> {
  const entry = await getPriceHistoryById(historyId);
  if (!entry) throw new Error("No se encontró esa actualización en el historial.");
  if (entry.reverted) throw new Error("Esta actualización ya fue revertida anteriormente.");

  const restores = Object.entries(entry.previousPrices).map(([id, price]) => ({ id, price }));
  const { error: restoreError } = await supabaseAdmin.from("products").upsert(restores);
  assertNoError("revertPriceUpdate (write)", restoreError);

  const { error: historyError } = await supabaseAdmin
    .from("price_history")
    .update({ reverted: true })
    .eq("id", historyId);
  assertNoError("revertPriceUpdate (history)", historyError);

  await logActivity(
    "precio",
    `Se revirtió una actualización de precios (${entry.affectedProductIds.length} productos vuelven a su precio anterior).`
  );
  return { ...entry, reverted: true };
}

/* --------------------------------------------------------------- */
/* Reglas automáticas de precios                                    */
/* --------------------------------------------------------------- */
export async function getPriceRules(): Promise<PriceRule[]> {
  const { data, error } = await supabaseAdmin.from("price_rules").select("*").order("created_at", { ascending: false });
  assertNoError("getPriceRules", error);
  return (data ?? []).map(rowToPriceRule);
}

export async function getPriceRuleById(id: string): Promise<PriceRule | undefined> {
  const { data, error } = await supabaseAdmin.from("price_rules").select("*").eq("id", id).maybeSingle();
  assertNoError("getPriceRuleById", error);
  return data ? rowToPriceRule(data) : undefined;
}

export async function getProductsForRuleScope(rule: Pick<PriceRule, "categoryId" | "brandId">): Promise<Product[]> {
  const rows = await fetchAllProductRows("*", (q) => {
    if (rule.categoryId) q = q.eq("category_id", rule.categoryId);
    if (rule.brandId) q = q.eq("brand_id", rule.brandId);
    return q;
  });
  return rows.map(rowToProduct);
}

export async function createPriceRule(input: PriceRuleInput): Promise<PriceRule> {
  const rule: PriceRule = { ...input, id: generateId("rule"), createdAt: new Date().toISOString() };
  const { error } = await supabaseAdmin.from("price_rules").insert({
    id: rule.id,
    name: rule.name,
    category_id: rule.categoryId ?? null,
    brand_id: rule.brandId ?? null,
    type: rule.type,
    value: rule.value,
    rounding: rule.rounding,
    active: rule.active,
    created_at: rule.createdAt,
    last_applied_at: null,
  });
  assertNoError("createPriceRule", error);
  await logActivity("precio", `Se creó la regla de precios "${rule.name}".`);
  return rule;
}

export async function updatePriceRule(id: string, input: Partial<PriceRuleInput>): Promise<PriceRule> {
  const current = await getPriceRuleById(id);
  if (!current) throw new Error(`updatePriceRule: no existe la regla ${id}`);
  const updated: PriceRule = { ...current, ...input };

  const { error } = await supabaseAdmin
    .from("price_rules")
    .update({
      name: updated.name,
      category_id: updated.categoryId ?? null,
      brand_id: updated.brandId ?? null,
      type: updated.type,
      value: updated.value,
      rounding: updated.rounding,
      active: updated.active,
    })
    .eq("id", id);
  assertNoError("updatePriceRule", error);
  await logActivity("precio", `Se editó la regla "${updated.name}".`);
  return updated;
}

export async function deletePriceRule(id: string): Promise<void> {
  const rule = await getPriceRuleById(id);
  const { error } = await supabaseAdmin.from("price_rules").delete().eq("id", id);
  assertNoError("deletePriceRule", error);
  if (rule) await logActivity("precio", `Se eliminó la regla "${rule.name}".`);
}

/** Aplica una regla ya mismo, reutilizando exactamente la misma lógica que el wizard manual. */
export async function applyPriceRuleNow(id: string): Promise<PriceHistoryEntry> {
  const rule = await getPriceRuleById(id);
  if (!rule) throw new Error("No se encontró la regla.");
  const targets = await getProductsForRuleScope(rule);
  if (targets.length === 0) {
    throw new Error("Esta regla no tiene productos asociados en su categoría/marca.");
  }
  const entry = await applyPriceUpdate({
    productIds: targets.map((p) => p.id),
    type: rule.type,
    value: rule.value,
    rounding: rule.rounding,
    ruleName: rule.name,
  });
  const { error } = await supabaseAdmin
    .from("price_rules")
    .update({ last_applied_at: new Date().toISOString() })
    .eq("id", id);
  assertNoError("applyPriceRuleNow (touch)", error);
  return entry;
}

/* --------------------------------------------------------------- */
/* Importación masiva de productos (CSV)                           */
/* --------------------------------------------------------------- */
/**
 * Crea o actualiza productos en bloque a partir de filas ya validadas por
 * el wizard de importación. Matchea por código de barras: si ya existe un
 * producto con ese código, lo actualiza (precio/stock/nombre/etc); si no
 * existe, lo crea. Trae el catálogo actual UNA sola vez y hace un único
 * upsert al final en vez de una consulta por fila — más rápido y evita
 * problemas de slugs duplicados dentro del mismo archivo.
 */
export async function bulkImportProducts(rows: ProductImportRow[]): Promise<ProductImportResult> {
  const [existingProducts, categories, brands] = await Promise.all([
    fetchAllProductRows("*"),
    getCategories(),
    getBrands(),
  ]);

  const productsByBarcode = new Map(existingProducts.map((p) => [p.barcode, p]));
  const usedSlugs = new Set(existingProducts.map((p) => p.slug as string));
  const createdIds: string[] = [];
  const updatedIds: string[] = [];
  const finalRows: Record<string, any>[] = [];

  for (const row of rows) {
    const existing = productsByBarcode.get(row.barcode);
    const category = row.categoryName
      ? categories.find((c) => c.name.toLowerCase() === row.categoryName!.trim().toLowerCase())
      : undefined;
    const brand = row.brandName
      ? brands.find((b) => b.name.toLowerCase() === row.brandName!.trim().toLowerCase())
      : undefined;

    if (existing) {
      finalRows.push({
        ...existing,
        name: row.name || existing.name,
        price: row.price,
        stock: row.stock,
        status: row.stock === 0 ? "sin_stock" : existing.status === "sin_stock" ? "activo" : existing.status,
        sku: row.sku || existing.sku,
        category_id: category?.id ?? existing.category_id,
        brand_id: brand?.id ?? existing.brand_id,
        description: row.description || existing.description,
      });
      updatedIds.push(existing.id);
    } else {
      const fallbackCategory = category ?? categories[0];
      const fallbackBrand = brand ?? brands[0];
      const id = generateId("prod");
      const slug = uniqueSlug(row.name, Array.from(usedSlugs));
      usedSlugs.add(slug);
      finalRows.push({
        id,
        sku: row.sku || row.barcode,
        barcode: row.barcode,
        slug,
        name: row.name,
        short_description: (row.description || row.name).slice(0, 140),
        description: row.description || row.name,
        features: [],
        category_id: fallbackCategory?.id ?? "",
        brand_id: fallbackBrand?.id ?? "",
        price: row.price,
        stock: row.stock,
        min_stock: 5,
        status: row.stock === 0 ? "sin_stock" : "activo",
        featured: false,
        is_new: true,
        on_offer: false,
        images: [placeholderImage(row.name)],
        tags: [],
        attribute_values: [],
        created_at: new Date().toISOString(),
      });
      createdIds.push(id);
    }
  }

  if (finalRows.length > 0) {
    const { error } = await supabaseAdmin.from("products").upsert(finalRows);
    assertNoError("bulkImportProducts (write)", error);
  }

  await logActivity(
    "producto",
    `Importación CSV: ${createdIds.length} producto${createdIds.length === 1 ? "" : "s"} creado${
      createdIds.length === 1 ? "" : "s"
    }, ${updatedIds.length} actualizado${updatedIds.length === 1 ? "" : "s"}.`
  );

  return { createdCount: createdIds.length, updatedCount: updatedIds.length, createdIds, updatedIds };
}

/* --------------------------------------------------------------- */
/* Pedidos (checkout real)                                          */
/* --------------------------------------------------------------- */
export async function getOrders(): Promise<Order[]> {
  const { data, error } = await supabaseAdmin.from("orders").select("*").order("created_at", { ascending: false });
  assertNoError("getOrders", error);
  return (data ?? []).map(rowToOrder);
}

export async function getOrderById(id: string): Promise<Order | undefined> {
  const { data, error } = await supabaseAdmin.from("orders").select("*").eq("id", id).maybeSingle();
  assertNoError("getOrderById", error);
  return data ? rowToOrder(data) : undefined;
}

export async function getOrdersByCustomerId(customerId: string): Promise<Order[]> {
  const { data, error } = await supabaseAdmin
    .from("orders")
    .select("*")
    .eq("customer_id", customerId)
    .order("created_at", { ascending: false });
  assertNoError("getOrdersByCustomerId", error);
  return (data ?? []).map(rowToOrder);
}

/**
 * Crea un pedido a partir del carrito. Nunca confía en precios que vengan
 * del cliente: vuelve a buscar cada producto por id y recalcula todo
 * (nombre, precio, subtotal, descuento, total) con los datos actuales de
 * la base — así nadie puede manipular el total editando el estado del
 * navegador antes de confirmar. También descuenta stock de cada producto.
 */
export async function createOrder(input: CreateOrderInput, customerId?: string): Promise<Order> {
  if (input.items.length === 0) throw new Error("El carrito está vacío.");

  const productIds = input.items.map((i) => i.productId);
  const { data: productRows, error: productsError } = await supabaseAdmin
    .from("products")
    .select("*")
    .in("id", productIds);
  assertNoError("createOrder (fetch)", productsError);

  const productsById = new Map((productRows ?? []).map((p) => [p.id, rowToProduct(p)]));

  const items: OrderItem[] = [];
  let subtotal = 0;
  let discount = 0;

  for (const line of input.items) {
    const product = productsById.get(line.productId);
    if (!product) continue; // producto eliminado entre que se agregó al carrito y se confirmó el pedido
    const quantity = Math.max(1, line.quantity);
    items.push({ productId: product.id, name: product.name, price: product.price, quantity });
    subtotal += product.price * quantity;
    if (product.previousPrice && product.previousPrice > product.price) {
      discount += (product.previousPrice - product.price) * quantity;
    }
  }

  if (items.length === 0) {
    throw new Error("Ninguno de los productos del carrito está disponible.");
  }

  const total = subtotal;
  const id = generateId("order");
  const now = new Date().toISOString();

  const { data, error } = await supabaseAdmin
    .from("orders")
    .insert({
      id,
      customer_name: input.customerName,
      customer_phone: input.customerPhone,
      delivery_method: input.deliveryMethod,
      address: input.address ?? null,
      payment_method: input.paymentMethod,
      notes: input.notes ?? null,
      items,
      subtotal,
      discount,
      total,
      status: "pendiente",
      created_at: now,
      updated_at: now,
      // Solo si hay cuenta logueada (así el checkout de invitados no depende de la migración de cuentas).
      ...(customerId ? { customer_id: customerId } : {}),
    })
    .select("*")
    .single();
  assertNoError("createOrder (insert)", error);

  // Descuenta stock — nunca deja stock negativo, y marca "sin_stock" al llegar a 0.
  const stockUpdates = items
    .map((item) => {
      const product = productsById.get(item.productId)!;
      const nextStock = Math.max(0, product.stock - item.quantity);
      return {
        id: product.id,
        stock: nextStock,
        status: nextStock === 0 ? "sin_stock" : product.status === "sin_stock" ? "activo" : product.status,
      };
    });
  const { error: stockError } = await supabaseAdmin.from("products").upsert(stockUpdates);
  assertNoError("createOrder (stock)", stockError);

  const order = rowToOrder(data);
  await logActivity(
    "pedido",
    `Nuevo pedido #${order.orderNumber} de ${order.customerName} por ${items.length} producto${
      items.length === 1 ? "" : "s"
    } (${formatPrice(order.total)}).`
  );
  return order;
}

export async function updateOrderStatus(id: string, status: OrderStatus): Promise<Order> {
  const { data, error } = await supabaseAdmin
    .from("orders")
    .update({ status, updated_at: new Date().toISOString() })
    .eq("id", id)
    .select("*")
    .single();
  assertNoError("updateOrderStatus", error);
  const order = rowToOrder(data);
  await logActivity("pedido", `El pedido #${order.orderNumber} pasó a estado "${status}".`);
  return order;
}

/* --------------------------------------------------------------- */
/* Sucursales                                                        */
/* --------------------------------------------------------------- */
export async function getBranches(): Promise<Branch[]> {
  const { data, error } = await supabaseAdmin.from("branches").select("*").order("name");
  assertNoError("getBranches", error);
  return data ?? [];
}

export async function getBranchById(id: string): Promise<Branch | undefined> {
  const { data, error } = await supabaseAdmin.from("branches").select("*").eq("id", id).maybeSingle();
  assertNoError("getBranchById", error);
  return data ?? undefined;
}

export async function createBranch(input: BranchInput): Promise<Branch> {
  const branch: Branch = { ...input, id: generateId("branch") };
  const { error } = await supabaseAdmin.from("branches").insert(branch);
  assertNoError("createBranch", error);
  await logActivity("sucursal", `Se creó la sucursal "${branch.name}".`);
  return branch;
}

export async function updateBranch(id: string, input: Partial<BranchInput>): Promise<Branch> {
  const current = await getBranchById(id);
  if (!current) throw new Error(`updateBranch: no existe la sucursal ${id}`);
  const updated: Branch = { ...current, ...input, id: current.id };
  const { error } = await supabaseAdmin.from("branches").update(updated).eq("id", id);
  assertNoError("updateBranch", error);
  await logActivity("sucursal", `Se editó la sucursal "${updated.name}".`);
  return updated;
}

export async function deleteBranch(id: string): Promise<void> {
  const branch = await getBranchById(id);
  const { error } = await supabaseAdmin.from("branches").delete().eq("id", id);
  assertNoError("deleteBranch", error);
  if (branch) await logActivity("sucursal", `Se eliminó la sucursal "${branch.name}".`);
}

/* --------------------------------------------------------------- */
/* Ajustes generales del sitio (fila única)                          */
/* --------------------------------------------------------------- */
const DEFAULT_SETTINGS: SiteSettings = {
  storeName: "Cotillón El Castillo",
  whatsappNumber: "5491100000000",
  contactEmail: "hola@elcastillocotillon.com.ar",
  address: "Villa Dominico, Buenos Aires, Argentina",
  hours: "Lun a Sáb de 9 a 19 h",
};

function rowToSiteSettings(row: any): SiteSettings {
  return {
    storeName: row.store_name,
    whatsappNumber: row.whatsapp_number,
    contactEmail: row.contact_email,
    address: row.address,
    hours: row.hours,
  };
}

/** Si por algún motivo la fila 'default' no existe todavía, devuelve los valores por defecto en vez de romper el sitio. */
export async function getSiteSettings(): Promise<SiteSettings> {
  const { data, error } = await supabaseAdmin.from("site_settings").select("*").eq("id", "default").maybeSingle();
  assertNoError("getSiteSettings", error);
  return data ? rowToSiteSettings(data) : DEFAULT_SETTINGS;
}

export async function updateSiteSettings(input: SiteSettingsInput): Promise<SiteSettings> {
  const { error } = await supabaseAdmin.from("site_settings").upsert({
    id: "default",
    store_name: input.storeName,
    whatsapp_number: input.whatsappNumber,
    contact_email: input.contactEmail,
    address: input.address,
    hours: input.hours,
  });
  assertNoError("updateSiteSettings", error);
  await logActivity("ajustes", "Se actualizaron los datos generales del sitio.");
  return input;
}

/* --------------------------------------------------------------- */
/* Atributos de producto                                             */
/* --------------------------------------------------------------- */
export async function getAttributes(): Promise<Attribute[]> {
  const { data, error } = await supabaseAdmin.from("attributes").select("*").order("name");
  assertNoError("getAttributes", error);
  return (data ?? []).map((r) => ({ id: r.id, name: r.name, values: r.values ?? [] }));
}

export async function getAttributeById(id: string): Promise<Attribute | undefined> {
  const { data, error } = await supabaseAdmin.from("attributes").select("*").eq("id", id).maybeSingle();
  assertNoError("getAttributeById", error);
  return data ? { id: data.id, name: data.name, values: data.values ?? [] } : undefined;
}

export async function createAttribute(input: AttributeInput): Promise<Attribute> {
  const attribute: Attribute = { ...input, id: generateId("attr") };
  const { error } = await supabaseAdmin.from("attributes").insert(attribute);
  assertNoError("createAttribute", error);
  await logActivity("atributo", `Se creó el atributo "${attribute.name}".`);
  return attribute;
}

export async function updateAttribute(id: string, input: Partial<AttributeInput>): Promise<Attribute> {
  const current = await getAttributeById(id);
  if (!current) throw new Error(`updateAttribute: no existe el atributo ${id}`);
  const updated: Attribute = { ...current, ...input, id: current.id };
  const { error } = await supabaseAdmin.from("attributes").update(updated).eq("id", id);
  assertNoError("updateAttribute", error);
  await logActivity("atributo", `Se editó el atributo "${updated.name}".`);
  return updated;
}

export async function deleteAttribute(id: string): Promise<void> {
  const attribute = await getAttributeById(id);
  const { error } = await supabaseAdmin.from("attributes").delete().eq("id", id);
  assertNoError("deleteAttribute", error);
  if (attribute) await logActivity("atributo", `Se eliminó el atributo "${attribute.name}".`);
}

/* --------------------------------------------------------------- */
/* Clientes (derivados de los pedidos — no hay cuentas de cliente)  */
/* --------------------------------------------------------------- */
/**
 * No existe un login de cliente ni una tabla propia: un "cliente" acá es
 * simplemente el conjunto de pedidos que comparten el mismo teléfono.
 * Inventar una tabla de clientes separada, desconectada de los pedidos
 * reales, sería una función de mentira — esto sí refleja datos reales.
 */
export async function getCustomers(): Promise<Customer[]> {
  const { data, error } = await supabaseAdmin
    .from("orders")
    .select("customer_name, customer_phone, total, created_at")
    .order("created_at", { ascending: true });
  assertNoError("getCustomers", error);

  const byPhone = new Map<string, Customer>();
  for (const row of data ?? []) {
    const existing = byPhone.get(row.customer_phone);
    if (existing) {
      existing.orderCount += 1;
      existing.totalSpent += Number(row.total);
      existing.name = row.customer_name; // se queda con el nombre más reciente
      existing.lastOrderAt = row.created_at;
    } else {
      byPhone.set(row.customer_phone, {
        phone: row.customer_phone,
        name: row.customer_name,
        orderCount: 1,
        totalSpent: Number(row.total),
        firstOrderAt: row.created_at,
        lastOrderAt: row.created_at,
      });
    }
  }

  return Array.from(byPhone.values()).sort((a, b) => b.lastOrderAt.localeCompare(a.lastOrderAt));
}

export async function getCustomerOrders(phone: string): Promise<Order[]> {
  const { data, error } = await supabaseAdmin
    .from("orders")
    .select("*")
    .eq("customer_phone", phone)
    .order("created_at", { ascending: false });
  assertNoError("getCustomerOrders", error);
  return (data ?? []).map(rowToOrder);
}

/* --------------------------------------------------------------- */
/* Usuarios administrativos                                          */
/* --------------------------------------------------------------- */
function rowToAdminUser(row: any): AdminUser {
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    role: row.role,
    active: row.active,
    createdAt: row.created_at,
  };
}

export async function getAdminUsers(): Promise<AdminUser[]> {
  const { data, error } = await supabaseAdmin.from("admin_users").select("*").order("created_at");
  assertNoError("getAdminUsers", error);
  return (data ?? []).map(rowToAdminUser);
}

export async function getAdminUserById(id: string): Promise<AdminUser | undefined> {
  const { data, error } = await supabaseAdmin.from("admin_users").select("*").eq("id", id).maybeSingle();
  assertNoError("getAdminUserById", error);
  return data ? rowToAdminUser(data) : undefined;
}

export async function createAdminUser(input: AdminUserInput): Promise<AdminUser> {
  const email = input.email.trim().toLowerCase();
  const { data: existing } = await supabaseAdmin.from("admin_users").select("id").eq("email", email).maybeSingle();
  if (existing) throw new Error("Ya existe un usuario con ese email.");

  const passwordHash = await bcrypt.hash(input.password, 10);
  const id = generateId("user");
  const createdAt = new Date().toISOString();
  const { error } = await supabaseAdmin.from("admin_users").insert({
    id,
    name: input.name.trim(),
    email,
    password_hash: passwordHash,
    role: input.role,
    active: true,
    created_at: createdAt,
  });
  assertNoError("createAdminUser", error);

  await logActivity("usuario", `Se creó el usuario "${input.name.trim()}" (${input.role}).`);
  return { id, name: input.name.trim(), email, role: input.role, active: true, createdAt };
}

export interface UpdateAdminUserInput {
  name?: string;
  role?: AdminRole;
  active?: boolean;
  /** Si viene, reemplaza la contraseña actual. */
  password?: string;
}

export async function updateAdminUser(id: string, input: UpdateAdminUserInput): Promise<AdminUser> {
  const current = await getAdminUserById(id);
  if (!current) throw new Error(`updateAdminUser: no existe el usuario ${id}`);

  const row: Record<string, any> = {};
  if (input.name !== undefined) row.name = input.name.trim();
  if (input.role !== undefined) row.role = input.role;
  if (input.active !== undefined) row.active = input.active;
  if (input.password) row.password_hash = await bcrypt.hash(input.password, 10);

  const { error } = await supabaseAdmin.from("admin_users").update(row).eq("id", id);
  assertNoError("updateAdminUser", error);

  await logActivity("usuario", `Se editó el usuario "${input.name?.trim() ?? current.name}".`);
  return { ...current, name: row.name ?? current.name, role: row.role ?? current.role, active: row.active ?? current.active };
}

export async function deleteAdminUser(id: string): Promise<void> {
  const user = await getAdminUserById(id);
  const { error } = await supabaseAdmin.from("admin_users").delete().eq("id", id);
  assertNoError("deleteAdminUser", error);
  if (user) await logActivity("usuario", `Se eliminó el usuario "${user.name}".`);
}
