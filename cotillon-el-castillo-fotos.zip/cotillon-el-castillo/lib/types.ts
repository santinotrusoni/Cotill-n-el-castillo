export type ProductStatus = "activo" | "inactivo" | "sin_stock";

export interface Product {
  id: string;
  sku: string;
  barcode: string;
  slug: string;
  name: string;
  shortDescription: string;
  description: string;
  features: string[];
  categoryId: string;
  brandId: string;
  price: number;
  previousPrice?: number;
  cost?: number;
  stock: number;
  minStock: number;
  status: ProductStatus;
  featured: boolean;
  isNew: boolean;
  onOffer: boolean;
  images: string[];
  tags: string[];
  attributeValues?: ProductAttributeValue[];
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
}

export interface Brand {
  id: string;
  name: string;
  slug: string;
}

export interface CartItem {
  productId: string;
  quantity: number;
}

export type OrderStatus = "pendiente" | "confirmado" | "en_preparacion" | "listo" | "entregado" | "cancelado";
export type DeliveryMethod = "retiro" | "envio";
export type PaymentMethod = "efectivo" | "transferencia";

export interface ProductAttributeValue {
  attributeId: string;
  /** Copia del nombre del atributo al momento de asignarlo, para que se siga mostrando bien aunque después se edite o borre el atributo. */
  attributeName: string;
  value: string;
}

export interface Attribute {
  id: string;
  name: string;
  values: string[];
}

export type AttributeInput = Omit<Attribute, "id">;

export interface Customer {
  phone: string;
  name: string;
  orderCount: number;
  totalSpent: number;
  firstOrderAt: string;
  lastOrderAt: string;
}

export type AdminRole = "admin" | "editor";

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: AdminRole;
  active: boolean;
  createdAt: string;
}

export interface AdminUserInput {
  name: string;
  email: string;
  password: string;
  role: AdminRole;
}

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
}

export interface Order {
  id: string;
  orderNumber: number;
  customerName: string;
  customerPhone: string;
  deliveryMethod: DeliveryMethod;
  address?: string;
  paymentMethod: PaymentMethod;
  notes?: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  total: number;
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
}

export interface CreateOrderInput {
  customerName: string;
  customerPhone: string;
  deliveryMethod: DeliveryMethod;
  address?: string;
  paymentMethod: PaymentMethod;
  notes?: string;
  items: { productId: string; quantity: number }[];
}

export type CategoryInput = Omit<Category, "id">;
export type BrandInput = Omit<Brand, "id">;

export interface Branch {
  id: string;
  name: string;
  address: string;
  phone?: string;
  hours?: string;
  active: boolean;
}

export type BranchInput = Omit<Branch, "id">;

export interface SiteSettings {
  storeName: string;
  whatsappNumber: string;
  contactEmail: string;
  address: string;
  hours: string;
}

export type SiteSettingsInput = SiteSettings;

export interface AdminActivityEntry {
  id: string;
  message: string;
  date: string;
  type: "producto" | "categoria" | "marca" | "precio" | "pedido" | "sucursal" | "ajustes" | "atributo" | "usuario";
}

export type PriceUpdateType = "porcentaje" | "monto_fijo" | "precio_especifico";

/** 0 = sin redondeo. El resto son los múltiplos que pide el brief. */
export type RoundingOption = 0 | 10 | 50 | 100 | 500 | 1000;

export interface PriceHistoryEntry {
  id: string;
  date: string;
  user: string;
  type: PriceUpdateType | "csv";
  value: number;
  rounding?: RoundingOption;
  ruleName?: string;
  affectedProductIds: string[];
  previousPrices: Record<string, number>;
  reverted: boolean;
}

export interface PriceRule {
  id: string;
  name: string;
  /** Sin categoryId/brandId la regla aplica a todo el catálogo. */
  categoryId?: string;
  brandId?: string;
  type: PriceUpdateType;
  value: number;
  rounding: RoundingOption;
  active: boolean;
  createdAt: string;
  lastAppliedAt?: string;
}

export type PriceRuleInput = Omit<PriceRule, "id" | "createdAt" | "lastAppliedAt">;

export interface ProductImportRow {
  name: string;
  barcode: string;
  sku?: string;
  price: number;
  stock: number;
  categoryName?: string;
  brandName?: string;
  description?: string;
}

export interface ProductImportResult {
  createdCount: number;
  updatedCount: number;
  createdIds: string[];
  updatedIds: string[];
}
