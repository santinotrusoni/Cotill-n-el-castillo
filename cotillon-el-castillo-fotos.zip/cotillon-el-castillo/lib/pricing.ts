/**
 * pricing.ts
 * -----------------------------------------------------------------
 * Cálculos puros de actualización de precios. No tocan ningún store:
 * por eso el wizard (cliente) los usa para mostrar el preview en vivo,
 * y `mock-service.ts` (servidor) los reutiliza para aplicar el cambio
 * real — así el número que el admin ve en el preview es exactamente
 * el que se termina guardando.
 * -----------------------------------------------------------------
 */
import { PriceUpdateType, RoundingOption } from "@/lib/types";

export const ROUNDING_OPTIONS: RoundingOption[] = [0, 10, 50, 100, 500, 1000];

export function roundPrice(value: number, rounding: RoundingOption): number {
  const rounded = rounding > 0 ? Math.round(value / rounding) * rounding : Math.round(value);
  return Math.max(0, rounded);
}

export function computeNewPrice(
  currentPrice: number,
  type: PriceUpdateType,
  value: number,
  rounding: RoundingOption
): number {
  let next = currentPrice;
  if (type === "porcentaje") next = currentPrice * (1 + value / 100);
  else if (type === "monto_fijo") next = currentPrice + value;
  else next = value; // precio_especifico
  return roundPrice(next, rounding);
}

export function changeLabel(type: PriceUpdateType, value: number): string {
  if (type === "porcentaje") return `${value > 0 ? "+" : ""}${value}%`;
  if (type === "monto_fijo") return `${value > 0 ? "+" : ""}$${Math.abs(value).toLocaleString("es-AR")}`;
  return `precio fijo $${value.toLocaleString("es-AR")}`;
}
