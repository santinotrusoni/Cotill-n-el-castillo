import "server-only";
import { createClient } from "@supabase/supabase-js";

/**
 * supabase/server.ts
 * -----------------------------------------------------------------
 * Cliente de Supabase para usar SOLO desde el servidor (Server
 * Components, Server Actions, Route Handlers). Usa la service role
 * key, que tiene permisos completos e ignora Row Level Security —
 * por eso el import de "server-only" de arriba: si algún componente
 * "use client" llegara a importar este archivo por error, el build
 * de Next falla en vez de filtrar la key al navegador.
 *
 * Variables de entorno necesarias (ver .env.example):
 *   NEXT_PUBLIC_SUPABASE_URL
 *   SUPABASE_SERVICE_ROLE_KEY
 * -----------------------------------------------------------------
 */

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !serviceRoleKey) {
  throw new Error(
    "Faltan las variables de entorno de Supabase (NEXT_PUBLIC_SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY). " +
      "Revisá tu .env.local (o las Environment Variables del proyecto en Vercel/Netlify) — ver .env.example."
  );
}

export const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});
