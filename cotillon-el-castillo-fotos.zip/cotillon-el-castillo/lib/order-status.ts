import { OrderStatus } from "@/lib/types";

export const ORDER_STATUS_OPTIONS: { value: OrderStatus; label: string }[] = [
  { value: "pendiente", label: "Pendiente" },
  { value: "confirmado", label: "Confirmado" },
  { value: "en_preparacion", label: "En preparación" },
  { value: "listo", label: "Listo" },
  { value: "entregado", label: "Entregado" },
  { value: "cancelado", label: "Cancelado" },
];

export const ORDER_STATUS_TONE: Record<OrderStatus, string> = {
  pendiente: "bg-dorado/15 text-dorado",
  confirmado: "bg-borgona/10 text-borgona",
  en_preparacion: "bg-borgona/10 text-borgona",
  listo: "bg-exito/10 text-exito",
  entregado: "bg-exito/10 text-exito",
  cancelado: "bg-error/10 text-error",
};

export function formatOrderDate(iso: string): string {
  const d = new Date(iso);
  return `${d.toLocaleDateString("es-AR")} · ${d.toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" })}`;
}
