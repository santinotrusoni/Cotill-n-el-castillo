export function formatPrice(value: number): string {
  return value.toLocaleString("es-AR", {
    style: "currency",
    currency: "ARS",
    maximumFractionDigits: 0,
  });
}

export function discountPercent(price: number, previousPrice?: number): number {
  if (!previousPrice || previousPrice <= price) return 0;
  return Math.round(((previousPrice - price) / previousPrice) * 100);
}

/**
 * Genera una imagen placeholder consistente y con marca, ya que todavía
 * no hay fotos reales de producto. Reemplazar por URLs reales o Supabase
 * Storage cuando se conecte la base de datos.
 */
export function placeholderImage(label: string, w = 600, h = 600): string {
  const text = encodeURIComponent(label);
  return `https://placehold.co/${w}x${h}/DBCED0/2FAECD?text=${text}&font=roboto`;
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "");
}
