import "server-only";
import { cookies } from "next/headers";
import { ADMIN_SESSION_COOKIE, verifySessionToken, SessionPayload } from "@/lib/admin-session";

/** Para usar en Server Components/Actions — nunca en middleware.ts (ahí no existe next/headers). */
export async function getCurrentAdminUser(): Promise<SessionPayload | null> {
  const token = cookies().get(ADMIN_SESSION_COOKIE)?.value;
  return verifySessionToken(token);
}

/** Corta la acción si quien la llama no está logueado como "admin". Usar al principio de cualquier server action de Usuarios. */
export async function requireAdminRole(): Promise<SessionPayload> {
  const user = await getCurrentAdminUser();
  if (!user || user.role !== "admin") {
    throw new Error("No tenés permisos para hacer esto.");
  }
  return user;
}
