"use server";

import { supabaseAdmin } from "@/lib/supabase/server";
import { getCurrentAdminUser } from "@/lib/admin-current-user";

const BUCKET = "product-images";
const MAX_BYTES = 4 * 1024 * 1024; // el navegador ya reduce las fotos; esto es solo un tope de seguridad
const TYPES: Record<string, string> = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp" };

/**
 * Sube una imagen a Supabase Storage y devuelve su URL pública.
 * Solo para usuarios logueados en el admin. Si el bucket todavía no existe,
 * lo crea (público, para que las fotos se vean en la tienda).
 */
export async function uploadProductImageAction(formData: FormData): Promise<{ url?: string; error?: string }> {
  const user = await getCurrentAdminUser();
  if (!user) return { error: "Tu sesión venció. Volvé a ingresar al panel." };

  const file = formData.get("file");
  if (!(file instanceof File)) return { error: "No se recibió ningún archivo." };
  const ext = TYPES[file.type];
  if (!ext) return { error: "Formato no permitido. Usá JPG, PNG o WebP." };
  if (file.size > MAX_BYTES) return { error: "La imagen es demasiado pesada (máximo 4 MB)." };

  const path = `products/${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const body = Buffer.from(await file.arrayBuffer());
  const options = { contentType: file.type, cacheControl: "31536000", upsert: false };

  let { error } = await supabaseAdmin.storage.from(BUCKET).upload(path, body, options);

  if (error && /bucket not found/i.test(error.message)) {
    const created = await supabaseAdmin.storage.createBucket(BUCKET, { public: true });
    if (created.error && !/already exists/i.test(created.error.message)) {
      console.error("[upload] No se pudo crear el bucket:", created.error.message);
      return { error: "No se pudo preparar el almacenamiento de imágenes." };
    }
    ({ error } = await supabaseAdmin.storage.from(BUCKET).upload(path, body, options));
  }

  if (error) {
    console.error("[upload] Falló la subida:", error.message);
    return { error: "No pudimos subir la imagen. Probá de nuevo." };
  }

  const { data } = supabaseAdmin.storage.from(BUCKET).getPublicUrl(path);
  return { url: data.publicUrl };
}
