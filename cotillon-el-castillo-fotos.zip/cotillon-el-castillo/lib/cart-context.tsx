"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { CartItem, Product } from "@/lib/types";

const STORAGE_KEY = "cotillon-cart";

interface CartContextValue {
  items: CartItem[];
  isOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  addItem: (productId: string, quantity?: number) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  getProduct: (productId: string) => Product | undefined;
  itemCount: number;
  subtotal: number;
  discount: number;
  total: number;
}

const CartContext = createContext<CartContextValue | undefined>(undefined);

/**
 * `products` es el catálogo completo, obtenido server-side (ver
 * app/(tienda)/layout.tsx) y pasado como prop. Así ningún componente
 * cliente (CartDrawer, /carrito) necesita importar la capa de datos
 * directamente ni convertirse en async — el lookup es una simple
 * búsqueda en memoria sobre datos ya cargados.
 */
export function CartProvider({ children, products }: { children: React.ReactNode; products: Product[] }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  const productsById = useMemo(() => new Map(products.map((p) => [p.id, p])), [products]);
  const getProduct = useCallback((productId: string) => productsById.get(productId), [productsById]);

  // Carga inicial desde localStorage (solo en cliente).
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setItems(JSON.parse(raw));
    } catch {
      // localStorage no disponible o dato corrupto: arrancamos con carrito vacío.
    } finally {
      setHydrated(true);
    }
  }, []);

  // Persiste cada cambio.
  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, [items, hydrated]);

  const addItem = useCallback((productId: string, quantity = 1) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.productId === productId);
      if (existing) {
        return prev.map((i) =>
          i.productId === productId ? { ...i, quantity: i.quantity + quantity } : i
        );
      }
      return [...prev, { productId, quantity }];
    });
  }, []);

  const removeItem = useCallback((productId: string) => {
    setItems((prev) => prev.filter((i) => i.productId !== productId));
  }, []);

  const updateQuantity = useCallback((productId: string, quantity: number) => {
    setItems((prev) => {
      if (quantity <= 0) return prev.filter((i) => i.productId !== productId);
      return prev.map((i) => (i.productId === productId ? { ...i, quantity } : i));
    });
  }, []);

  const clearCart = useCallback(() => setItems([]), []);
  const openCart = useCallback(() => setIsOpen(true), []);
  const closeCart = useCallback(() => setIsOpen(false), []);

  const { itemCount, subtotal, discount, total } = useMemo(() => {
    let itemCount = 0;
    let subtotal = 0;
    let discount = 0;

    for (const item of items) {
      const product = productsById.get(item.productId);
      if (!product) continue;
      itemCount += item.quantity;
      subtotal += product.price * item.quantity;
      if (product.previousPrice && product.previousPrice > product.price) {
        discount += (product.previousPrice - product.price) * item.quantity;
      }
    }

    return { itemCount, subtotal, discount, total: subtotal };
  }, [items, productsById]);

  const value: CartContextValue = {
    items,
    isOpen,
    openCart,
    closeCart,
    addItem,
    removeItem,
    updateQuantity,
    clearCart,
    getProduct,
    itemCount,
    subtotal,
    discount,
    total,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart debe usarse dentro de <CartProvider>");
  return ctx;
}
