"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import bcrypt from "bcryptjs";
import { supabaseAdmin } from "@/lib/supabase/server";
import { ADMIN_SESSION_COOKIE, SESSION_MAX_AGE_SECONDS, createSessionToken } from "@/lib/admin-session";

/** Mensaje genérico a propósito: no le decimos al que intenta entrar si falló el email o la contraseña. */
const INVALID_CREDENTIALS_MESSAGE = "Email o contraseña incorrectos.";

export async function loginAction(email: string, password: string, next: string): Promise<{ error?: string } | void> {
  const normalizedEmail = email.trim().toLowerCase();
  const { data: user, error } = await supabaseAdmin
    .from("admin_users")
    .select("*")
    .eq("email", normalizedEmail)
    .maybeSingle();

  if (error || !user || !user.active) {
    return { error: INVALID_CREDENTIALS_MESSAGE };
  }

  const passwordMatches = await bcrypt.compare(password, user.password_hash);
  if (!passwordMatches) {
    return { error: INVALID_CREDENTIALS_MESSAGE };
  }

  const token = await createSessionToken({ userId: user.id, name: user.name, role: user.role });
  cookies().set(ADMIN_SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_MAX_AGE_SECONDS,
  });

  redirect(next && next.startsWith("/admin") ? next : "/admin");
}

export async function logoutAction(): Promise<void> {
  cookies().set(ADMIN_SESSION_COOKIE, "", { path: "/", maxAge: 0 });
  redirect("/admin/login");
}
