/**
 * admin-session.ts
 * -----------------------------------------------------------------
 * Reemplaza el passcode único por sesiones reales por usuario. La
 * "sesión" es un token firmado (HMAC-SHA256) que viaja en una cookie:
 * contiene quién es el usuario, su rol, y cuándo vence — sin necesidad
 * de consultar la base en cada request para validarlo.
 *
 * Usa únicamente Web Crypto (`crypto.subtle`), disponible tanto en el
 * runtime de Node (Server Actions) como en el Edge runtime
 * (middleware.ts) — por eso este archivo no importa nada de Node
 * (`node:crypto`, `Buffer`) ni de Next (`next/headers`), para poder
 * importarse desde cualquiera de los dos sin romper el build.
 *
 * Necesitás definir ADMIN_SESSION_SECRET (ver .env.example) — una
 * cadena larga y aleatoria. Generá una con, por ejemplo:
 *   openssl rand -base64 32
 * -----------------------------------------------------------------
 */
import { AdminRole } from "@/lib/types";

export const ADMIN_SESSION_COOKIE = "castillo_admin_session";
export const SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 7; // 7 días

export interface SessionPayload {
  userId: string;
  name: string;
  role: AdminRole;
  exp: number; // unix seconds
}

function toBase64Url(bytes: Uint8Array): string {
  let str = "";
  for (const b of bytes) str += String.fromCharCode(b);
  return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function fromBase64Url(value: string): Uint8Array {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((value.length + 3) % 4);
  const str = atob(padded);
  const bytes = new Uint8Array(str.length);
  for (let i = 0; i < str.length; i++) bytes[i] = str.charCodeAt(i);
  return bytes;
}

async function getKey(): Promise<CryptoKey> {
  const secret = process.env.ADMIN_SESSION_SECRET;
  if (!secret) {
    throw new Error(
      "Falta la variable de entorno ADMIN_SESSION_SECRET. Generá una (ej: `openssl rand -base64 32`) y agregala en .env.local y en Vercel/Netlify."
    );
  }
  return crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, [
    "sign",
    "verify",
  ]);
}

export async function createSessionToken(user: { userId: string; name: string; role: AdminRole }): Promise<string> {
  const payload: SessionPayload = { ...user, exp: Math.floor(Date.now() / 1000) + SESSION_MAX_AGE_SECONDS };
  const payloadBytes = new TextEncoder().encode(JSON.stringify(payload));
  const key = await getKey();
  const signature = await crypto.subtle.sign("HMAC", key, payloadBytes);
  return `${toBase64Url(payloadBytes)}.${toBase64Url(new Uint8Array(signature))}`;
}

export async function verifySessionToken(token: string | undefined | null): Promise<SessionPayload | null> {
  if (!token) return null;
  const [payloadPart, sigPart] = token.split(".");
  if (!payloadPart || !sigPart) return null;

  try {
    const key = await getKey();
    const payloadBytes = fromBase64Url(payloadPart);
    const signature = fromBase64Url(sigPart);
    const valid = await crypto.subtle.verify("HMAC", key, signature, payloadBytes);
    if (!valid) return null;

    const payload = JSON.parse(new TextDecoder().decode(payloadBytes)) as SessionPayload;
    if (payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch {
    return null;
  }
}
