/**
 * customer-session.ts
 * Sesión de clientes de la tienda: token firmado (HMAC-SHA256) en una cookie.
 * Usa la misma variable ADMIN_SESSION_SECRET, pero firma con una clave
 * derivada distinta ("<secreto>:customer") y el payload lleva kind="customer",
 * así un token de cliente NUNCA sirve como sesión de admin (ni al revés).
 */
export const CUSTOMER_SESSION_COOKIE = "castillo_customer_session";
export const CUSTOMER_SESSION_MAX_AGE = 60 * 60 * 24 * 30; // 30 días

export interface CustomerSession {
  kind: "customer";
  id: string;
  name: string;
  exp: number;
}

function toB64Url(bytes: Uint8Array): string {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function fromB64Url(v: string): Uint8Array {
  const padded = v.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((v.length + 3) % 4);
  const s = atob(padded);
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

async function getKey(): Promise<CryptoKey> {
  const secret = process.env.ADMIN_SESSION_SECRET;
  if (!secret) throw new Error("Falta la variable de entorno ADMIN_SESSION_SECRET (ver .env.example).");
  return crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(`${secret}:customer`),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"]
  );
}

export async function createCustomerToken(user: { id: string; name: string }): Promise<string> {
  const payload: CustomerSession = {
    kind: "customer",
    id: user.id,
    name: user.name,
    exp: Math.floor(Date.now() / 1000) + CUSTOMER_SESSION_MAX_AGE,
  };
  const bytes = new TextEncoder().encode(JSON.stringify(payload));
  const sig = await crypto.subtle.sign("HMAC", await getKey(), bytes);
  return `${toB64Url(bytes)}.${toB64Url(new Uint8Array(sig))}`;
}

export async function verifyCustomerToken(token: string | undefined | null): Promise<CustomerSession | null> {
  if (!token) return null;
  const [p, s] = token.split(".");
  if (!p || !s) return null;
  try {
    const bytes = fromB64Url(p);
    const ok = await crypto.subtle.verify("HMAC", await getKey(), fromB64Url(s), bytes);
    if (!ok) return null;
    const payload = JSON.parse(new TextDecoder().decode(bytes)) as CustomerSession;
    if (payload.kind !== "customer" || payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch {
    return null;
  }
}
