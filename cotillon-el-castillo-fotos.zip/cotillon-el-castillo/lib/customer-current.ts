import "server-only";
import { cookies } from "next/headers";
import { supabaseAdmin } from "@/lib/supabase/server";
import { CUSTOMER_SESSION_COOKIE, CustomerSession, verifyCustomerToken } from "@/lib/customer-session";

export interface CustomerAccount {
  id: string;
  name: string;
  email: string;
  phone: string;
}

/** Solo valida la cookie (sin consultar la base). Barato: sirve para el header. */
export async function getCustomerSession(): Promise<CustomerSession | null> {
  return verifyCustomerToken(cookies().get(CUSTOMER_SESSION_COOKIE)?.value);
}

/** Valida la cookie y trae los datos actuales de la cuenta. Devuelve null si ya no existe. */
export async function getCurrentCustomer(): Promise<CustomerAccount | null> {
  const session = await getCustomerSession();
  if (!session) return null;
  const { data } = await supabaseAdmin
    .from("customer_accounts")
    .select("id, name, email, phone")
    .eq("id", session.id)
    .maybeSingle();
  return data ?? null;
}
