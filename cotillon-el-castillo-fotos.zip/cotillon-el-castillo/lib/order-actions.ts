"use server";

import { revalidatePath } from "next/cache";
import * as service from "@/lib/mock-service";
import type { CreateOrderInput } from "@/lib/types";
import { getCurrentCustomer } from "@/lib/customer-current";

/**
 * Acción pública: la llama cualquier visitante desde /checkout, no
 * requiere estar en el admin. Vive separada de admin-actions.ts porque
 * conceptualmente no es una acción de administración.
 */
export async function createOrderAction(input: CreateOrderInput) {
  // El vínculo con la cuenta se saca de la cookie en el servidor, nunca de lo que mande el navegador.
  const account = await getCurrentCustomer();
  const order = await service.createOrder(input, account?.id);
  revalidatePath("/", "layout");
  return order;
}
