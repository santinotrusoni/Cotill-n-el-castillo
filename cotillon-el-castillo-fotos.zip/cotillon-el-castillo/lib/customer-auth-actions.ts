"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import bcrypt from "bcryptjs";
import { supabaseAdmin } from "@/lib/supabase/server";
import { CUSTOMER_SESSION_COOKIE, CUSTOMER_SESSION_MAX_AGE, createCustomerToken } from "@/lib/customer-session";

const INVALID = "Email o contraseña incorrectos.";
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** Solo rutas internas de la tienda: evita redirecciones a otros sitios o al admin. */
function safeNext(next: string): string {
  return next.startsWith("/") && !next.startsWith("//") && !next.startsWith("/admin") ? next : "/cuenta";
}

/**
 * Deja el detalle real en los logs del servidor (Vercel/terminal). En desarrollo
 * además lo muestra en pantalla; en producción el cliente ve un mensaje genérico.
 */
function dbFailure(where: string, error: { message: string; code?: string }): string {
  console.error(`[cuentas] Falló ${where}:`, error.code, error.message);
  const base = "No pudimos crear tu cuenta. Probá de nuevo en un momento.";
  return process.env.NODE_ENV === "production" ? base : `${base} (${error.code ?? ""} ${error.message})`;
}

async function startSession(user: { id: string; name: string }) {
  const token = await createCustomerToken(user);
  cookies().set(CUSTOMER_SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: CUSTOMER_SESSION_MAX_AGE,
  });
}

export async function registerCustomerAction(
  input: { name: string; email: string; phone: string; password: string },
  next: string
): Promise<{ error?: string } | void> {
  const name = input.name.trim();
  const email = input.email.trim().toLowerCase();
  const phone = input.phone.trim();

  if (name.length < 2) return { error: "Ingresá tu nombre." };
  if (!EMAIL_RE.test(email)) return { error: "Ingresá un email válido." };
  if (phone.replace(/\D/g, "").length < 8) return { error: "Ingresá un teléfono válido." };
  if (input.password.length < 8) return { error: "La contraseña debe tener al menos 8 caracteres." };

  const { data: existing, error: lookupError } = await supabaseAdmin
    .from("customer_accounts")
    .select("id")
    .eq("email", email)
    .maybeSingle();
  if (lookupError) return { error: dbFailure("registro (buscar email)", lookupError) };
  if (existing) return { error: "Ya existe una cuenta con ese email. Probá ingresando." };

  const id = `cust_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
  const password_hash = await bcrypt.hash(input.password, 10);
  const { error } = await supabaseAdmin.from("customer_accounts").insert({ id, name, email, phone, password_hash });
  if (error) {
    if (error.code === "23505") return { error: "Ya existe una cuenta con ese email. Probá ingresando." };
    return { error: dbFailure("registro (crear cuenta)", error) };
  }

  await startSession({ id, name });
  redirect(safeNext(next));
}

export async function loginCustomerAction(
  email: string,
  password: string,
  next: string
): Promise<{ error?: string } | void> {
  const { data: user } = await supabaseAdmin
    .from("customer_accounts")
    .select("id, name, password_hash")
    .eq("email", email.trim().toLowerCase())
    .maybeSingle();

  if (!user || !(await bcrypt.compare(password, user.password_hash))) return { error: INVALID };

  await startSession({ id: user.id, name: user.name });
  redirect(safeNext(next));
}

export async function logoutCustomerAction(): Promise<void> {
  cookies().set(CUSTOMER_SESSION_COOKIE, "", { path: "/", maxAge: 0 });
  redirect("/");
}
