"use server";

import { revalidatePath } from "next/cache";
import * as service from "@/lib/mock-service";
import type { ProductInput, ApplyPriceUpdateInput } from "@/lib/mock-service";
import type { CategoryInput, BrandInput, PriceRuleInput, ProductImportRow } from "@/lib/types";
import type { OrderStatus, BranchInput, SiteSettingsInput, AttributeInput } from "@/lib/types";
import type { AdminUserInput } from "@/lib/types";
import type { UpdateAdminUserInput } from "@/lib/mock-service";
import { requireAdminRole } from "@/lib/admin-current-user";

/**
 * Todas las acciones de esta capa mutan el mock-service y después
 * invalidan el cache de Next para toda la app ("layout" = raíz), así
 * el panel admin y la tienda pública reflejan el cambio en la misma
 * sesión del servidor sin necesidad de recargar manualmente.
 */
function revalidateAll() {
  revalidatePath("/", "layout");
}

/* ----------------------------- Productos ----------------------------- */

export async function createProductAction(input: ProductInput) {
  const product = await service.createProduct(input);
  revalidateAll();
  return product;
}

export async function updateProductAction(id: string, input: Partial<ProductInput>) {
  const product = await service.updateProduct(id, input);
  revalidateAll();
  return product;
}

export async function deleteProductAction(id: string) {
  await service.deleteProduct(id);
  revalidateAll();
}

export async function toggleProductStatusAction(id: string) {
  const product = await service.getProductById(id);
  if (!product) throw new Error("Producto no encontrado.");
  const nextStatus = product.status === "activo" ? "inactivo" : "activo";
  const updated = await service.updateProduct(id, { status: nextStatus });
  revalidateAll();
  return updated;
}

/* ----------------------------- Categorías ----------------------------- */

export async function createCategoryAction(input: CategoryInput) {
  const category = await service.createCategory(input);
  revalidateAll();
  return category;
}

export async function updateCategoryAction(id: string, input: Partial<CategoryInput>) {
  const category = await service.updateCategory(id, input);
  revalidateAll();
  return category;
}

export async function deleteCategoryAction(id: string) {
  await service.deleteCategory(id);
  revalidateAll();
}

/* ------------------------------- Marcas -------------------------------- */

export async function createBrandAction(input: BrandInput) {
  const brand = await service.createBrand(input);
  revalidateAll();
  return brand;
}

export async function updateBrandAction(id: string, input: Partial<BrandInput>) {
  const brand = await service.updateBrand(id, input);
  revalidateAll();
  return brand;
}

export async function deleteBrandAction(id: string) {
  await service.deleteBrand(id);
  revalidateAll();
}

/* ------------------------ Actualización de precios ------------------------ */

export async function applyPriceUpdateAction(input: ApplyPriceUpdateInput) {
  const entry = await service.applyPriceUpdate(input);
  revalidateAll();
  return entry;
}

export async function revertPriceUpdateAction(historyId: string) {
  const entry = await service.revertPriceUpdate(historyId);
  revalidateAll();
  return entry;
}

/* --------------------------- Reglas automáticas ---------------------------- */

export async function createPriceRuleAction(input: PriceRuleInput) {
  const rule = await service.createPriceRule(input);
  revalidateAll();
  return rule;
}

export async function updatePriceRuleAction(id: string, input: Partial<PriceRuleInput>) {
  const rule = await service.updatePriceRule(id, input);
  revalidateAll();
  return rule;
}

export async function deletePriceRuleAction(id: string) {
  await service.deletePriceRule(id);
  revalidateAll();
}

export async function applyPriceRuleNowAction(id: string) {
  const entry = await service.applyPriceRuleNow(id);
  revalidateAll();
  return entry;
}

/* ------------------------------ Importación CSV ------------------------------ */

export async function bulkImportProductsAction(rows: ProductImportRow[]) {
  const result = await service.bulkImportProducts(rows);
  revalidateAll();
  return result;
}

/* -------------------------------- Pedidos -------------------------------- */

export async function updateOrderStatusAction(id: string, status: OrderStatus) {
  const order = await service.updateOrderStatus(id, status);
  revalidateAll();
  return order;
}

/* ------------------------------ Sucursales ------------------------------ */

export async function createBranchAction(input: BranchInput) {
  const branch = await service.createBranch(input);
  revalidateAll();
  return branch;
}

export async function updateBranchAction(id: string, input: Partial<BranchInput>) {
  const branch = await service.updateBranch(id, input);
  revalidateAll();
  return branch;
}

export async function deleteBranchAction(id: string) {
  await service.deleteBranch(id);
  revalidateAll();
}

/* -------------------------------- Ajustes -------------------------------- */

export async function updateSiteSettingsAction(input: SiteSettingsInput) {
  await requireAdminRole();
  const settings = await service.updateSiteSettings(input);
  revalidateAll();
  return settings;
}

/* ------------------------------- Atributos ------------------------------- */

export async function createAttributeAction(input: AttributeInput) {
  const attribute = await service.createAttribute(input);
  revalidateAll();
  return attribute;
}

export async function updateAttributeAction(id: string, input: Partial<AttributeInput>) {
  const attribute = await service.updateAttribute(id, input);
  revalidateAll();
  return attribute;
}

export async function deleteAttributeAction(id: string) {
  await service.deleteAttribute(id);
  revalidateAll();
}

/* -------------------------------- Usuarios -------------------------------- */
/* Cada una revalida el rol del que llama server-side — no alcanza con
   ocultar el botón en la UI, porque un server action se puede invocar
   directamente sin pasar por la pantalla. */

export async function createAdminUserAction(input: AdminUserInput) {
  await requireAdminRole();
  const user = await service.createAdminUser(input);
  revalidateAll();
  return user;
}

export async function updateAdminUserAction(id: string, input: UpdateAdminUserInput) {
  const currentUser = await requireAdminRole();
  if (currentUser.userId === id && input.active === false) {
    throw new Error("No podés desactivar tu propia cuenta.");
  }
  const user = await service.updateAdminUser(id, input);
  revalidateAll();
  return user;
}

export async function deleteAdminUserAction(id: string) {
  const currentUser = await requireAdminRole();
  if (currentUser.userId === id) {
    throw new Error("No podés eliminar tu propia cuenta.");
  }
  await service.deleteAdminUser(id);
  revalidateAll();
}
