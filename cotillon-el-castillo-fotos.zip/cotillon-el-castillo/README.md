# Cotillón El Castillo — Fase 1 a Fase 6 + Base de datos (Supabase)

eCommerce + panel admin para Cotillón "El Castillo" (Villa Dominico, Buenos Aires).
Stack: **Next.js 14 (App Router) + TypeScript + Tailwind CSS + Supabase (Postgres)**.

⚠️ **Antes de correrlo necesitás un proyecto de Supabase conectado** — ver
la sección "Base de datos real (Supabase)" más abajo. Sin las variables de
entorno configuradas, la app no arranca (falla a propósito con un mensaje
claro, en vez de fallar en silencio).

## Cómo correrlo local

```bash
npm install
```

Configurá `.env.local` (ver sección de Supabase más abajo y `.env.example`), después:

```bash
npm run dev
```

Abrí `http://localhost:3000`.

## Cómo deployarlo (demo para el cliente)

**Vercel (recomendado, cero config):**
1. Subí esta carpeta a un repo de GitHub.
2. Entrá a vercel.com → "Add New Project" → importá el repo.
3. Framework Preset: detecta Next.js automáticamente. Deploy.

**Netlify:**
1. Mismo repo en GitHub.
2. "Add new site" → "Import an existing project".
3. Build command: `npm run build` — Publish directory: `.next`
   (agregá el plugin oficial `@netlify/plugin-nextjs`, Netlify lo sugiere solo).

No hace falta configurar variables de entorno ni base de datos para esta fase.

## Qué incluye esta entrega (Fase 1)

- Setup completo del proyecto (Next.js + TS + Tailwind, paleta e identidad de marca).
- Capa de datos mock (`/data`) + capa de servicio (`/lib/mock-service.ts`) — el
  resto de la app **nunca** importa `/data` directamente, siempre pasa por el
  servicio. Esto es clave: el día de mañana reemplazamos las funciones de
  `mock-service.ts` por llamadas a Supabase/API y ningún componente cambia.
- 22 productos de demostración (con destacados, ofertas, sin stock, nuevos),
  10 categorías, 4 marcas.
- Header (nav, buscador, acceso a carrito y escáner, menú mobile), Footer.
- Home completa: Hero, Beneficios, Destacados, Ofertas.
- Componentes reutilizables: `ProductCard`, `PriceBadge`, `StockBadge`.

## Qué se agregó en la Fase 2

- **Carrito real** (`lib/cart-context.tsx`): Context API + persistencia en
  `localStorage`. Agregar, restar, eliminar y vaciar funcionan de punta a
  punta y se mantienen al recargar la página.
- **Drawer de carrito** (panel lateral) accesible desde el ícono del Header
  en cualquier página, sin perder el contexto de navegación.
- **`/productos`** — catálogo completo con filtros combinables (categoría,
  marca, rango de precio, disponibilidad, oferta, destacados), buscador,
  orden (relevancia / precio / más nuevos), chips de filtros activos con
  opción de quitar cada uno, y drawer de filtros en mobile.
- **`/productos/[slug]`** — detalle de producto con galería, selector de
  cantidad (limitado por stock real), descripción, características,
  breadcrumb y productos relacionados de la misma categoría.
- **`/carrito`** — página completa de carrito con resumen de compra y
  **checkout funcional por WhatsApp** (arma el mensaje con el detalle del
  pedido y el total). Reemplazá `WHATSAPP_NUMBER` en
  `app/carrito/page.tsx` por el número real del negocio.
- **`/ofertas`, `/destacados`, `/novedades`, `/categorias`** — reutilizan el
  mismo catálogo con un filtro preseteado, para que ningún link del
  Header/Footer quede roto.

## Qué se agregó en la Fase 3

- **`/escanear`** — escáner de código de barras funcional de punta a punta:
  - **Cámara en vivo** (`components/scanner/BarcodeScanner.tsx`) usando
    [`@zxing/browser`](https://www.npmjs.com/package/@zxing/browser): pide
    permiso, prioriza la cámara trasera en celulares, y decodifica en
    background formatos EAN-13, EAN-8, UPC-A, UPC-E, CODE-128 y CODE-39
    (los formatos habituales en productos de góndola). Marco visual con
    línea de escaneo animada mientras busca el código.
  - **Ingreso manual** siempre visible y funcional, incluso si la cámara
    falla o no está disponible — usa el mismo `getProductByBarcode()` del
    mock-service.
  - **Manejo de estados real**: idle → escaneando → encontrado / no
    encontrado / error de cámara, cada uno con su propia pantalla (nunca un
    `alert()`).
  - **Resultado del escaneo**: card con imagen, precio, stock, SKU, código
    de barras, descripción y características, con botones para agregar al
    carrito (usa el mismo `cart-context`) o ir al detalle del producto.
  - Reemplazá `getProductByBarcode` en `lib/mock-service.ts` por la consulta
    real cuando conectes base de datos; el componente no cambia.

## Qué se agregó en la Fase 4 — Panel `/admin`

**Arquitectura:** la tienda pública se movió a un route group
`app/(tienda)/` y `/admin` tiene su **propio layout raíz** (`<html>`/`<body>`
independientes) — por eso el admin no arrastra el Header/Footer de la
tienda y puede tener un diseño completamente distinto (sidebar oscura +
contenido claro), tal como pide el brief. Esto no cambia ninguna URL: `/`,
`/productos`, etc. siguen funcionando igual.

**CRUD real, no maquetas:**

- `lib/mock-service.ts` pasó de ser solo lectura a un **store mutable en
  memoria** con `createProduct/updateProduct/deleteProduct`,
  `createCategory/updateCategory/deleteCategory`,
  `createBrand/updateBrand/deleteBrand`, más `getDashboardStats()` y
  `getRecentActivity()`. Sigue siendo el único punto de acceso a datos.
- `lib/admin-actions.ts` son **Server Actions** de Next.js que llaman al
  servicio y revalidan toda la app (`revalidatePath("/", "layout")`) — como
  el store es compartido, un producto creado/editado en el admin se refleja
  también en la tienda pública dentro de la misma sesión del servidor.
- ⚠️ **Importante para producción real:** sin base de datos, este estado
  vive en la memoria del proceso. Anda perfecto en `npm run dev` o en un
  server Node persistente; en hosting serverless (Vercel/Netlify) cada
  request puede caer en una instancia distinta y los cambios podrían no
  persistir entre requests. Conectar Supabase reemplazando las funciones de
  `mock-service.ts` (mismo contrato) resuelve esto sin tocar la UI.

**Qué incluye:**

- **Dashboard (`/admin`)** — métricas reales (no inventadas) calculadas al
  vuelo desde el catálogo: total de productos, en stock, sin stock,
  categorías, destacados, ofertas activas; gráfico de stock por categoría;
  lista de productos sin stock con acceso directo a reponer; y un feed de
  **actividad reciente** que registra cada alta/edición/baja que hagas en
  la sesión.
- **`/admin/productos`** — tabla con búsqueda (nombre, SKU, código de
  barras), filtros combinables (categoría, marca, estado) y paginación real
  vía query params; activar/desactivar, editar y eliminar (con
  confirmación) desde cada fila.
- **`/admin/productos/nuevo` y `/admin/productos/[id]/editar`** —
  formulario completo (info, precio, stock, imágenes, organización) con
  validación real de campos obligatorios, cálculo automático de % de
  descuento, gestión de imágenes (agrega placeholders con marca — no hay
  upload real todavía) y **botón "Escanear código"** que abre la cámara
  (reutiliza el componente de la Fase 3) para autocompletar el código de
  barras.
- **`/admin/categorias` y `/admin/marcas`** — CRUD completo vía modal, con
  conteo de productos por categoría/marca y bloqueo de borrado si hay
  productos asignados (para no dejar productos huérfanos).
- **`/admin/ofertas`** — vista de todos los productos marcados como oferta.
- **`/admin/escanear`** — escáner en el admin: si el código existe te lleva
  directo a editar ese producto; si no existe, te ofrece crear un producto
  nuevo con el código ya cargado.
- **Toasts propios del admin** (`lib/admin-toast-context.tsx`) para
  confirmar cada acción, sin un solo `alert()`.
- **Sin login todavía** — no hay autenticación real (se documenta como
  pendiente); la estructura (rutas separadas, layout propio) ya está lista
  para agregarla sin refactor.
- **Secciones con "Pronto"** (Pedidos, Clientes, Atributos, Usuarios,
  Ajustes, Sucursales) y las de fases ya planificadas (Importación,
  Exportación, Actualización de precios) están en el sidebar con una
  pantalla "Próximamente" en vez de un link roto.

## Qué se agregó en la Fase 5 — Actualización masiva de precios

**Nueva capa de cálculo puro (`lib/pricing.ts`):** `computeNewPrice()` y
`roundPrice()` no tocan ningún store — el wizard (cliente) las usa para
mostrar el preview en vivo mientras el admin todavía no confirmó nada, y
`mock-service.ts` (servidor) reutiliza exactamente las mismas funciones al
aplicar el cambio real. Así el número que ves en el preview es siempre el
que se termina guardando, nunca una aproximación.

- **`/admin/precios`** — wizard de 3 pasos, tal como pide el brief:
  1. **Seleccionar productos**: todos / una categoría / una marca /
     selección manual (checklist con buscador y "seleccionar visibles"),
     combinable con filtros de estado, disponibilidad, rango de precio,
     oferta y destacados. Muestra en vivo cuántos productos coinciden.
  2. **Método de actualización**: porcentaje, monto fijo o precio
     específico, con **redondeo** opcional a $10/$50/$100/$500/$1.000, y un
     ejemplo en vivo con el primer producto seleccionado.
  3. **Revisar y confirmar**: preview producto por producto (precio actual
     → nuevo, con el % de cambio) y un resumen con seleccionados, en
     stock/sin stock, precio total actual, nuevo total y diferencia — igual
     al ejemplo del brief. **Nada se modifica** hasta confirmar en un
     diálogo que dice explícitamente cuántos productos se van a ver
     afectados.
- **`/admin/precios/historial`** — cada actualización aplicada queda
  registrada (fecha, usuario, tipo de cambio, productos afectados) con un
  detalle producto por producto (precio anterior vs. actual) y un botón
  **Revertir** que devuelve cada producto a su precio previo — funciona
  aunque hayan pasado varias actualizaciones intermedias, porque cada
  entrada del historial guarda su propio mapa de precios anteriores.
- **`/admin/precios/reglas`** — reglas reutilizables ("Aumento Cotillón:
  +10%, categoría Cotillón, redondeo a $50") que podés activar/desactivar y
  disparar con un botón **Aplicar ahora**: usan la misma función
  `applyPriceUpdate()` de la actualización manual, así que también quedan
  en el historial y se pueden revertir igual que cualquier otra.
- Todo vive en `mock-service.ts` (mismo patrón que productos/categorías):
  `applyPriceUpdate`, `revertPriceUpdate`, `getPriceHistory`,
  `createPriceRule/updatePriceRule/deletePriceRule`, `applyPriceRuleNow` —
  con sus Server Actions correspondientes en `lib/admin-actions.ts`.

## Qué se agregó en la Fase 6 — Import/export CSV, responsive y verificación final

- **`/admin/importar`** — wizard de 3 pasos para carga masiva vía CSV: subir
  archivo (drag & drop o selector), mapear columnas del archivo a los campos
  del sistema (con auto-detección por nombre de columna), y una tabla de
  preview con validación fila por fila —
  <span style="color:#4C7A57">●</span> válidos,
  <span style="color:#C9A227">●</span> con advertencias (categoría/marca no
  encontrada → usa un fallback, o código de barras que ya existe → va a
  actualizar en vez de crear) y
  <span style="color:#C15B5B">●</span> con errores (se omiten
  automáticamente). Matchea por código de barras: si ya existe, actualiza el
  producto; si no, lo crea.
- **`/admin/exportar`** — descarga el catálogo en CSV (con filtro por
  categoría, marca, ofertas, destacados o sin stock) más botones rápidos
  para exportar categorías y marcas. Los CSV llevan BOM UTF-8 para que Excel
  muestre bien los acentos.
- **`lib/csv.ts`** — parser/generador de CSV propio (soporta comillas, comas
  y saltos de línea dentro de un campo), sin dependencias externas, para no
  agregar peso innecesario solo para esto.
- **`/contacto`** ya no es un 404: formulario de contacto con validación y
  mensaje de confirmación, más los datos de ubicación/horario/WhatsApp que
  ya vivían en el footer.
- **Pulido responsive y verificación final**: se revisaron todas las tablas
  del admin (precios, historial, importación, marcas) para que scrolleen
  horizontalmente en mobile en vez de romper el layout; se confirmó que no
  quedan enlaces del sidebar apuntando a rutas inexistentes (las secciones
  fuera de alcance — Pedidos, Clientes, Atributos, Usuarios, Ajustes,
  Sucursales — muestran una pantalla "Próximamente" en lugar de un 404); y
  se corrió el chequeo de tipos de todo el proyecto sin errores.

## `/admin` protegido — arquitectura de rutas

`/admin` está protegido desde el día que se compartió la primera demo
(hoy con cuentas reales, ver la sección "Usuarios" más abajo — al
principio fue un passcode único, ya reemplazado por completo).

- `middleware.ts` protege todas las rutas `/admin/*` — sin sesión válida,
  redirige a `/admin/login`.
- `/admin/login` vive fuera del grupo de rutas protegido, con su propio
  layout liviano sin sidebar.
- Botón de **Cerrar sesión** en el header del admin.

Los grupos de rutas de `/admin` están organizados así:
`app/admin/(dashboard)/...` agrupa todas las secciones protegidas (con
sidebar), mientras `app/admin/login` queda afuera de ese grupo — la URL no
cambia (`/admin`, `/admin/productos`, etc. siguen igual), solo cambió cómo
están organizadas las carpetas internamente.

## Roadmap

Con la Fase 6 se cierra el roadmap original de 6 fases. Sobre esa base ya
se agregaron: cuentas de usuario reales (con roles), base de datos real,
Pedidos + checkout, Ajustes + Sucursales, y Atributos + Clientes. Con
Usuarios se completaron las 6 secciones que en su momento decían
"Próximamente" en el sidebar del admin.

## Pedidos + checkout real

Ya no es solo "armá el carrito y mandá un WhatsApp": el carrito ahora puede
convertirse en un pedido de verdad, guardado en Supabase.

**Si ya corriste `schema.sql` antes** (proyecto existente), correspondé
correr **además** `supabase/migration-orders.sql` en el SQL Editor —
agrega solamente la tabla `orders`, no toca nada de lo que ya tenías. Si
es un proyecto nuevo, con correr `schema.sql` (que ya incluye `orders`)
alcanza.

- **`/checkout`** — formulario de datos del cliente (nombre, teléfono),
  entrega (retiro en local / envío con dirección) y método de pago
  (efectivo / transferencia — todavía no hay pasarela de pago online, el
  pago se coordina directamente con el local). Al confirmar, crea el
  pedido en la base con los precios recalculados server-side (nunca
  confía en lo que mande el navegador) y descuenta stock automáticamente.
- **`/pedido/[id]`** — confirmación con el resumen del pedido y un botón
  para confirmarlo por WhatsApp con el local (mismo número que configurás
  en `/admin/ajustes`).
- **`/admin/pedidos`** — lista de todos los pedidos con cambio de estado
  inline (pendiente → confirmado → en preparación → listo → entregado, o
  cancelado). **`/admin/pedidos/[id]`** tiene el detalle completo.
- El carrito (`/carrito`) mantiene el botón de WhatsApp como opción rápida,
  pero ahora "Finalizar pedido" es el flujo principal.

## Atributos + Clientes (+ fix de un bug de la migración)

- **`/admin/atributos`** — atributos reutilizables tipo "Color" con una
  lista de valores posibles ("Rojo, Azul, Verde"). Se asignan a un
  producto desde su formulario de edición (nueva sección "Atributos") y
  se muestran en el detalle del producto en la tienda como
  especificaciones estructuradas, separadas de las características libres
  que ya existían. Por ahora es descriptivo — no arma variantes con stock
  o precio independiente por combinación (eso sería un cambio de
  arquitectura mucho más grande, tipo "talles y colores" de un ecommerce
  de indumentaria).
- **`/admin/clientes`** — como no hay cuentas de cliente ni login (el
  checkout es "de invitado"), un cliente acá es simplemente el conjunto de
  pedidos que comparten el mismo teléfono. Se arma solo a partir de la
  tabla de pedidos, sin tabla ni datos de mentira aparte. Click en un
  cliente para ver su historial completo de pedidos.
- **Bug fix**: el campo "Costo" del formulario de producto existía desde
  antes de conectar Supabase, pero la migración nunca le agregó su columna
  a la base — se guardaba en el navegador y se perdía en silencio al
  confirmar. Ya está arreglado (ver `supabase/migration-atributos.sql`,
  que también agrega los atributos).

**Si tu proyecto ya existe**, correspondé correr
`supabase/migration-atributos.sql` en el SQL Editor. Como con las demás
migraciones, un proyecto nuevo ya lo tiene todo en `schema.sql`.

## Usuarios — cuentas reales, reemplaza el passcode único

Esta es la más grande de las funciones agregadas después del roadmap
original: `/admin` ya no se protege con un código único compartido, sino
con cuentas individuales (nombre, email, contraseña, rol).

- **Dos roles**: `admin` (acceso completo) y `editor` (todo excepto
  Usuarios y Ajustes — esas dos secciones ni siquiera aparecen en su
  sidebar, y si entran a la URL a mano les tira 404).
- **`/admin/usuarios`** — crear usuarios, cambiar su rol, activar/
  desactivar, restablecer contraseña o eliminarlos. Nadie puede
  desactivarse ni eliminarse a sí mismo (protección tanto en la UI como
  en el server action, para que no se pueda saltear).
- **Sesión real**: al loguearse se firma un token (HMAC-SHA256) con los
  datos de la sesión — no hay contraseñas ni sesiones guardadas en texto
  plano en ningún lado más que el hash en la base. Dura 7 días o hasta
  que cierres sesión.

### Cómo migrar si ya tenías el passcode viejo

1. Corré `supabase/migration-usuarios.sql` en el SQL Editor (crea la
   tabla `admin_users`, vacía a propósito).
2. Reemplazá la variable de entorno `ADMIN_PASSCODE` por
   `ADMIN_SESSION_SECRET` (una cadena larga y aleatoria — generá una con
   `openssl rand -base64 32`) tanto en `.env.local` como en Vercel/Netlify.
3. Con las variables de Supabase ya configuradas en tu `.env.local`, corré:
   ```bash
   npm run create-admin
   ```
   Te va a pedir nombre, email y contraseña por consola y te crea el
   primer usuario con rol `admin`. Repetilo (o usá `/admin/usuarios` una
   vez que puedas entrar) para crear más cuentas.
4. Redeploy (`npx vercel --prod`) — a partir de ahí, `/admin/login` pide
   email y contraseña en vez del código único.

## Base de datos real (Supabase) — ya está conectada

El catálogo, el historial de precios, las reglas automáticas y el log de
actividad ya NO viven en memoria: `lib/mock-service.ts` habla con Supabase
(Postgres) a través de `lib/supabase/server.ts`. Los datos de `/data/*.ts`
quedaron solo como fuente para generar el seed inicial (ver más abajo) —
ya no los usa la app en tiempo de ejecución.

### 1. Correr el schema en tu proyecto de Supabase

En tu proyecto → **SQL Editor** → **New query**, pegá y corré, EN ESTE ORDEN:

1. Todo el contenido de `supabase/schema.sql` (crea las tablas, índices y
   políticas de lectura pública del catálogo).
2. Todo el contenido de `supabase/seed.sql` (carga las 10 categorías, 4
   marcas y 22 productos de muestra que ya traía la app).

Si más adelante cambiás los datos de ejemplo en `/data/*.ts` y querés
regenerar `seed.sql`, corré `npm run export-seed`.

### 2. Variables de entorno

En **Project Settings → API** de tu proyecto de Supabase vas a encontrar:

- **Project URL** → va en `NEXT_PUBLIC_SUPABASE_URL`
- **service_role key** (no la `anon public`) → va en `SUPABASE_SERVICE_ROLE_KEY`

Agregalas:

- En desarrollo local: creá un archivo `.env.local` (no se sube a git) con
  esas dos variables más `ADMIN_PASSCODE` — mirá `.env.example` como
  referencia.
- En Vercel/Netlify: Settings → Environment Variables, las tres variables,
  en Production **y** Preview.

**Importante**: `SUPABASE_SERVICE_ROLE_KEY` tiene acceso total a la base y
salta cualquier política de seguridad — por eso `lib/supabase/server.ts`
usa el paquete `server-only`, que rompe el build si algún componente
`"use client"` llegara a importarlo por error. Nunca la pongas en una
variable que empiece con `NEXT_PUBLIC_`.

### 3. Redeploy

Con las variables ya configuradas, `npx vercel --prod` (o el redeploy
automático si conectaste GitHub). A partir de ahí, cualquier producto que
cargues, precio que actualices o categoría que edites desde `/admin` queda
guardado de verdad — sobrevive a un redeploy y a que se reinicie el
servidor, cosa que con los datos en memoria no pasaba.

### Notas sobre el diseño

- Los IDs siguen siendo texto legible (`prod_xxxxx`, no UUIDs) para no
  tocar ninguna lógica de la UI que ya asumía este formato.
- Las páginas de la tienda y del admin están marcadas
  `export const dynamic = "force-dynamic"` en sus layouts — así un cambio
  hecho en `/admin` se ve reflejado al instante en la tienda pública, en
  vez de quedar cacheado estáticamente por Next.
- La actualización masiva de precios y la importación CSV hacen un único
  `upsert` en bloque en vez de una consulta por producto — más rápido y
  evita quedar a mitad de camino si algo falla.
- El carrito y el escáner de código de barras corren en el navegador, así
  que reciben el catálogo ya cargado como prop desde el Server Component
  más cercano (nunca importan la capa de datos directamente) — así ninguna
  credencial de Supabase puede terminar expuesta en el bundle del cliente.
