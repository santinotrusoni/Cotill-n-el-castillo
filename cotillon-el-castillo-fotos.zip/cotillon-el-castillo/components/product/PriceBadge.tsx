import { formatPrice, discountPercent } from "@/lib/utils";

export function PriceBadge({
  price,
  previousPrice,
  size = "md",
}: {
  price: number;
  previousPrice?: number;
  size?: "sm" | "md" | "lg";
}) {
  const discount = discountPercent(price, previousPrice);
  const priceClass = size === "lg" ? "text-2xl" : size === "sm" ? "text-base" : "text-lg";

  return (
    <div className="flex flex-wrap items-baseline gap-2">
      <span className={`font-display font-semibold text-carbon ${priceClass}`}>
        {formatPrice(price)}
      </span>
      {discount > 0 && previousPrice && (
        <>
          <span className="text-sm text-carbon/40 line-through">{formatPrice(previousPrice)}</span>
          <span className="rounded-full bg-dorado/15 px-2 py-0.5 text-xs font-semibold text-[#676A37]">
            -{discount}%
          </span>
        </>
      )}
    </div>
  );
}
