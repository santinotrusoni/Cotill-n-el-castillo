"use client";

import { Category, Brand } from "@/lib/types";
import { formatPrice } from "@/lib/utils";

export interface CatalogFilters {
  categoryIds: string[];
  brandIds: string[];
  minPrice: number;
  maxPrice: number;
  availability: "todos" | "en_stock" | "sin_stock";
  onOfferOnly: boolean;
  featuredOnly: boolean;
}

export const PRICE_FLOOR = 0;
export const PRICE_CEILING = 50000;

export const DEFAULT_FILTERS: CatalogFilters = {
  categoryIds: [],
  brandIds: [],
  minPrice: PRICE_FLOOR,
  maxPrice: PRICE_CEILING,
  availability: "todos",
  onOfferOnly: false,
  featuredOnly: false,
};

function toggle<T>(list: T[], value: T): T[] {
  return list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
}

export function ProductFilters({
  categories,
  brands,
  filters,
  onChange,
}: {
  categories: Category[];
  brands: Brand[];
  filters: CatalogFilters;
  onChange: (filters: CatalogFilters) => void;
}) {
  return (
    <div className="flex flex-col gap-6">
      <fieldset>
        <legend className="mb-3 text-sm font-semibold text-carbon">Categorías</legend>
        <div className="flex flex-col gap-2">
          {categories.map((cat) => (
            <label key={cat.id} className="flex items-center gap-2 text-sm text-carbon/80">
              <input
                type="checkbox"
                checked={filters.categoryIds.includes(cat.id)}
                onChange={() =>
                  onChange({ ...filters, categoryIds: toggle(filters.categoryIds, cat.id) })
                }
                className="h-4 w-4 rounded border-crema-dark text-borgona focus:ring-borgona"
              />
              {cat.name}
            </label>
          ))}
        </div>
      </fieldset>

      <fieldset>
        <legend className="mb-3 text-sm font-semibold text-carbon">Precio</legend>
        <div className="flex flex-col gap-2">
          <input
            type="range"
            min={PRICE_FLOOR}
            max={PRICE_CEILING}
            step={100}
            value={filters.minPrice}
            onChange={(e) => {
              const value = Math.min(Number(e.target.value), filters.maxPrice - 100);
              onChange({ ...filters, minPrice: value });
            }}
            className="w-full accent-borgona"
            aria-label="Precio mínimo"
          />
          <input
            type="range"
            min={PRICE_FLOOR}
            max={PRICE_CEILING}
            step={100}
            value={filters.maxPrice}
            onChange={(e) => {
              const value = Math.max(Number(e.target.value), filters.minPrice + 100);
              onChange({ ...filters, maxPrice: value });
            }}
            className="w-full accent-borgona"
            aria-label="Precio máximo"
          />
          <div className="flex justify-between text-xs text-carbon/60">
            <span>{formatPrice(filters.minPrice)}</span>
            <span>{formatPrice(filters.maxPrice)}</span>
          </div>
        </div>
      </fieldset>

      <fieldset>
        <legend className="mb-3 text-sm font-semibold text-carbon">Marca</legend>
        <div className="flex flex-col gap-2">
          {brands.map((brand) => (
            <label key={brand.id} className="flex items-center gap-2 text-sm text-carbon/80">
              <input
                type="checkbox"
                checked={filters.brandIds.includes(brand.id)}
                onChange={() => onChange({ ...filters, brandIds: toggle(filters.brandIds, brand.id) })}
                className="h-4 w-4 rounded border-crema-dark text-borgona focus:ring-borgona"
              />
              {brand.name}
            </label>
          ))}
        </div>
      </fieldset>

      <fieldset>
        <legend className="mb-3 text-sm font-semibold text-carbon">Disponibilidad</legend>
        <div className="flex flex-col gap-2">
          {[
            { value: "todos", label: "Todos" },
            { value: "en_stock", label: "En stock" },
            { value: "sin_stock", label: "Sin stock" },
          ].map((opt) => (
            <label key={opt.value} className="flex items-center gap-2 text-sm text-carbon/80">
              <input
                type="radio"
                name="availability"
                checked={filters.availability === opt.value}
                onChange={() => onChange({ ...filters, availability: opt.value as CatalogFilters["availability"] })}
                className="h-4 w-4 border-crema-dark text-borgona focus:ring-borgona"
              />
              {opt.label}
            </label>
          ))}
        </div>
      </fieldset>

      <fieldset className="flex flex-col gap-2">
        <label className="flex items-center gap-2 text-sm text-carbon/80">
          <input
            type="checkbox"
            checked={filters.onOfferOnly}
            onChange={() => onChange({ ...filters, onOfferOnly: !filters.onOfferOnly })}
            className="h-4 w-4 rounded border-crema-dark text-borgona focus:ring-borgona"
          />
          Solo ofertas
        </label>
        <label className="flex items-center gap-2 text-sm text-carbon/80">
          <input
            type="checkbox"
            checked={filters.featuredOnly}
            onChange={() => onChange({ ...filters, featuredOnly: !filters.featuredOnly })}
            className="h-4 w-4 rounded border-crema-dark text-borgona focus:ring-borgona"
          />
          Solo destacados
        </label>
      </fieldset>

      <button
        type="button"
        onClick={() => onChange(DEFAULT_FILTERS)}
        className="rounded-full border border-crema-dark py-2 text-sm font-medium text-carbon/70 hover:border-borgona hover:text-borgona"
      >
        Limpiar filtros
      </button>
    </div>
  );
}
