"use client";

import { X } from "lucide-react";
import { Category, Brand } from "@/lib/types";
import { CatalogFilters, DEFAULT_FILTERS, PRICE_FLOOR, PRICE_CEILING } from "./ProductFilters";
import { formatPrice } from "@/lib/utils";

export function ActiveFilterChips({
  filters,
  categories,
  brands,
  onChange,
}: {
  filters: CatalogFilters;
  categories: Category[];
  brands: Brand[];
  onChange: (filters: CatalogFilters) => void;
}) {
  const chips: { key: string; label: string; remove: () => void }[] = [];

  filters.categoryIds.forEach((id) => {
    const cat = categories.find((c) => c.id === id);
    if (!cat) return;
    chips.push({
      key: `cat-${id}`,
      label: cat.name,
      remove: () => onChange({ ...filters, categoryIds: filters.categoryIds.filter((c) => c !== id) }),
    });
  });

  filters.brandIds.forEach((id) => {
    const brand = brands.find((b) => b.id === id);
    if (!brand) return;
    chips.push({
      key: `brand-${id}`,
      label: brand.name,
      remove: () => onChange({ ...filters, brandIds: filters.brandIds.filter((b) => b !== id) }),
    });
  });

  if (filters.minPrice > PRICE_FLOOR || filters.maxPrice < PRICE_CEILING) {
    chips.push({
      key: "price",
      label: `${formatPrice(filters.minPrice)} - ${formatPrice(filters.maxPrice)}`,
      remove: () => onChange({ ...filters, minPrice: PRICE_FLOOR, maxPrice: PRICE_CEILING }),
    });
  }

  if (filters.availability !== "todos") {
    chips.push({
      key: "availability",
      label: filters.availability === "en_stock" ? "En stock" : "Sin stock",
      remove: () => onChange({ ...filters, availability: "todos" }),
    });
  }

  if (filters.onOfferOnly) {
    chips.push({ key: "offer", label: "Oferta", remove: () => onChange({ ...filters, onOfferOnly: false }) });
  }

  if (filters.featuredOnly) {
    chips.push({ key: "featured", label: "Destacados", remove: () => onChange({ ...filters, featuredOnly: false }) });
  }

  if (chips.length === 0) return null;

  return (
    <div className="mb-5 flex flex-wrap items-center gap-2">
      <span className="text-xs font-medium uppercase tracking-wide text-carbon/40">Filtros activos:</span>
      {chips.map((chip) => (
        <button
          key={chip.key}
          type="button"
          onClick={chip.remove}
          className="flex items-center gap-1 rounded-full bg-white px-3 py-1 text-xs font-medium text-carbon shadow-sm hover:text-borgona"
        >
          {chip.label}
          <X className="h-3 w-3" />
        </button>
      ))}
      <button
        type="button"
        onClick={() => onChange(DEFAULT_FILTERS)}
        className="text-xs font-medium text-borgona hover:underline"
      >
        Limpiar todo
      </button>
    </div>
  );
}
