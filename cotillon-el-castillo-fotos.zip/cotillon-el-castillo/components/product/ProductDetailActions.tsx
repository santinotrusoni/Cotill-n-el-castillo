"use client";

import { useState } from "react";
import { Minus, Plus, ShoppingCart, Check } from "lucide-react";
import { Product } from "@/lib/types";
import { useCart } from "@/lib/cart-context";

export function ProductDetailActions({ product }: { product: Product }) {
  const outOfStock = product.status === "sin_stock" || product.stock === 0;
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const { addItem, openCart } = useCart();

  function handleAdd() {
    if (outOfStock) return;
    addItem(product.id, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-4">
        <span className="text-sm font-medium text-carbon">Cantidad</span>
        <div className="flex items-center gap-3 rounded-full border border-crema-dark px-3 py-1.5">
          <button
            type="button"
            aria-label="Restar cantidad"
            disabled={outOfStock}
            onClick={() => setQuantity((q) => Math.max(1, q - 1))}
            className="flex h-6 w-6 items-center justify-center text-carbon/70 hover:text-exito disabled:opacity-30"
          >
            <Minus className="h-3.5 w-3.5" />
          </button>
          <span className="w-6 text-center text-sm font-medium">{quantity}</span>
          <button
            type="button"
            aria-label="Sumar cantidad"
            disabled={outOfStock || quantity >= product.stock}
            onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
            className="flex h-6 w-6 items-center justify-center text-carbon/70 hover:text-exito disabled:opacity-30"
          >
            <Plus className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-2 sm:flex-row">
        <button
          type="button"
          disabled={outOfStock}
          onClick={handleAdd}
          className="flex flex-1 items-center justify-center gap-2 rounded-full bg-rosa py-3 text-sm font-medium text-white transition-colors hover:bg-rosa-dark disabled:cursor-not-allowed disabled:bg-carbon/15 disabled:text-carbon/40"
        >
          {outOfStock ? (
            "Sin stock"
          ) : added ? (
            <>
              <Check className="h-4 w-4" /> Agregado al carrito
            </>
          ) : (
            <>
              <ShoppingCart className="h-4 w-4" /> Agregar al carrito
            </>
          )}
        </button>
        {added && (
          <button
            type="button"
            onClick={openCart}
            className="rounded-full border border-crema-dark px-5 py-3 text-sm font-medium text-carbon hover:border-exito hover:text-exito"
          >
            Ver carrito
          </button>
        )}
      </div>
    </div>
  );
}
