import { ProductStatus } from "@/lib/types";

export function StockBadge({ status, stock }: { status: ProductStatus; stock: number }) {
  if (status === "sin_stock" || stock === 0) {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-error">
        <span className="h-1.5 w-1.5 rounded-full bg-error" />
        Sin stock
      </span>
    );
  }

  if (stock <= 10) {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-dorado">
        <span className="h-1.5 w-1.5 rounded-full bg-dorado" />
        Últimas unidades
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-exito">
      <span className="h-1.5 w-1.5 rounded-full bg-exito" />
      En stock
    </span>
  );
}
