"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { SlidersHorizontal, X, PackageSearch } from "lucide-react";
import { Product, Category, Brand } from "@/lib/types";
import { ProductCard } from "@/components/product/ProductCard";
import {
  ProductFilters,
  CatalogFilters,
  DEFAULT_FILTERS,
} from "@/components/product/ProductFilters";
import { ActiveFilterChips } from "@/components/product/ActiveFilterChips";

type SortOption = "relevancia" | "precio_asc" | "precio_desc" | "mas_nuevos";

const SORT_LABELS: Record<SortOption, string> = {
  relevancia: "Relevancia",
  precio_asc: "Precio: menor a mayor",
  precio_desc: "Precio: mayor a menor",
  mas_nuevos: "Más nuevos",
};

export function CatalogClient({
  products,
  categories,
  brands,
}: {
  products: Product[];
  categories: Category[];
  brands: Brand[];
}) {
  const searchParams = useSearchParams();
  const initialCategorySlug = searchParams.get("categoria");
  const initialQuery = searchParams.get("q") ?? "";
  const initialCategory = categories.find((c) => c.slug === initialCategorySlug);

  const [filters, setFilters] = useState<CatalogFilters>({
    ...DEFAULT_FILTERS,
    categoryIds: initialCategory ? [initialCategory.id] : [],
  });
  const [query, setQuery] = useState(initialQuery);
  const [sort, setSort] = useState<SortOption>("relevancia");
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const filtered = useMemo(() => {
    let result = products.filter((p) => {
      if (filters.categoryIds.length > 0 && !filters.categoryIds.includes(p.categoryId)) return false;
      if (filters.brandIds.length > 0 && !filters.brandIds.includes(p.brandId)) return false;
      if (p.price < filters.minPrice || p.price > filters.maxPrice) return false;
      if (filters.availability === "en_stock" && (p.status === "sin_stock" || p.stock === 0)) return false;
      if (filters.availability === "sin_stock" && p.status !== "sin_stock" && p.stock !== 0) return false;
      if (filters.onOfferOnly && !p.onOffer) return false;
      if (filters.featuredOnly && !p.featured) return false;
      if (query.trim()) {
        const q = query.trim().toLowerCase();
        const haystack = `${p.name} ${p.sku} ${p.barcode}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });

    result = [...result].sort((a, b) => {
      if (sort === "precio_asc") return a.price - b.price;
      if (sort === "precio_desc") return b.price - a.price;
      if (sort === "mas_nuevos") return b.createdAt.localeCompare(a.createdAt);
      return 0; // relevancia: orden original
    });

    return result;
  }, [products, filters, query, sort]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-6">
        <h1 className="font-display text-3xl font-semibold text-carbon">Todos los productos</h1>
        <p className="mt-1 text-sm text-carbon/60">{filtered.length} productos encontrados</p>
      </div>

      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Buscar por nombre, SKU o código de barras..."
          className="w-full rounded-full border border-crema-dark bg-white px-4 py-2.5 text-sm outline-none placeholder:text-carbon/40 focus:border-borgona sm:max-w-sm"
        />
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setMobileFiltersOpen(true)}
            className="flex items-center gap-2 rounded-full border border-crema-dark bg-white px-4 py-2.5 text-sm font-medium text-carbon lg:hidden"
          >
            <SlidersHorizontal className="h-4 w-4" />
            Filtros
          </button>
          <label className="flex items-center gap-2 text-sm text-carbon/70">
            <span className="hidden sm:inline">Ordenar por</span>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as SortOption)}
              className="rounded-full border border-crema-dark bg-white px-3 py-2.5 text-sm outline-none focus:border-borgona"
            >
              {Object.entries(SORT_LABELS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </label>
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-[240px_1fr]">
        <aside className="hidden lg:block">
          <ProductFilters categories={categories} brands={brands} filters={filters} onChange={setFilters} />
        </aside>

        <div>
          <ActiveFilterChips filters={filters} categories={categories} brands={brands} onChange={setFilters} />

          {filtered.length === 0 ? (
            <div className="flex flex-col items-center gap-3 rounded-xl2 bg-white py-20 text-center shadow-card">
              <PackageSearch className="h-10 w-10 text-carbon/20" />
              <p className="font-medium text-carbon">No encontramos productos con esos filtros.</p>
              <button
                type="button"
                onClick={() => {
                  setFilters(DEFAULT_FILTERS);
                  setQuery("");
                }}
                className="text-sm font-medium text-borgona hover:underline"
              >
                Limpiar filtros
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4 sm:gap-5 md:grid-cols-3 xl:grid-cols-4">
              {filtered.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>

      {mobileFiltersOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-carbon/50" onClick={() => setMobileFiltersOpen(false)} />
          <div className="absolute inset-y-0 left-0 flex w-full max-w-xs flex-col bg-white p-5">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold text-carbon">Filtros</h2>
              <button type="button" onClick={() => setMobileFiltersOpen(false)} aria-label="Cerrar filtros">
                <X className="h-5 w-5 text-carbon/60" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto pb-4">
              <ProductFilters categories={categories} brands={brands} filters={filters} onChange={setFilters} />
            </div>
            <button
              type="button"
              onClick={() => setMobileFiltersOpen(false)}
              className="mt-4 rounded-full bg-borgona py-3 text-sm font-medium text-crema"
            >
              Ver {filtered.length} resultados
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
