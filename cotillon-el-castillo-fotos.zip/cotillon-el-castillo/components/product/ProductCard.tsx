"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { Product } from "@/lib/types";
import { PriceBadge } from "./PriceBadge";
import { StockBadge } from "./StockBadge";
import { ShoppingCart, Check } from "lucide-react";
import { useCart } from "@/lib/cart-context";

export function ProductCard({ product }: { product: Product }) {
  const outOfStock = product.status === "sin_stock" || product.stock === 0;
  const [added, setAdded] = useState(false);
  const { addItem } = useCart();

  function handleAddToCart() {
    if (outOfStock) return;
    addItem(product.id, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  }

  return (
    <div className="group relative flex flex-col overflow-hidden rounded-xl2 bg-white shadow-card transition-shadow hover:shadow-cardHover">
      <Link href={`/productos/${product.slug}`} className="relative block aspect-square overflow-hidden bg-crema">
        <Image
          src={product.images[0]}
          alt={product.name}
          fill
          sizes="(max-width: 768px) 50vw, 25vw"
          className="object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute left-2 top-2 flex flex-col gap-1.5">
          {product.featured && (
            <span className="rounded-full bg-carbon/85 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-crema">
              Destacado
            </span>
          )}
          {product.onOffer && (
            <span className="rounded-full bg-rosa px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-white">
              Oferta
            </span>
          )}
          {product.isNew && (
            <span className="rounded-full bg-exito px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-white">
              Nuevo
            </span>
          )}
        </div>
      </Link>

      <div className="flex flex-1 flex-col gap-2 p-4">
        <span className="text-xs uppercase tracking-wide text-carbon/40">
          {product.tags[0] ?? "Cotillón"}
        </span>
        <Link href={`/productos/${product.slug}`} className="line-clamp-2 font-medium text-carbon hover:text-rosa">
          {product.name}
        </Link>
        <PriceBadge price={product.price} previousPrice={product.previousPrice} />
        <StockBadge status={product.status} stock={product.stock} />

        <button
          type="button"
          disabled={outOfStock}
          onClick={handleAddToCart}
          className="mt-2 flex items-center justify-center gap-2 rounded-full bg-rosa py-2.5 text-sm font-medium text-white transition-colors hover:bg-rosa-dark disabled:cursor-not-allowed disabled:bg-carbon/15 disabled:text-carbon/40"
        >
          {outOfStock ? (
            "Sin stock"
          ) : added ? (
            <>
              <Check className="h-4 w-4" aria-hidden /> Agregado
            </>
          ) : (
            <>
              <ShoppingCart className="h-4 w-4" aria-hidden /> Agregar al carrito
            </>
          )}
        </button>
      </div>
    </div>
  );
}
