"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { loginCustomerAction, registerCustomerAction } from "@/lib/customer-auth-actions";

const inputClass =
  "w-full rounded-lg border border-crema-dark bg-white px-3.5 py-2.5 text-sm outline-none transition-colors focus:border-borgona";

export function AuthForm({ mode, next }: { mode: "login" | "register"; next: string }) {
  const isRegister = mode === "register";
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "" });
  const [error, setError] = useState("");
  const [pending, startTransition] = useTransition();

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    startTransition(async () => {
      const result = isRegister
        ? await registerCustomerAction(form, next)
        : await loginCustomerAction(form.email, form.password, next);
      if (result?.error) setError(result.error);
    });
  }

  const nextQuery = next && next !== "/cuenta" ? `?next=${encodeURIComponent(next)}` : "";

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {isRegister && (
        <>
          <div>
            <label htmlFor="name" className="mb-1.5 block text-sm font-medium text-carbon">Nombre y apellido</label>
            <input id="name" autoComplete="name" required value={form.name} onChange={set("name")} className={inputClass} />
          </div>
          <div>
            <label htmlFor="phone" className="mb-1.5 block text-sm font-medium text-carbon">Teléfono / WhatsApp</label>
            <input id="phone" type="tel" autoComplete="tel" required value={form.phone} onChange={set("phone")} className={inputClass} />
          </div>
        </>
      )}
      <div>
        <label htmlFor="email" className="mb-1.5 block text-sm font-medium text-carbon">Email</label>
        <input id="email" type="email" autoComplete="email" required value={form.email} onChange={set("email")} className={inputClass} />
      </div>
      <div>
        <label htmlFor="password" className="mb-1.5 block text-sm font-medium text-carbon">Contraseña</label>
        <input
          id="password"
          type="password"
          autoComplete={isRegister ? "new-password" : "current-password"}
          required
          minLength={isRegister ? 8 : undefined}
          value={form.password}
          onChange={set("password")}
          className={inputClass}
        />
        {isRegister && <p className="mt-1 text-xs text-carbon/50">Mínimo 8 caracteres.</p>}
      </div>

      {error && (
        <p role="alert" className="rounded-lg bg-error/10 px-3 py-2 text-sm text-error">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={pending}
        className="w-full rounded-full bg-rosa py-3 text-sm font-medium text-white transition-colors hover:bg-rosa-dark disabled:opacity-60"
      >
        {pending ? "Un momento..." : isRegister ? "Crear mi cuenta" : "Ingresar"}
      </button>

      <p className="text-center text-sm text-carbon/60">
        {isRegister ? (
          <>¿Ya tenés cuenta? <Link href={`/ingresar${nextQuery}`} className="font-medium text-rosa hover:underline">Ingresá</Link></>
        ) : (
          <>¿Todavía no tenés cuenta? <Link href={`/registrarse${nextQuery}`} className="font-medium text-rosa hover:underline">Registrate</Link></>
        )}
      </p>
    </form>
  );
}
