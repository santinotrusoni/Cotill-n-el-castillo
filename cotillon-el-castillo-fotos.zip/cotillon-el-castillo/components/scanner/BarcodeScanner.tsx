"use client";

import { useEffect, useRef } from "react";
import { BrowserMultiFormatReader } from "@zxing/browser";
import type { IScannerControls } from "@zxing/browser";
import { BarcodeFormat, DecodeHintType, NotFoundException } from "@zxing/library";

interface BarcodeScannerProps {
  /** Se llama una única vez por código detectado (hasta que se llame a reset()). */
  onDetected: (code: string) => void;
  /** Se llama si la cámara no está disponible o el permiso fue denegado. */
  onError: (message: string) => void;
}

const HINTS = new Map();
HINTS.set(DecodeHintType.POSSIBLE_FORMATS, [
  BarcodeFormat.EAN_13,
  BarcodeFormat.EAN_8,
  BarcodeFormat.UPC_A,
  BarcodeFormat.UPC_E,
  BarcodeFormat.CODE_128,
  BarcodeFormat.CODE_39,
]);

/**
 * Cámara en vivo + lectura de código de barras (ZXing).
 * Muestra el <video> con el stream y un marco visual superpuesto;
 * la detección corre en background y se reporta vía onDetected.
 */
export function BarcodeScanner({ onDetected, onError }: BarcodeScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const controlsRef = useRef<IScannerControls | null>(null);
  const detectedRef = useRef(false);

  useEffect(() => {
    let cancelled = false;
    const reader = new BrowserMultiFormatReader(HINTS as any);

    async function start() {
      if (!navigator.mediaDevices?.getUserMedia) {
        onError("Este navegador no permite acceder a la cámara. Probá con el ingreso manual.");
        return;
      }

      try {
        const devices = await BrowserMultiFormatReader.listVideoInputDevices();
        if (devices.length === 0) {
          onError("No encontramos ninguna cámara disponible en este dispositivo.");
          return;
        }

        // En celulares preferimos la cámara trasera para apuntar al producto.
        const backCamera = devices.find((d) => /back|rear|trasera|environment/i.test(d.label));
        const deviceId = (backCamera ?? devices[devices.length - 1]).deviceId;

        const controls = await reader.decodeFromVideoDevice(
          deviceId,
          videoRef.current!,
          (result, error) => {
            if (cancelled || detectedRef.current) return;
            if (result) {
              detectedRef.current = true;
              onDetected(result.getText());
            } else if (error && !(error instanceof NotFoundException)) {
              // Errores de decodificación frame a frame son normales mientras
              // no hay un código enfocado: los ignoramos en silencio.
            }
          }
        );

        if (cancelled) {
          controls.stop();
          return;
        }
        controlsRef.current = controls;
      } catch (err) {
        if (cancelled) return;
        if (err instanceof DOMException && (err.name === "NotAllowedError" || err.name === "PermissionDeniedError")) {
          onError("Necesitamos permiso de cámara para escanear. Habilitalo en la configuración del navegador.");
        } else if (err instanceof DOMException && err.name === "NotFoundError") {
          onError("No encontramos ninguna cámara disponible en este dispositivo.");
        } else {
          onError("No pudimos acceder a la cámara. Probá con el ingreso manual.");
        }
      }
    }

    start();

    return () => {
      cancelled = true;
      controlsRef.current?.stop();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="relative aspect-[3/4] w-full overflow-hidden rounded-xl2 bg-carbon sm:aspect-video">
      <video ref={videoRef} className="h-full w-full object-cover" muted playsInline autoPlay />

      {/* Marco visual + línea de escaneo */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center p-8 sm:p-12">
        <div className="relative h-full w-full max-w-md">
          <div className="absolute inset-0 rounded-2xl border-2 border-crema/50" />
          <span className="absolute -left-0.5 -top-0.5 h-7 w-7 rounded-tl-2xl border-l-4 border-t-4 border-dorado" />
          <span className="absolute -right-0.5 -top-0.5 h-7 w-7 rounded-tr-2xl border-r-4 border-t-4 border-dorado" />
          <span className="absolute -left-0.5 -bottom-0.5 h-7 w-7 rounded-bl-2xl border-b-4 border-l-4 border-dorado" />
          <span className="absolute -right-0.5 -bottom-0.5 h-7 w-7 rounded-br-2xl border-b-4 border-r-4 border-dorado" />
          <div className="scan-line absolute inset-x-3 h-0.5 rounded-full bg-dorado shadow-[0_0_8px_2px_rgba(201,162,39,0.6)]" />
        </div>
      </div>

      <p className="pointer-events-none absolute inset-x-0 bottom-4 text-center text-xs font-medium uppercase tracking-wide text-crema/70">
        Centrá el código de barras dentro del marco
      </p>
    </div>
  );
}
