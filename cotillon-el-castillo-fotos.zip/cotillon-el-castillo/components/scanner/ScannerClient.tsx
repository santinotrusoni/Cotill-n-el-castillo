"use client";

import { useCallback, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  ScanLine,
  Search,
  ShoppingCart,
  Check,
  X,
  AlertTriangle,
  PackageSearch,
  ArrowRight,
} from "lucide-react";
import { Product, Category } from "@/lib/types";
import { useCart } from "@/lib/cart-context";
import { PriceBadge } from "@/components/product/PriceBadge";
import { StockBadge } from "@/components/product/StockBadge";
import { BarcodeScanner } from "@/components/scanner/BarcodeScanner";

type ScanState =
  | { view: "idle" }
  | { view: "scanning" }
  | { view: "camera_error"; message: string }
  | { view: "found"; product: Product }
  | { view: "not_found"; code: string };

export function ScannerClient({ products, categories }: { products: Product[]; categories: Category[] }) {
  const [state, setState] = useState<ScanState>({ view: "idle" });
  const [manualCode, setManualCode] = useState("");

  const resolveCode = useCallback(
    (rawCode: string) => {
      const code = rawCode.trim();
      if (!code) return;
      const product = products.find((p) => p.barcode === code);
      setState(product ? { view: "found", product } : { view: "not_found", code });
    },
    [products]
  );

  function handleManualSubmit(e: React.FormEvent) {
    e.preventDefault();
    resolveCode(manualCode);
  }

  function handleReset() {
    setManualCode("");
    setState({ view: "idle" });
  }

  const showScannerPanel = state.view !== "found";

  return (
    <div className="grid gap-8 lg:grid-cols-2 lg:items-start">
      {/* Panel de escaneo */}
      {showScannerPanel && (
        <div className="ticket-edge-bottom overflow-hidden rounded-xl2 bg-carbon">
          {state.view === "idle" && (
            <div className="flex flex-col items-center gap-4 px-6 py-16 text-center sm:py-20">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-dorado/15">
                <ScanLine className="h-8 w-8 text-dorado" aria-hidden />
              </div>
              <h1 className="font-display text-2xl font-semibold text-crema sm:text-3xl">
                Escaneá el código de barras
              </h1>
              <p className="max-w-xs text-sm text-crema/60">
                Encontrá el producto que buscás en segundos, directamente desde la
                cámara de tu teléfono.
              </p>
              <button
                type="button"
                onClick={() => setState({ view: "scanning" })}
                className="mt-2 flex items-center gap-2 rounded-full bg-rosa px-6 py-3 text-sm font-medium text-white transition-colors hover:bg-rosa-dark"
              >
                <ScanLine className="h-4 w-4" aria-hidden />
                Iniciar escaneo
              </button>
            </div>
          )}

          {state.view === "scanning" && (
            <div className="p-3 sm:p-4">
              <BarcodeScanner
                onDetected={resolveCode}
                onError={(message) => setState({ view: "camera_error", message })}
              />
              <button
                type="button"
                onClick={handleReset}
                className="mx-auto mt-3 flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-medium text-crema/70 transition-colors hover:text-crema"
              >
                <X className="h-3.5 w-3.5" aria-hidden />
                Cancelar escaneo
              </button>
            </div>
          )}

          {state.view === "camera_error" && (
            <div className="flex flex-col items-center gap-4 px-6 py-16 text-center sm:py-20">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-error/15">
                <AlertTriangle className="h-8 w-8 text-error" aria-hidden />
              </div>
              <h2 className="font-display text-xl font-semibold text-crema">
                No pudimos abrir la cámara
              </h2>
              <p className="max-w-xs text-sm text-crema/60">{state.message}</p>
              <p className="max-w-xs text-xs text-crema/40">
                Podés seguir buscando el producto ingresando el código manualmente acá abajo.
              </p>
              <button
                type="button"
                onClick={() => setState({ view: "scanning" })}
                className="mt-1 rounded-full border border-crema/25 px-5 py-2.5 text-sm font-medium text-crema transition-colors hover:bg-white/10"
              >
                Reintentar cámara
              </button>
            </div>
          )}

          {state.view === "not_found" && (
            <div className="flex flex-col items-center gap-4 px-6 py-16 text-center sm:py-20">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-crema/10">
                <PackageSearch className="h-8 w-8 text-crema/60" aria-hidden />
              </div>
              <h2 className="font-display text-xl font-semibold text-crema">
                No encontramos ese producto
              </h2>
              <p className="max-w-xs text-sm text-crema/60">
                El código <span className="font-mono text-crema">{state.code}</span> no
                coincide con ningún producto de nuestro catálogo.
              </p>
              <button
                type="button"
                onClick={handleReset}
                className="mt-1 rounded-full bg-rosa px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-rosa-dark"
              >
                Intentar de nuevo
              </button>
            </div>
          )}
        </div>
      )}

      {/* Resultado del producto encontrado */}
      {state.view === "found" && (
        <ScanResultCard product={state.product} categories={categories} onScanAnother={handleReset} />
      )}

      {/* Ingreso manual: siempre disponible, funcione o no la cámara */}
      <div className={showScannerPanel ? "" : "lg:col-start-1 lg:row-start-1"}>
        <div className="rounded-xl2 bg-white p-6 shadow-card sm:p-8">
          <h2 className="font-display text-lg font-semibold text-carbon">
            ¿No podés escanearlo?
          </h2>
          <p className="mt-1 text-sm text-carbon/60">Ingresá el código manualmente.</p>
          <form onSubmit={handleManualSubmit} className="mt-4 flex flex-col gap-3 sm:flex-row">
            <input
              type="text"
              inputMode="numeric"
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value)}
              placeholder="7791234567890"
              className="flex-1 rounded-full border border-crema-dark bg-crema/40 px-4 py-2.5 text-sm text-carbon outline-none placeholder:text-carbon/30 focus:border-borgona"
            />
            <button
              type="submit"
              disabled={!manualCode.trim()}
              className="flex items-center justify-center gap-2 rounded-full bg-rosa px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-rosa-dark disabled:cursor-not-allowed disabled:bg-carbon/15 disabled:text-carbon/40"
            >
              <Search className="h-4 w-4" aria-hidden />
              Buscar
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

function ScanResultCard({
  product,
  categories,
  onScanAnother,
}: {
  product: Product;
  categories: Category[];
  onScanAnother: () => void;
}) {
  const outOfStock = product.status === "sin_stock" || product.stock === 0;
  const [added, setAdded] = useState(false);
  const { addItem, openCart } = useCart();
  const category = categories.find((c) => c.id === product.categoryId);

  function handleAdd() {
    if (outOfStock) return;
    addItem(product.id, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  }

  return (
    <div className="overflow-hidden rounded-xl2 bg-white shadow-card">
      <div className="flex items-center gap-2 border-b border-crema-dark bg-exito/10 px-6 py-3">
        <Check className="h-4 w-4 text-exito" aria-hidden />
        <span className="text-sm font-medium text-exito">Código encontrado</span>
      </div>

      <div className="p-6 sm:p-8">
        <div className="flex gap-5">
          <div className="relative h-28 w-28 shrink-0 overflow-hidden rounded-xl2 bg-crema">
            <Image src={product.images[0]} alt={product.name} fill className="object-cover" sizes="112px" />
          </div>
          <div className="flex flex-col gap-1.5">
            {category && (
              <span className="text-xs font-semibold uppercase tracking-wide text-borgona">
                {category.name}
              </span>
            )}
            <h2 className="font-display text-xl font-semibold leading-snug text-carbon">
              {product.name}
            </h2>
            <PriceBadge price={product.price} previousPrice={product.previousPrice} />
            <StockBadge status={product.status} stock={product.stock} />
          </div>
        </div>

        <div className="mt-5 flex flex-wrap gap-x-6 gap-y-1 border-t border-crema-dark pt-4 text-xs text-carbon/50">
          <span>SKU: {product.sku}</span>
          <span>Código de barras: {product.barcode}</span>
        </div>

        <p className="mt-4 text-sm leading-relaxed text-carbon/70">{product.shortDescription}</p>

        {product.features.length > 0 && (
          <ul className="mt-3 list-inside list-disc space-y-1 text-sm text-carbon/70">
            {product.features.slice(0, 4).map((f) => (
              <li key={f}>{f}</li>
            ))}
          </ul>
        )}

        <div className="mt-6 flex flex-col gap-2 sm:flex-row">
          <button
            type="button"
            disabled={outOfStock}
            onClick={handleAdd}
            className="flex flex-1 items-center justify-center gap-2 rounded-full bg-rosa py-3 text-sm font-medium text-white transition-colors hover:bg-rosa-dark disabled:cursor-not-allowed disabled:bg-carbon/15 disabled:text-carbon/40"
          >
            {outOfStock ? (
              "Sin stock"
            ) : added ? (
              <>
                <Check className="h-4 w-4" aria-hidden /> Agregado
              </>
            ) : (
              <>
                <ShoppingCart className="h-4 w-4" aria-hidden /> Agregar al carrito
              </>
            )}
          </button>
          <Link
            href={`/productos/${product.slug}`}
            className="flex items-center justify-center gap-2 rounded-full border border-crema-dark px-5 py-3 text-sm font-medium text-carbon transition-colors hover:border-exito hover:text-exito"
          >
            Ver producto
            <ArrowRight className="h-4 w-4" aria-hidden />
          </Link>
        </div>

        {added && (
          <button
            type="button"
            onClick={openCart}
            className="mt-3 w-full text-center text-xs font-medium text-exito hover:underline"
          >
            Ver carrito
          </button>
        )}

        <button
          type="button"
          onClick={onScanAnother}
          className="mt-5 flex w-full items-center justify-center gap-2 text-xs font-medium text-carbon/50 hover:text-rosa"
        >
          <ScanLine className="h-3.5 w-3.5" aria-hidden />
          Escanear otro código
        </button>
      </div>
    </div>
  );
}
