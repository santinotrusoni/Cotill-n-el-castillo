"use client";

import Image from "next/image";
import Link from "next/link";
import { Minus, Plus, Trash2, ShoppingBag, MessageCircle } from "lucide-react";
import { useCart } from "@/lib/cart-context";
import { formatPrice } from "@/lib/utils";

export function CartPageClient({ whatsappNumber }: { whatsappNumber: string }) {
  const { items, updateQuantity, removeItem, getProduct, subtotal, discount, total, clearCart } = useCart();

  const whatsappMessage = () => {
    const lines = items.map((item) => {
      const product = getProduct(item.productId);
      if (!product) return "";
      return `• ${product.name} x${item.quantity} — ${formatPrice(product.price * item.quantity)}`;
    });
    lines.push("", `Total: ${formatPrice(total)}`);
    return encodeURIComponent(`¡Hola! Quiero hacer este pedido en Cotillón El Castillo:\n\n${lines.join("\n")}`);
  };

  if (items.length === 0) {
    return (
      <div className="mx-auto flex max-w-lg flex-col items-center gap-4 px-4 py-24 text-center">
        <ShoppingBag className="h-12 w-12 text-carbon/20" />
        <h1 className="font-display text-2xl font-semibold text-carbon">Tu carrito está vacío</h1>
        <p className="text-sm text-carbon/60">Todavía no agregaste productos a tu carrito.</p>
        <Link href="/productos" className="rounded-full bg-rosa px-6 py-3 text-sm font-medium text-white hover:bg-rosa-dark">
          Ver productos
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="mb-6 font-display text-3xl font-semibold text-carbon">Tu carrito</h1>

      <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
        <ul className="divide-y divide-crema-dark rounded-xl2 bg-white shadow-card">
          {items.map((item) => {
            const product = getProduct(item.productId);
            if (!product) return null;
            return (
              <li key={item.productId} className="flex gap-4 p-4 sm:p-5">
                <Link href={`/productos/${product.slug}`} className="relative h-20 w-20 shrink-0 overflow-hidden rounded-lg bg-crema sm:h-24 sm:w-24">
                  <Image src={product.images[0]} alt={product.name} fill sizes="96px" className="object-cover" />
                </Link>
                <div className="flex flex-1 flex-col justify-between">
                  <div>
                    <Link href={`/productos/${product.slug}`} className="font-medium text-carbon hover:text-rosa">
                      {product.name}
                    </Link>
                    <p className="mt-0.5 text-sm text-carbon/60">{formatPrice(product.price)} c/u</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-3 rounded-full border border-crema-dark px-2.5 py-1">
                      <button
                        type="button"
                        aria-label="Restar cantidad"
                        onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                        className="flex h-6 w-6 items-center justify-center text-carbon/70 hover:text-exito"
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                      <span className="w-5 text-center text-sm">{item.quantity}</span>
                      <button
                        type="button"
                        aria-label="Sumar cantidad"
                        disabled={item.quantity >= product.stock}
                        onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                        className="flex h-6 w-6 items-center justify-center text-carbon/70 hover:text-exito disabled:opacity-30"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeItem(item.productId)}
                      className="flex items-center gap-1 text-xs text-carbon/40 hover:text-error"
                    >
                      <Trash2 className="h-3.5 w-3.5" /> Eliminar
                    </button>
                  </div>
                </div>
                <span className="hidden font-medium text-carbon sm:block">
                  {formatPrice(product.price * item.quantity)}
                </span>
              </li>
            );
          })}
        </ul>

        <div className="h-fit rounded-xl2 bg-white p-5 shadow-card">
          <h2 className="mb-4 font-display text-lg font-semibold text-carbon">Resumen</h2>
          <div className="flex justify-between py-1 text-sm text-carbon/60">
            <span>Subtotal</span>
            <span>{formatPrice(subtotal + discount)}</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between py-1 text-sm text-exito">
              <span>Descuento</span>
              <span>-{formatPrice(discount)}</span>
            </div>
          )}
          <div className="mt-2 flex justify-between border-t border-crema-dark py-3 font-display text-xl font-semibold text-carbon">
            <span>Total</span>
            <span>{formatPrice(total)}</span>
          </div>

          <Link
            href="/checkout"
            className="mt-3 flex items-center justify-center gap-2 rounded-full bg-rosa py-3 text-sm font-medium text-white hover:bg-rosa-dark"
          >
            Finalizar pedido
          </Link>
          <a
            href={`https://wa.me/${whatsappNumber}?text=${whatsappMessage()}`}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-2 flex items-center justify-center gap-2 rounded-full border border-crema-dark py-2.5 text-sm font-medium text-carbon/70 hover:border-exito hover:text-exito"
          >
            <MessageCircle className="h-4 w-4" />
            Consultar por WhatsApp
          </a>
          <button
            type="button"
            onClick={clearCart}
            className="mt-2 w-full rounded-full border border-crema-dark py-2.5 text-sm font-medium text-carbon/60 hover:border-error hover:text-error"
          >
            Vaciar carrito
          </button>
        </div>
      </div>
    </div>
  );
}
