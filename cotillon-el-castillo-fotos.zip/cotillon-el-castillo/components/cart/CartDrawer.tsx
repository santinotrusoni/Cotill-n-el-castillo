"use client";

import Image from "next/image";
import Link from "next/link";
import { X, Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useCart } from "@/lib/cart-context";
import { formatPrice } from "@/lib/utils";

export function CartDrawer() {
  const { items, isOpen, closeCart, updateQuantity, removeItem, getProduct, subtotal, discount, total } = useCart();

  return (
    <>
      <div
        aria-hidden={!isOpen}
        onClick={closeCart}
        className={`fixed inset-0 z-50 bg-carbon/50 transition-opacity ${
          isOpen ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      />
      <aside
        role="dialog"
        aria-modal="true"
        aria-label="Carrito de compras"
        className={`fixed right-0 top-0 z-50 flex h-full w-full max-w-sm flex-col bg-white shadow-2xl transition-transform duration-300 ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between border-b border-crema-dark px-5 py-4">
          <h2 className="font-display text-lg font-semibold text-carbon">Tu carrito</h2>
          <button
            type="button"
            onClick={closeCart}
            aria-label="Cerrar carrito"
            className="rounded-full p-1.5 text-carbon/60 hover:bg-crema hover:text-rosa"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
            <ShoppingBag className="h-10 w-10 text-carbon/20" />
            <p className="text-sm text-carbon/60">Todavía no agregaste productos.</p>
            <button
              onClick={closeCart}
              className="rounded-full bg-rosa px-5 py-2 text-sm font-medium text-white hover:bg-rosa-dark"
            >
              Seguir comprando
            </button>
          </div>
        ) : (
          <>
            <ul className="flex-1 divide-y divide-crema-dark overflow-y-auto px-5">
              {items.map((item) => {
                const product = getProduct(item.productId);
                if (!product) return null;
                return (
                  <li key={item.productId} className="flex gap-3 py-4">
                    <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-crema">
                      <Image src={product.images[0]} alt={product.name} fill sizes="64px" className="object-cover" />
                    </div>
                    <div className="flex flex-1 flex-col gap-1">
                      <Link
                        href={`/productos/${product.slug}`}
                        onClick={closeCart}
                        className="line-clamp-1 text-sm font-medium text-carbon hover:text-rosa"
                      >
                        {product.name}
                      </Link>
                      <span className="text-sm text-carbon/60">{formatPrice(product.price)}</span>
                      <div className="mt-1 flex items-center gap-2">
                        <button
                          type="button"
                          aria-label="Restar cantidad"
                          onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                          className="flex h-6 w-6 items-center justify-center rounded-full border border-crema-dark text-carbon/70 hover:border-exito hover:text-exito"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="w-5 text-center text-sm">{item.quantity}</span>
                        <button
                          type="button"
                          aria-label="Sumar cantidad"
                          onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                          disabled={item.quantity >= product.stock}
                          className="flex h-6 w-6 items-center justify-center rounded-full border border-crema-dark text-carbon/70 hover:border-exito hover:text-exito disabled:opacity-30"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                        <button
                          type="button"
                          aria-label="Eliminar producto"
                          onClick={() => removeItem(item.productId)}
                          className="ml-auto text-carbon/40 hover:text-error"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>

            <div className="border-t border-crema-dark px-5 py-4">
              <div className="mb-1 flex justify-between text-sm text-carbon/60">
                <span>Subtotal</span>
                <span>{formatPrice(subtotal + discount)}</span>
              </div>
              {discount > 0 && (
                <div className="mb-1 flex justify-between text-sm text-exito">
                  <span>Descuento</span>
                  <span>-{formatPrice(discount)}</span>
                </div>
              )}
              <div className="mb-4 flex justify-between font-display text-lg font-semibold text-carbon">
                <span>Total</span>
                <span>{formatPrice(total)}</span>
              </div>
              <Link
                href="/carrito"
                onClick={closeCart}
                className="block rounded-full bg-rosa py-3 text-center text-sm font-medium text-white hover:bg-rosa-dark"
              >
                Continuar compra
              </Link>
            </div>
          </>
        )}
      </aside>
    </>
  );
}
