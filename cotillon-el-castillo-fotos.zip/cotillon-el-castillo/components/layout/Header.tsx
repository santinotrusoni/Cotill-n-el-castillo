"use client";

import Link from "next/link";
import { useState } from "react";
import { Search, User, ShoppingCart, ScanLine, Menu, X, Ghost } from "lucide-react";
import { useCart } from "@/lib/cart-context";
import { Logo } from "@/components/layout/Logo";

const NAV_LINKS: { label: string; href: string; special?: boolean }[] = [
  { label: "Inicio", href: "/" },
  { label: "Productos", href: "/productos" },
  { label: "Categorías", href: "/categorias" },
  { label: "Ofertas", href: "/ofertas" },
  { label: "Halloween", href: "/halloween", special: true },
  { label: "Destacados", href: "/destacados" },
  { label: "Novedades", href: "/novedades" },
  { label: "Contacto", href: "/contacto" },
];

export function Header({ accountName }: { accountName?: string | null }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const { itemCount, openCart } = useCart();

  return (
    <header className="sticky top-0 z-40 border-b border-crema-dark bg-crema/95 backdrop-blur supports-[backdrop-filter]:bg-crema/80">
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-2 sm:px-6 lg:px-8">
        <Link href="/" aria-label="Cotillón El Castillo, ir al inicio" className="shrink-0">
          <Logo className="h-14 sm:h-[72px]" priority />
        </Link>

        <nav className="hidden flex-1 items-center justify-center gap-6 lg:flex">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={
                link.special
                  ? "flex items-center gap-1 rounded-full bg-halloween-night px-3 py-1 text-sm font-semibold text-halloween-orange transition-colors hover:bg-halloween-plum"
                  : "text-sm font-medium text-carbon/80 transition-colors hover:text-borgona"
              }
            >
              {link.special && <Ghost className="h-3.5 w-3.5" aria-hidden />}
              {link.label}
            </Link>
          ))}
        </nav>

        <form
          role="search"
          action="/productos"
          className="hidden flex-1 max-w-sm items-center rounded-full border border-crema-dark bg-white px-4 py-2 md:flex"
        >
          <Search className="h-4 w-4 shrink-0 text-carbon/40" aria-hidden />
          <input
            type="search"
            name="q"
            placeholder="Buscar productos, SKU o código..."
            className="w-full bg-transparent px-2 text-sm text-carbon outline-none placeholder:text-carbon/40"
          />
        </form>

        <div className="ml-auto flex items-center gap-1 sm:gap-2">
          <Link
            href="/escanear"
            className="hidden items-center gap-2 rounded-full bg-borgona px-4 py-2 text-sm font-medium text-crema transition-colors hover:bg-borgona-dark sm:flex"
          >
            <ScanLine className="h-4 w-4" aria-hidden />
            Escanear código
          </Link>
          <Link
            href={accountName ? "/cuenta" : "/ingresar"}
            aria-label={accountName ? `Mi cuenta (${accountName})` : "Ingresar o crear cuenta"}
            title={accountName ? `Mi cuenta (${accountName})` : "Ingresar"}
            className="relative rounded-full p-2 text-carbon/70 transition-colors hover:bg-white hover:text-borgona"
          >
            <User className="h-5 w-5" />
            {accountName && (
              <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-exito ring-2 ring-crema" aria-hidden />
            )}
          </Link>
          <button
            type="button"
            onClick={openCart}
            aria-label={`Carrito, ${itemCount} productos`}
            className="relative rounded-full p-2 text-carbon/70 transition-colors hover:bg-white hover:text-borgona"
          >
            <ShoppingCart className="h-5 w-5" />
            {itemCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-rosa text-[10px] font-semibold text-white">
                {itemCount}
              </span>
            )}
          </button>
          <button
            type="button"
            aria-label={menuOpen ? "Cerrar menú" : "Abrir menú"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((v) => !v)}
            className="rounded-full p-2 text-carbon/70 transition-colors hover:bg-white hover:text-borgona lg:hidden"
          >
            {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className="border-t border-crema-dark bg-crema px-4 pb-4 pt-2 lg:hidden">
          <form action="/productos" role="search" className="mb-3 flex items-center rounded-full border border-crema-dark bg-white px-4 py-2">
            <Search className="h-4 w-4 shrink-0 text-carbon/40" aria-hidden />
            <input
              type="search"
              name="q"
              placeholder="Buscar productos..."
              className="w-full bg-transparent px-2 text-sm outline-none placeholder:text-carbon/40"
            />
          </form>
          <nav className="flex flex-col gap-1">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className={
                  link.special
                    ? "flex items-center gap-2 rounded-lg bg-halloween-night px-2 py-2.5 text-sm font-semibold text-halloween-orange"
                    : "rounded-lg px-2 py-2.5 text-sm font-medium text-carbon/80 hover:bg-white hover:text-borgona"
                }
              >
                {link.special && <Ghost className="h-4 w-4" aria-hidden />}
                {link.label}
              </Link>
            ))}
            <Link
              href="/escanear"
              onClick={() => setMenuOpen(false)}
              className="mt-2 flex items-center justify-center gap-2 rounded-full bg-borgona px-4 py-2.5 text-sm font-medium text-crema"
            >
              <ScanLine className="h-4 w-4" aria-hidden />
              Escanear código
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
