import Image from "next/image";

/**
 * Logo de Cotillón El Castillo (public/logo.png, fondo transparente).
 * La altura se controla con className (ej: "h-14"); el ancho se ajusta solo.
 */
export function Logo({ className = "h-14", priority = false }: { className?: string; priority?: boolean }) {
  return (
    <Image
      src="/logo.png"
      alt="Cotillón El Castillo"
      width={900}
      height={777}
      priority={priority}
      sizes="(max-width: 640px) 200px, 400px"
      className={`${className} w-auto`}
    />
  );
}

/**
 * El nombre del logo es oscuro, así que sobre fondos oscuros (footer, panel de
 * contacto, sidebar del admin) va apoyado sobre una placa clara.
 */
export function LogoBadge({ className = "h-24" }: { className?: string }) {
  return (
    <span className="inline-block rounded-xl2 bg-crema p-2.5">
      <Logo className={className} />
    </span>
  );
}
