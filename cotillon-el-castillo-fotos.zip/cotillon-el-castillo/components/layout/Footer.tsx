import Link from "next/link";
import { MapPin, Phone, Clock } from "lucide-react";
import { SiteSettings } from "@/lib/types";
import { LogoBadge } from "@/components/layout/Logo";

export function Footer({ settings }: { settings: SiteSettings }) {
  return (
    <footer className="mt-20 border-t border-crema-dark bg-carbon text-crema/80">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-4 lg:px-8">
        <div>
          <LogoBadge className="h-28" />
          <p className="mt-3 max-w-xs text-sm text-crema/60">
            Cotillón, decoración, descartables y repostería para que tu evento salga como lo imaginaste.
          </p>
        </div>

        <div>
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-crema">Tienda</h3>
          <ul className="space-y-2 text-sm">
            <li><Link href="/productos" className="hover:text-rosa">Todos los productos</Link></li>
            <li><Link href="/ofertas" className="hover:text-rosa">Ofertas</Link></li>
            <li><Link href="/destacados" className="hover:text-rosa">Destacados</Link></li>
            <li><Link href="/halloween" className="hover:text-halloween-orange">Halloween</Link></li>
            <li><Link href="/categorias" className="hover:text-rosa">Categorías</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-crema">Ayuda</h3>
          <ul className="space-y-2 text-sm">
            <li><Link href="/contacto" className="hover:text-rosa">Contacto</Link></li>
            <li><Link href="/escanear" className="hover:text-rosa">Escanear código</Link></li>
            <li><Link href="/carrito" className="hover:text-rosa">Mi carrito</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-crema">Visitanos</h3>
          <ul className="space-y-3 text-sm">
            <li className="flex items-start gap-2">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-exito" />
              {settings.address}
            </li>
            <li className="flex items-start gap-2">
              <Clock className="mt-0.5 h-4 w-4 shrink-0 text-exito" />
              {settings.hours}
            </li>
            <li className="flex items-start gap-2">
              <Phone className="mt-0.5 h-4 w-4 shrink-0 text-exito" />
              WhatsApp disponible
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 px-4 py-4 text-center text-xs text-crema/40">
        © {new Date().getFullYear()} Cotillón El Castillo. Todos los derechos reservados.
      </div>
    </footer>
  );
}
