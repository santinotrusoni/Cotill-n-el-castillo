import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { getOfferProducts } from "@/lib/mock-service";
import { ProductCard } from "@/components/product/ProductCard";

export async function OffersSection() {
  const offers = await getOfferProducts(8);

  if (offers.length === 0) return null;

  return (
    <section className="bg-crema-dark/50 py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wide text-rosa">Por tiempo limitado</span>
            <h2 className="font-display text-2xl font-semibold text-carbon sm:text-3xl">Ofertas imperdibles</h2>
          </div>
          <Link href="/ofertas" className="hidden items-center gap-1 text-sm font-medium text-rosa hover:underline sm:flex">
            Ver todas <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 gap-4 sm:gap-5 md:grid-cols-3 lg:grid-cols-4">
          {offers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        <Link
          href="/ofertas"
          className="mt-6 flex items-center justify-center gap-1 text-sm font-medium text-rosa hover:underline sm:hidden"
        >
          Ver todas <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </section>
  );
}
