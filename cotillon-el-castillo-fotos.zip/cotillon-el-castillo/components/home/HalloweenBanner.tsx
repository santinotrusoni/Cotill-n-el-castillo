import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Ghost } from "lucide-react";

/** Acceso directo a la sección de Halloween desde el home. */
export function HalloweenBanner() {
  return (
    <section className="mx-auto max-w-7xl px-4 pt-10 sm:px-6 lg:px-8">
      <Link
        href="/halloween"
        className="group relative flex min-h-[220px] items-center overflow-hidden rounded-xl2 bg-halloween-night sm:min-h-[260px]"
      >
        <Image
          src="/halloween/poster.jpg"
          alt=""
          fill
          sizes="(max-width: 1280px) 100vw, 1280px"
          className="object-cover opacity-70 transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-halloween-night via-halloween-night/80 to-transparent" />

        <div className="relative max-w-xl px-6 py-8 sm:px-10">
          <span className="mb-3 inline-flex items-center gap-1.5 rounded-full bg-halloween-orange/15 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-halloween-ember">
            <Ghost className="h-3.5 w-3.5" aria-hidden /> Temporada de Halloween
          </span>
          <h2 className="font-display text-3xl font-semibold leading-tight text-white sm:text-4xl">
            Noche de brujas,{" "}
            <span className="italic text-halloween-orange">todo en El Castillo</span>
          </h2>
          <p className="mt-2 max-w-md text-sm text-white/70 sm:text-base">
            Disfraces, decoración, globos y todo lo que necesitás para una fiesta de terror.
          </p>
          <span className="mt-5 inline-flex items-center gap-2 rounded-full bg-halloween-orange px-5 py-2.5 text-sm font-semibold text-halloween-night transition-colors group-hover:bg-halloween-ember">
            Entrar a Halloween <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
          </span>
        </div>
      </Link>
    </section>
  );
}
