import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { getFeaturedProducts } from "@/lib/mock-service";
import { ProductCard } from "@/components/product/ProductCard";

export async function FeaturedProducts() {
  const featured = await getFeaturedProducts(8);

  if (featured.length === 0) return null;

  return (
    <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-6 flex items-end justify-between">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wide text-borgona">Seleccionados para vos</span>
          <h2 className="font-display text-2xl font-semibold text-carbon sm:text-3xl">Productos destacados</h2>
        </div>
        <Link href="/destacados" className="hidden items-center gap-1 text-sm font-medium text-borgona hover:underline sm:flex">
          Ver todos <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:gap-5 md:grid-cols-3 lg:grid-cols-4">
        {featured.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      <Link
        href="/destacados"
        className="mt-6 flex items-center justify-center gap-1 text-sm font-medium text-borgona hover:underline sm:hidden"
      >
        Ver todos <ArrowRight className="h-4 w-4" />
      </Link>
    </section>
  );
}
