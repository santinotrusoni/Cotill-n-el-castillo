import Link from "next/link";
import { Logo } from "@/components/layout/Logo";

export function Hero() {
  return (
    <section className="ticket-edge-bottom relative overflow-hidden bg-carbon pb-14 pt-14 sm:pb-20 sm:pt-16">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
        <div>
          <span className="mb-4 inline-block rounded-full bg-dorado/15 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-dorado">
            Villa Dominico, Buenos Aires
          </span>
          <h1 className="font-display text-4xl font-semibold leading-[1.1] text-crema sm:text-5xl lg:text-6xl">
            Todo lo que necesitás,
            <br />
            <span className="italic text-rosa">en un solo lugar.</span>
          </h1>
          <p className="mt-5 max-w-md text-base text-crema/70 sm:text-lg">
            Cotillón, decoración, descartables y repostería para tus fiestas y eventos.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="/productos"
              className="rounded-full bg-rosa px-6 py-3 text-sm font-medium text-white transition-colors hover:bg-rosa-dark"
            >
              Ver productos
            </Link>
            <Link
              href="/ofertas"
              className="rounded-full border border-rosa/40 px-6 py-3 text-sm font-medium text-rosa transition-colors hover:bg-rosa/10"
            >
              Explorar ofertas
            </Link>
          </div>
        </div>

        <div className="mx-auto flex aspect-[4/3] w-full max-w-lg items-center justify-center rounded-xl2 border-4 border-crema/10 bg-crema p-6">
          <Logo className="h-52 sm:h-64" priority />
        </div>
      </div>
    </section>
  );
}
