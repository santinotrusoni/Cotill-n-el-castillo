import { Sparkles, HeartHandshake, Tag, ShieldCheck } from "lucide-react";

const BENEFITS = [
  {
    icon: Sparkles,
    title: "Gran variedad",
    text: "Más de 2.500 productos para cualquier evento.",
    colorClass: "bg-borgona/10 text-borgona",
  },
  {
    icon: HeartHandshake,
    title: "Atención personalizada",
    text: "Te ayudamos a elegir lo mejor para tu fiesta.",
    colorClass: "bg-exito/10 text-exito",
  },
  {
    icon: Tag,
    title: "Ofertas especiales",
    text: "Descuentos reales, todas las semanas.",
    colorClass: "bg-rosa/10 text-rosa",
  },
  {
    icon: ShieldCheck,
    title: "Productos de calidad",
    text: "Seleccionados para que tu evento salga perfecto.",
    colorClass: "bg-exito/10 text-exito",
  },
];

export function Benefits() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="grid grid-cols-2 gap-6 lg:grid-cols-4">
        {BENEFITS.map(({ icon: Icon, title, text, colorClass }) => (
          <div key={title} className="flex flex-col items-start gap-3">
            <span className={`flex h-11 w-11 items-center justify-center rounded-full ${colorClass}`}>
              <Icon className="h-5 w-5" aria-hidden />
            </span>
            <h3 className="font-medium text-carbon">{title}</h3>
            <p className="text-sm text-carbon/60">{text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
