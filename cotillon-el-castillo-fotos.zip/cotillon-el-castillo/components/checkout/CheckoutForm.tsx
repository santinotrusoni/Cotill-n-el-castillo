"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ShoppingBag, Truck, Store, Banknote, Landmark, AlertTriangle } from "lucide-react";
import { useCart } from "@/lib/cart-context";
import { formatPrice } from "@/lib/utils";
import { createOrderAction } from "@/lib/order-actions";
import { DeliveryMethod, PaymentMethod } from "@/lib/types";

export function CheckoutForm({ initialName = "", initialPhone = "" }: { initialName?: string; initialPhone?: string }) {
  const router = useRouter();
  const { items, getProduct, subtotal, discount, total, clearCart } = useCart();
  const [pending, startTransition] = useTransition();

  const [customerName, setCustomerName] = useState(initialName);
  const [customerPhone, setCustomerPhone] = useState(initialPhone);
  const [deliveryMethod, setDeliveryMethod] = useState<DeliveryMethod>("retiro");
  const [address, setAddress] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("efectivo");
  const [notes, setNotes] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState("");

  const lines = useMemo(
    () =>
      items
        .map((item) => ({ item, product: getProduct(item.productId) }))
        .filter((l): l is { item: typeof items[number]; product: NonNullable<ReturnType<typeof getProduct>> } => !!l.product),
    [items, getProduct]
  );

  if (items.length === 0) {
    return (
      <div className="mx-auto flex max-w-lg flex-col items-center gap-4 px-4 py-24 text-center">
        <ShoppingBag className="h-12 w-12 text-carbon/20" />
        <h1 className="font-display text-2xl font-semibold text-carbon">Tu carrito está vacío</h1>
        <p className="text-sm text-carbon/60">Agregá productos antes de finalizar un pedido.</p>
        <Link href="/productos" className="rounded-full bg-rosa px-6 py-3 text-sm font-medium text-white hover:bg-rosa-dark">
          Ver productos
        </Link>
      </div>
    );
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const nextErrors: Record<string, string> = {};
    if (!customerName.trim()) nextErrors.customerName = "Contanos tu nombre.";
    if (!customerPhone.trim()) nextErrors.customerPhone = "Necesitamos un teléfono de contacto.";
    if (deliveryMethod === "envio" && !address.trim()) nextErrors.address = "Ingresá la dirección de envío.";

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setSubmitError("");
    startTransition(async () => {
      try {
        const order = await createOrderAction({
          customerName: customerName.trim(),
          customerPhone: customerPhone.trim(),
          deliveryMethod,
          address: deliveryMethod === "envio" ? address.trim() : undefined,
          paymentMethod,
          notes: notes.trim() || undefined,
          items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
        });
        clearCart();
        router.push(`/pedido/${order.id}`);
      } catch (err) {
        setSubmitError(err instanceof Error ? err.message : "No pudimos generar el pedido. Probá de nuevo.");
      }
    });
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-8 lg:grid-cols-[1fr_320px]">
      <div className="space-y-6">
        <div className="rounded-xl2 bg-white p-5 shadow-card sm:p-6">
          <h2 className="mb-4 font-display text-lg font-semibold text-carbon">Tus datos</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-carbon">Nombre y apellido</label>
              <input
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className={`w-full rounded-lg border px-3.5 py-2.5 text-sm outline-none transition-colors ${
                  errors.customerName ? "border-error" : "border-crema-dark focus:border-borgona"
                }`}
              />
              {errors.customerName && <p className="mt-1 text-xs text-error">{errors.customerName}</p>}
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-carbon">Teléfono</label>
              <input
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                placeholder="11 1234-5678"
                className={`w-full rounded-lg border px-3.5 py-2.5 text-sm outline-none transition-colors ${
                  errors.customerPhone ? "border-error" : "border-crema-dark focus:border-borgona"
                }`}
              />
              {errors.customerPhone && <p className="mt-1 text-xs text-error">{errors.customerPhone}</p>}
            </div>
          </div>
        </div>

        <div className="rounded-xl2 bg-white p-5 shadow-card sm:p-6">
          <h2 className="mb-4 font-display text-lg font-semibold text-carbon">Entrega</h2>
          <div className="grid grid-cols-2 gap-3">
            <label
              className={`flex cursor-pointer items-center gap-2.5 rounded-lg border px-4 py-3 text-sm transition-colors ${
                deliveryMethod === "retiro" ? "border-exito bg-exito/5 font-medium text-exito" : "border-crema-dark text-carbon"
              }`}
            >
              <input
                type="radio"
                checked={deliveryMethod === "retiro"}
                onChange={() => setDeliveryMethod("retiro")}
                className="h-4 w-4 accent-exito"
              />
              <Store className="h-4 w-4" /> Retiro en local
            </label>
            <label
              className={`flex cursor-pointer items-center gap-2.5 rounded-lg border px-4 py-3 text-sm transition-colors ${
                deliveryMethod === "envio" ? "border-exito bg-exito/5 font-medium text-exito" : "border-crema-dark text-carbon"
              }`}
            >
              <input
                type="radio"
                checked={deliveryMethod === "envio"}
                onChange={() => setDeliveryMethod("envio")}
                className="h-4 w-4 accent-exito"
              />
              <Truck className="h-4 w-4" /> Envío a domicilio
            </label>
          </div>
          {deliveryMethod === "envio" && (
            <div className="mt-4">
              <label className="mb-1.5 block text-sm font-medium text-carbon">Dirección</label>
              <input
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Calle, número, localidad"
                className={`w-full rounded-lg border px-3.5 py-2.5 text-sm outline-none transition-colors ${
                  errors.address ? "border-error" : "border-crema-dark focus:border-borgona"
                }`}
              />
              {errors.address && <p className="mt-1 text-xs text-error">{errors.address}</p>}
            </div>
          )}
        </div>

        <div className="rounded-xl2 bg-white p-5 shadow-card sm:p-6">
          <h2 className="mb-4 font-display text-lg font-semibold text-carbon">Pago</h2>
          <div className="grid grid-cols-2 gap-3">
            <label
              className={`flex cursor-pointer items-center gap-2.5 rounded-lg border px-4 py-3 text-sm transition-colors ${
                paymentMethod === "efectivo" ? "border-exito bg-exito/5 font-medium text-exito" : "border-crema-dark text-carbon"
              }`}
            >
              <input
                type="radio"
                checked={paymentMethod === "efectivo"}
                onChange={() => setPaymentMethod("efectivo")}
                className="h-4 w-4 accent-exito"
              />
              <Banknote className="h-4 w-4" /> Efectivo
            </label>
            <label
              className={`flex cursor-pointer items-center gap-2.5 rounded-lg border px-4 py-3 text-sm transition-colors ${
                paymentMethod === "transferencia" ? "border-exito bg-exito/5 font-medium text-exito" : "border-crema-dark text-carbon"
              }`}
            >
              <input
                type="radio"
                checked={paymentMethod === "transferencia"}
                onChange={() => setPaymentMethod("transferencia")}
                className="h-4 w-4 accent-exito"
              />
              <Landmark className="h-4 w-4" /> Transferencia
            </label>
          </div>
          <p className="mt-2 text-xs text-carbon/50">
            El pago se coordina directamente con el local al confirmar el pedido — todavía no procesamos
            pagos online.
          </p>

          <div className="mt-4">
            <label className="mb-1.5 block text-sm font-medium text-carbon">Notas (opcional)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              placeholder="Aclaraciones sobre el pedido, horario de entrega, etc."
              className="w-full resize-none rounded-lg border border-crema-dark px-3.5 py-2.5 text-sm outline-none focus:border-borgona"
            />
          </div>
        </div>
      </div>

      <div className="h-fit rounded-xl2 bg-white p-5 shadow-card">
        <h2 className="mb-4 font-display text-lg font-semibold text-carbon">Tu pedido</h2>
        <ul className="divide-y divide-crema-dark">
          {lines.map(({ item, product }) => (
            <li key={item.productId} className="flex justify-between gap-2 py-2.5 text-sm">
              <span className="text-carbon/80">
                {product.name} <span className="text-carbon/40">x{item.quantity}</span>
              </span>
              <span className="shrink-0 font-medium text-carbon">{formatPrice(product.price * item.quantity)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-2 flex justify-between py-1 text-sm text-carbon/60">
          <span>Subtotal</span>
          <span>{formatPrice(subtotal + discount)}</span>
        </div>
        {discount > 0 && (
          <div className="flex justify-between py-1 text-sm text-exito">
            <span>Descuento</span>
            <span>-{formatPrice(discount)}</span>
          </div>
        )}
        <div className="mt-2 flex justify-between border-t border-crema-dark py-3 font-display text-xl font-semibold text-carbon">
          <span>Total</span>
          <span>{formatPrice(total)}</span>
        </div>

        {submitError && (
          <p className="mb-3 flex items-center gap-1.5 rounded-lg bg-error/10 px-3 py-2 text-xs text-error">
            <AlertTriangle className="h-3.5 w-3.5 shrink-0" /> {submitError}
          </p>
        )}

        <button
          type="submit"
          disabled={pending}
          className="w-full rounded-full bg-rosa py-3 text-sm font-medium text-white hover:bg-rosa-dark disabled:opacity-60"
        >
          {pending ? "Confirmando..." : "Confirmar pedido"}
        </button>
      </div>
    </form>
  );
}
