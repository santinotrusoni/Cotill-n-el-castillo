"use client";

import { useEffect, useRef, useState } from "react";

/**
 * Video de fondo del hero de Halloween.
 * - Sin sonido, en loop y con póster (carga rápida y compatible con iOS).
 * - El video arranca oscuro y termina claro, así que al reiniciar hacemos
 *   un fundido a negro en vez de un corte brusco.
 * - Si la persona prefiere menos movimiento, se queda el póster quieto.
 */
export function HalloweenVideo() {
  const ref = useRef<HTMLVideoElement>(null);
  const [visible, setVisible] = useState(true);
  const [reduceMotion, setReduceMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduceMotion(mq.matches);
  }, []);

  function handleEnded() {
    const video = ref.current;
    if (!video) return;
    setVisible(false);
    setTimeout(() => {
      video.currentTime = 0;
      video.play().catch(() => {});
      setVisible(true);
    }, 500);
  }

  if (reduceMotion) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src="/halloween/poster.jpg" alt="" className="absolute inset-0 h-full w-full object-cover" />;
  }

  return (
    <video
      ref={ref}
      className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-500 ${
        visible ? "opacity-100" : "opacity-0"
      }`}
      autoPlay
      muted
      playsInline
      preload="metadata"
      poster="/halloween/poster.jpg"
      onEnded={handleEnded}
      aria-hidden
    >
      <source src="/halloween/halloween.mp4" type="video/mp4" />
    </video>
  );
}
