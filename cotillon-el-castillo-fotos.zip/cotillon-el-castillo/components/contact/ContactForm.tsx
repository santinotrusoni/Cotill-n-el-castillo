"use client";

import { LogoBadge } from "@/components/layout/Logo";
import { useState } from "react";
import { Send, CheckCircle2, MapPin, Clock, Phone, Mail } from "lucide-react";
import { SiteSettings } from "@/lib/types";

export function ContactForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sent, setSent] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const nextErrors: Record<string, string> = {};
    if (!name.trim()) nextErrors.name = "Contanos tu nombre.";
    if (!email.trim()) nextErrors.email = "Necesitamos un email para responderte.";
    else if (!/^\S+@\S+\.\S+$/.test(email)) nextErrors.email = "Ese email no parece válido.";
    if (!message.trim()) nextErrors.message = "Escribinos tu consulta.";

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setSent(true);
    setName("");
    setEmail("");
    setMessage("");
  }

  if (sent) {
    return (
      <div className="flex flex-col items-center gap-3 rounded-xl2 bg-white p-8 text-center shadow-card">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-exito/10">
          <CheckCircle2 className="h-6 w-6 text-exito" aria-hidden />
        </div>
        <h2 className="font-display text-xl font-semibold text-carbon">¡Gracias por escribirnos!</h2>
        <p className="max-w-sm text-sm text-carbon/60">
          Recibimos tu mensaje y te vamos a responder a la brevedad. Si es urgente, escribinos directo por
          WhatsApp.
        </p>
        <button
          type="button"
          onClick={() => setSent(false)}
          className="mt-2 rounded-full border border-crema-dark px-5 py-2.5 text-sm font-medium text-carbon hover:border-exito hover:text-exito"
        >
          Enviar otra consulta
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="space-y-4 rounded-xl2 bg-white p-6 shadow-card sm:p-8">
      <div>
        <label htmlFor="contact-name" className="mb-1.5 block text-sm font-medium text-carbon">
          Nombre
        </label>
        <input
          id="contact-name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Tu nombre"
          className={`w-full rounded-lg border px-3.5 py-2.5 text-sm outline-none transition-colors ${
            errors.name ? "border-error" : "border-crema-dark focus:border-borgona"
          }`}
        />
        {errors.name && <p className="mt-1 text-xs text-error">{errors.name}</p>}
      </div>

      <div>
        <label htmlFor="contact-email" className="mb-1.5 block text-sm font-medium text-carbon">
          Email
        </label>
        <input
          id="contact-email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="tu@email.com"
          className={`w-full rounded-lg border px-3.5 py-2.5 text-sm outline-none transition-colors ${
            errors.email ? "border-error" : "border-crema-dark focus:border-borgona"
          }`}
        />
        {errors.email && <p className="mt-1 text-xs text-error">{errors.email}</p>}
      </div>

      <div>
        <label htmlFor="contact-message" className="mb-1.5 block text-sm font-medium text-carbon">
          Mensaje
        </label>
        <textarea
          id="contact-message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          rows={5}
          placeholder="Contanos qué necesitás para tu evento..."
          className={`w-full resize-none rounded-lg border px-3.5 py-2.5 text-sm outline-none transition-colors ${
            errors.message ? "border-error" : "border-crema-dark focus:border-borgona"
          }`}
        />
        {errors.message && <p className="mt-1 text-xs text-error">{errors.message}</p>}
      </div>

      <button
        type="submit"
        className="flex w-full items-center justify-center gap-2 rounded-full bg-rosa py-3 text-sm font-medium text-white transition-colors hover:bg-rosa-dark sm:w-auto sm:px-8"
      >
        <Send className="h-4 w-4" /> Enviar mensaje
      </button>
    </form>
  );
}

export function ContactInfo({ settings }: { settings: SiteSettings }) {
  return (
    <div className="space-y-5 rounded-xl2 bg-carbon p-6 text-crema/85 sm:p-8">
      <LogoBadge className="h-24" />
      <ul className="space-y-4 text-sm">
        <li className="flex items-start gap-3">
          <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-exito" />
          {settings.address}
        </li>
        <li className="flex items-start gap-3">
          <Clock className="mt-0.5 h-4 w-4 shrink-0 text-exito" />
          {settings.hours}
        </li>
        <li className="flex items-start gap-3">
          <Phone className="mt-0.5 h-4 w-4 shrink-0 text-exito" />
          WhatsApp disponible
        </li>
        <li className="flex items-start gap-3">
          <Mail className="mt-0.5 h-4 w-4 shrink-0 text-exito" />
          {settings.contactEmail}
        </li>
      </ul>
    </div>
  );
}
