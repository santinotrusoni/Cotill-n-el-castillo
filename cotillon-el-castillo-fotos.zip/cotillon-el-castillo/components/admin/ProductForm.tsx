"use client";

import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { ScanLine, Plus, Trash2, ImagePlus, Star, Loader2 } from "lucide-react";
import { Product, Category, Brand, ProductStatus, Attribute } from "@/lib/types";
import { placeholderImage, discountPercent, formatPrice } from "@/lib/utils";
import { createProductAction, updateProductAction } from "@/lib/admin-actions";
import { useAdminToast } from "@/lib/admin-toast-context";
import { uploadProductImageAction } from "@/lib/upload-actions";
import { resizeImage } from "@/lib/resize-image";
import { Modal } from "@/components/admin/Modal";
import { BarcodeScanner } from "@/components/scanner/BarcodeScanner";

interface ProductFormProps {
  mode: "create" | "edit";
  product?: Product;
  categories: Category[];
  brands: Brand[];
  attributes: Attribute[];
  initialBarcode?: string;
}

interface FormState {
  name: string;
  shortDescription: string;
  description: string;
  categoryId: string;
  brandId: string;
  sku: string;
  barcode: string;
  price: string;
  previousPrice: string;
  cost: string;
  stock: string;
  minStock: string;
  status: ProductStatus;
  featured: boolean;
  isNew: boolean;
  onOffer: boolean;
  images: string[];
  tags: string;
  features: string;
  attributeValues: Record<string, string>;
}

function initialState(product?: Product, initialBarcode?: string): FormState {
  return {
    name: product?.name ?? "",
    shortDescription: product?.shortDescription ?? "",
    description: product?.description ?? "",
    categoryId: product?.categoryId ?? "",
    brandId: product?.brandId ?? "",
    sku: product?.sku ?? "",
    barcode: product?.barcode ?? initialBarcode ?? "",
    price: product ? String(product.price) : "",
    previousPrice: product?.previousPrice ? String(product.previousPrice) : "",
    cost: product?.cost ? String(product.cost) : "",
    stock: product ? String(product.stock) : "0",
    minStock: product ? String(product.minStock) : "5",
    status: product?.status ?? "activo",
    featured: product?.featured ?? false,
    isNew: product?.isNew ?? false,
    onOffer: product?.onOffer ?? false,
    images: product?.images ?? [],
    tags: product?.tags?.join(", ") ?? "",
    features: product?.features?.join("\n") ?? "",
    attributeValues: Object.fromEntries((product?.attributeValues ?? []).map((av) => [av.attributeId, av.value])),
  };
}

export function ProductForm({ mode, product, categories, brands, attributes, initialBarcode }: ProductFormProps) {
  const [form, setForm] = useState<FormState>(() => initialState(product, initialBarcode));
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [scannerOpen, setScannerOpen] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(0);

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    const list = Array.from(files);
    setUploading((n) => n + list.length);
    for (const file of list) {
      try {
        const resized = await resizeImage(file);
        const fd = new FormData();
        fd.append("file", resized);
        const result = await uploadProductImageAction(fd);
        if (result.url) {
          const url = result.url;
          setForm((f) => ({ ...f, images: [...f.images, url] }));
        } else {
          showToast(`${file.name}: ${result.error ?? "no se pudo subir."}`, "error");
        }
      } catch {
        showToast(`${file.name}: no se pudo leer la imagen. Probá con un JPG o PNG.`, "error");
      } finally {
        setUploading((n) => n - 1);
      }
    }
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  function makeMainImage(index: number) {
    setForm((f) => {
      const next = [...f.images];
      const [picked] = next.splice(index, 1);
      return { ...f, images: [picked, ...next] };
    });
  }

  function setAttributeValue(attributeId: string, value: string) {
    setForm((f) => ({ ...f, attributeValues: { ...f.attributeValues, [attributeId]: value } }));
  }

  function validate(): boolean {
    const next: Partial<Record<keyof FormState, string>> = {};
    if (!form.name.trim()) next.name = "El nombre es obligatorio.";
    if (!form.categoryId) next.categoryId = "Elegí una categoría.";
    if (!form.brandId) next.brandId = "Elegí una marca.";
    if (!form.sku.trim()) next.sku = "El SKU es obligatorio.";
    if (!form.barcode.trim()) next.barcode = "El código de barras es obligatorio.";
    if (!form.price || Number(form.price) <= 0) next.price = "Ingresá un precio válido.";
    if (form.stock === "" || Number(form.stock) < 0) next.stock = "Ingresá un stock válido.";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (uploading > 0) {
      showToast("Esperá a que terminen de subirse las fotos.", "error");
      return;
    }
    if (!validate()) {
      showToast("Revisá los campos marcados en rojo.", "error");
      return;
    }

    const payload = {
      name: form.name.trim(),
      shortDescription: form.shortDescription.trim() || form.name.trim(),
      description: form.description.trim(),
      categoryId: form.categoryId,
      brandId: form.brandId,
      sku: form.sku.trim(),
      barcode: form.barcode.trim(),
      price: Number(form.price),
      previousPrice: form.previousPrice ? Number(form.previousPrice) : undefined,
      cost: form.cost ? Number(form.cost) : undefined,
      stock: Number(form.stock),
      minStock: Number(form.minStock) || 0,
      status: Number(form.stock) === 0 ? "sin_stock" as ProductStatus : form.status,
      featured: form.featured,
      isNew: form.isNew,
      onOffer: form.onOffer,
      images: form.images.length > 0 ? form.images : [placeholderImage(form.name.trim() || "Producto")],
      tags: form.tags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean),
      features: form.features
        .split("\n")
        .map((t) => t.trim())
        .filter(Boolean),
      attributeValues: Object.entries(form.attributeValues)
        .filter(([, value]) => value)
        .map(([attributeId, value]) => ({
          attributeId,
          attributeName: attributes.find((a) => a.id === attributeId)?.name ?? "",
          value,
        })),
    };

    startTransition(async () => {
      try {
        if (mode === "create") {
          await createProductAction(payload);
          showToast("Producto creado correctamente.");
        } else if (product) {
          await updateProductAction(product.id, payload);
          showToast("Producto actualizado correctamente.");
        }
        router.push("/admin/productos");
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo guardar el producto.", "error");
      }
    });
  }

  const discount = discountPercent(Number(form.price) || 0, form.previousPrice ? Number(form.previousPrice) : undefined);

  return (
    <>
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Información */}
        <Section title="Información">
          <Field label="Nombre" error={errors.name} className="sm:col-span-2">
            <input
              value={form.name}
              onChange={(e) => set("name", e.target.value)}
              className={inputClass(!!errors.name)}
              placeholder="Ej: Vasos de colores x 10u"
            />
          </Field>
          <Field label="Descripción corta" className="sm:col-span-2">
            <input
              value={form.shortDescription}
              onChange={(e) => set("shortDescription", e.target.value)}
              className={inputClass(false)}
              placeholder="Se usa en las cards del catálogo"
            />
          </Field>
          <Field label="Descripción completa" className="sm:col-span-2">
            <textarea
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
              rows={4}
              className={inputClass(false)}
            />
          </Field>
          <Field label="Categoría" error={errors.categoryId}>
            <select
              value={form.categoryId}
              onChange={(e) => set("categoryId", e.target.value)}
              className={inputClass(!!errors.categoryId)}
            >
              <option value="">Seleccionar...</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Marca" error={errors.brandId}>
            <select
              value={form.brandId}
              onChange={(e) => set("brandId", e.target.value)}
              className={inputClass(!!errors.brandId)}
            >
              <option value="">Seleccionar...</option>
              {brands.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="SKU" error={errors.sku}>
            <input
              value={form.sku}
              onChange={(e) => set("sku", e.target.value)}
              className={inputClass(!!errors.sku)}
            />
          </Field>
          <Field label="Código de barras" error={errors.barcode}>
            <div className="flex gap-2">
              <input
                value={form.barcode}
                onChange={(e) => set("barcode", e.target.value)}
                className={inputClass(!!errors.barcode)}
                inputMode="numeric"
              />
              <button
                type="button"
                onClick={() => setScannerOpen(true)}
                title="Escanear código"
                className="flex shrink-0 items-center gap-1.5 rounded-lg border border-adminBorder px-3 text-sm text-carbon hover:bg-adminBg"
              >
                <ScanLine className="h-4 w-4" />
              </button>
            </div>
          </Field>
        </Section>

        {/* Precio */}
        <Section title="Precio">
          <Field label="Precio" error={errors.price}>
            <input
              type="number"
              min={0}
              value={form.price}
              onChange={(e) => set("price", e.target.value)}
              className={inputClass(!!errors.price)}
            />
          </Field>
          <Field label="Precio anterior">
            <input
              type="number"
              min={0}
              value={form.previousPrice}
              onChange={(e) => set("previousPrice", e.target.value)}
              className={inputClass(false)}
            />
          </Field>
          <Field label="Costo">
            <input
              type="number"
              min={0}
              value={form.cost}
              onChange={(e) => set("cost", e.target.value)}
              className={inputClass(false)}
            />
          </Field>
          <div className="flex flex-col justify-between gap-2 sm:col-span-3 sm:flex-row sm:items-center">
            <Checkbox
              label="Marcar como oferta"
              checked={form.onOffer}
              onChange={(v) => set("onOffer", v)}
            />
            {discount > 0 && (
              <span className="w-fit rounded-full bg-dorado/15 px-3 py-1 text-xs font-semibold text-dorado">
                {discount}% OFF · {formatPrice(Number(form.price) || 0)}
              </span>
            )}
          </div>
        </Section>

        {/* Stock */}
        <Section title="Stock">
          <Field label="Stock actual" error={errors.stock}>
            <input
              type="number"
              min={0}
              value={form.stock}
              onChange={(e) => set("stock", e.target.value)}
              className={inputClass(!!errors.stock)}
            />
          </Field>
          <Field label="Stock mínimo">
            <input
              type="number"
              min={0}
              value={form.minStock}
              onChange={(e) => set("minStock", e.target.value)}
              className={inputClass(false)}
            />
          </Field>
          <Field label="Estado">
            <select
              value={form.status}
              onChange={(e) => set("status", e.target.value as ProductStatus)}
              disabled={Number(form.stock) === 0}
              className={`${inputClass(false)} disabled:cursor-not-allowed disabled:bg-adminBg disabled:text-adminMuted`}
            >
              <option value="activo">Activo</option>
              <option value="inactivo">Inactivo</option>
              <option value="sin_stock">Sin stock</option>
            </select>
          </Field>
          {Number(form.stock) === 0 && (
            <p className="text-xs text-adminMuted sm:col-span-3">
              Con stock 0 el producto se marca "Sin stock" automáticamente.
            </p>
          )}
        </Section>

        {/* Imágenes */}
        <Section title="Imágenes">
          <div className="sm:col-span-3">
            <div className="flex flex-wrap gap-3">
              {form.images.map((img, i) => (
                <div key={img + i} className="relative h-24 w-24 overflow-hidden rounded-lg border border-adminBorder">
                  <Image src={img} alt="" fill className="object-cover" sizes="96px" />
                  {i === 0 && (
                    <span className="absolute bottom-1 left-1 rounded bg-carbon/80 px-1.5 py-0.5 text-[10px] font-medium text-white">
                      Principal
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={() => set("images", form.images.filter((_, idx) => idx !== i))}
                    aria-label="Quitar imagen"
                    className="absolute right-1 top-1 rounded-full bg-black/60 p-1 text-white hover:bg-error"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                  {i > 0 && (
                    <button
                      type="button"
                      onClick={() => makeMainImage(i)}
                      aria-label="Usar como imagen principal"
                      title="Usar como principal"
                      className="absolute bottom-1 left-1 rounded-full bg-black/60 p-1 text-white hover:bg-borgona"
                    >
                      <Star className="h-3 w-3" />
                    </button>
                  )}
                </div>
              ))}
              {Array.from({ length: uploading }).map((_, i) => (
                <div
                  key={`up-${i}`}
                  className="flex h-24 w-24 items-center justify-center rounded-lg border border-adminBorder bg-adminBg text-adminMuted"
                >
                  <Loader2 className="h-5 w-5 animate-spin" aria-label="Subiendo" />
                </div>
              ))}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex h-24 w-24 flex-col items-center justify-center gap-1 rounded-lg border border-dashed border-adminBorder text-adminMuted hover:border-borgona hover:text-borgona"
              >
                <ImagePlus className="h-5 w-5" />
                <span className="text-[10px]">Subir fotos</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                multiple
                className="hidden"
                onChange={(e) => handleFiles(e.target.files)}
              />
            </div>
            <p className="mt-2 text-xs text-adminMuted">
              JPG, PNG o WebP. Las fotos se reducen solas para que carguen rápido. La primera es la principal
              (con la estrella cambiás cuál). Si no subís ninguna, se usa una imagen genérica.
            </p>
          </div>
        </Section>

        {/* Organización */}
        <Section title="Organización">
          <div className="flex flex-wrap gap-5 sm:col-span-3">
            <Checkbox label="Destacado" checked={form.featured} onChange={(v) => set("featured", v)} />
            <Checkbox label="Nuevo" checked={form.isNew} onChange={(v) => set("isNew", v)} />
          </div>
          <Field label="Etiquetas (separadas por coma)" className="sm:col-span-3">
            <input
              value={form.tags}
              onChange={(e) => set("tags", e.target.value)}
              className={inputClass(false)}
              placeholder="cumpleaños, infantil, económico"
            />
          </Field>
          <Field label="Características (una por línea)" className="sm:col-span-3">
            <textarea
              value={form.features}
              onChange={(e) => set("features", e.target.value)}
              rows={3}
              className={inputClass(false)}
            />
          </Field>
        </Section>

        {attributes.length > 0 && (
          <Section title="Atributos">
            {attributes.map((attr) => (
              <Field key={attr.id} label={attr.name}>
                <select
                  value={form.attributeValues[attr.id] ?? ""}
                  onChange={(e) => setAttributeValue(attr.id, e.target.value)}
                  className={inputClass(false)}
                >
                  <option value="">Sin especificar</option>
                  {attr.values.map((v) => (
                    <option key={v} value={v}>
                      {v}
                    </option>
                  ))}
                </select>
              </Field>
            ))}
          </Section>
        )}

        <div className="flex justify-end gap-3">
          <button
            type="button"
            onClick={() => router.push("/admin/productos")}
            className="rounded-full border border-adminBorder px-5 py-2.5 text-sm font-medium text-carbon hover:bg-adminBg"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={pending}
            className="rounded-full bg-borgona px-6 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-60"
          >
            {pending ? "Guardando..." : mode === "create" ? "Crear producto" : "Guardar cambios"}
          </button>
        </div>
      </form>

      {scannerOpen && (
        <Modal title="Escanear código de barras" onClose={() => setScannerOpen(false)}>
          <BarcodeScanner
            onDetected={(code) => {
              set("barcode", code);
              setScannerOpen(false);
              showToast(`Código escaneado: ${code}`);
            }}
            onError={(message) => showToast(message, "error")}
          />
        </Modal>
      )}
    </>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl2 border border-adminBorder bg-white p-6 shadow-card">
      <h2 className="mb-4 font-display text-base font-semibold text-carbon">{title}</h2>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">{children}</div>
    </div>
  );
}

function Field({
  label,
  error,
  className,
  children,
}: {
  label: string;
  error?: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <label className={`block text-sm ${className ?? ""}`}>
      <span className="mb-1.5 block font-medium text-carbon/80">{label}</span>
      {children}
      {error && <span className="mt-1 block text-xs text-error">{error}</span>}
    </label>
  );
}

function Checkbox({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-2 text-sm text-carbon/80">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="h-4 w-4 rounded border-adminBorder text-borgona focus:ring-borgona"
      />
      {label}
    </label>
  );
}

function inputClass(hasError: boolean) {
  return `w-full rounded-lg border px-3 py-2.5 text-sm text-carbon outline-none transition-colors ${
    hasError ? "border-error" : "border-adminBorder focus:border-borgona"
  }`;
}
