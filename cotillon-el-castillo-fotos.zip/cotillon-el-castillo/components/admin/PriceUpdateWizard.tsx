"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Search,
  Percent,
  Banknote,
  Tag,
  ListChecks,
} from "lucide-react";
import { Product, Category, Brand, PriceUpdateType, RoundingOption } from "@/lib/types";
import { formatPrice } from "@/lib/utils";
import { computeNewPrice, ROUNDING_OPTIONS } from "@/lib/pricing";
import { applyPriceUpdateAction } from "@/lib/admin-actions";
import { useAdminToast } from "@/lib/admin-toast-context";
import { ConfirmDialog } from "@/components/admin/ConfirmDialog";

type SelectionMode = "todos" | "categoria" | "marca" | "manual";
type Availability = "" | "en_stock" | "sin_stock";
type Estado = "" | "activo" | "inactivo" | "sin_stock";

const STEPS = ["Seleccionar productos", "Método de actualización", "Revisar y confirmar"];

const ROUNDING_LABELS: Record<RoundingOption, string> = {
  0: "Sin redondeo",
  10: "Redondear a $10",
  50: "Redondear a $50",
  100: "Redondear a $100",
  500: "Redondear a $500",
  1000: "Redondear a $1.000",
};

export function PriceUpdateWizard({
  products,
  categories,
  brands,
}: {
  products: Product[];
  categories: Category[];
  brands: Brand[];
}) {
  const router = useRouter();
  const { showToast } = useAdminToast();
  const [pending, startTransition] = useTransition();

  const [step, setStep] = useState(1);

  // Paso 1 — selección de productos
  const [mode, setMode] = useState<SelectionMode>("todos");
  const [categoryId, setCategoryId] = useState("");
  const [brandId, setBrandId] = useState("");
  const [manualIds, setManualIds] = useState<Set<string>>(new Set());
  const [manualQuery, setManualQuery] = useState("");
  const [estado, setEstado] = useState<Estado>("");
  const [availability, setAvailability] = useState<Availability>("");
  const [onlyOffer, setOnlyOffer] = useState(false);
  const [onlyFeatured, setOnlyFeatured] = useState(false);
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");

  // Paso 2 — método de actualización
  const [type, setType] = useState<PriceUpdateType>("porcentaje");
  const [value, setValue] = useState("10");
  const [rounding, setRounding] = useState<RoundingOption>(0);

  // Paso 3 — confirmación
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [successCount, setSuccessCount] = useState<number | null>(null);

  const baseFiltered = useMemo(() => {
    return products.filter((p) => {
      if (mode === "categoria" && categoryId && p.categoryId !== categoryId) return false;
      if (mode === "marca" && brandId && p.brandId !== brandId) return false;
      if (estado && p.status !== estado) return false;
      if (availability === "en_stock" && (p.status === "sin_stock" || p.stock === 0)) return false;
      if (availability === "sin_stock" && p.status !== "sin_stock" && p.stock !== 0) return false;
      if (onlyOffer && !p.onOffer) return false;
      if (onlyFeatured && !p.featured) return false;
      if (minPrice && p.price < Number(minPrice)) return false;
      if (maxPrice && p.price > Number(maxPrice)) return false;
      return true;
    });
  }, [products, mode, categoryId, brandId, estado, availability, onlyOffer, onlyFeatured, minPrice, maxPrice]);

  const selectedProducts = useMemo(() => {
    if (mode === "manual") return baseFiltered.filter((p) => manualIds.has(p.id));
    return baseFiltered;
  }, [mode, baseFiltered, manualIds]);

  const manualVisible = useMemo(() => {
    if (!manualQuery.trim()) return baseFiltered;
    const q = manualQuery.trim().toLowerCase();
    return baseFiltered.filter((p) => `${p.name} ${p.sku} ${p.barcode}`.toLowerCase().includes(q));
  }, [baseFiltered, manualQuery]);

  const numericValue = Number(value.replace(",", "."));

  const preview = useMemo(
    () =>
      selectedProducts.map((p) => ({
        product: p,
        newPrice: computeNewPrice(p.price, type, numericValue || 0, rounding),
      })),
    [selectedProducts, type, numericValue, rounding]
  );

  const totals = useMemo(() => {
    const currentTotal = preview.reduce((s, r) => s + r.product.price, 0);
    const newTotal = preview.reduce((s, r) => s + r.newPrice, 0);
    const enStock = selectedProducts.filter((p) => p.status !== "sin_stock" && p.stock > 0).length;
    const sinStock = selectedProducts.length - enStock;
    return { currentTotal, newTotal, enStock, sinStock, diff: newTotal - currentTotal };
  }, [preview, selectedProducts]);

  function toggleManual(id: string) {
    setManualIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function selectAllVisible() {
    setManualIds((prev) => {
      const next = new Set(prev);
      manualVisible.forEach((p) => next.add(p.id));
      return next;
    });
  }

  const canGoStep2 = selectedProducts.length > 0;
  const canGoStep3 = value.trim() !== "" && !Number.isNaN(numericValue) && (type === "monto_fijo" || numericValue >= 0 || type === "porcentaje");

  function resetWizard() {
    setStep(1);
    setMode("todos");
    setCategoryId("");
    setBrandId("");
    setManualIds(new Set());
    setManualQuery("");
    setEstado("");
    setAvailability("");
    setOnlyOffer(false);
    setOnlyFeatured(false);
    setMinPrice("");
    setMaxPrice("");
    setType("porcentaje");
    setValue("10");
    setRounding(0);
    setSuccessCount(null);
  }

  function handleConfirm() {
    startTransition(async () => {
      try {
        const entry = await applyPriceUpdateAction({
          productIds: selectedProducts.map((p) => p.id),
          type,
          value: numericValue,
          rounding,
        });
        setConfirmOpen(false);
        setSuccessCount(entry.affectedProductIds.length);
        showToast(`Se actualizaron ${entry.affectedProductIds.length} productos correctamente.`);
        router.refresh();
      } catch (err) {
        setConfirmOpen(false);
        showToast(err instanceof Error ? err.message : "No se pudo aplicar la actualización.", "error");
      }
    });
  }

  if (successCount !== null) {
    return (
      <div className="flex flex-col items-center gap-4 rounded-xl2 border border-adminBorder bg-white px-6 py-16 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-exito/10">
          <CheckCircle2 className="h-7 w-7 text-exito" aria-hidden />
        </div>
        <div>
          <h2 className="font-display text-xl font-semibold text-carbon">¡Precios actualizados!</h2>
          <p className="mt-1 max-w-sm text-sm text-adminMuted">
            Se modificaron {successCount} producto{successCount === 1 ? "" : "s"}. Podés revisar el
            detalle o revertir el cambio en cualquier momento desde el historial.
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-3">
          <button
            type="button"
            onClick={resetWizard}
            className="rounded-full border border-adminBorder px-5 py-2.5 text-sm font-medium text-carbon hover:bg-adminBg"
          >
            Nueva actualización
          </button>
          <Link
            href="/admin/precios/historial"
            className="rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark"
          >
            Ver historial
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Indicador de pasos */}
      <ol className="flex flex-wrap gap-2">
        {STEPS.map((label, i) => {
          const n = i + 1;
          const active = step === n;
          const done = step > n;
          return (
            <li key={label} className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  if (n === 1 || (n === 2 && canGoStep2) || (n === 3 && canGoStep2 && canGoStep3)) setStep(n);
                }}
                className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                  active
                    ? "bg-borgona text-white"
                    : done
                    ? "bg-exito/10 text-exito"
                    : "bg-adminBg text-adminMuted"
                }`}
              >
                <span
                  className={`flex h-5 w-5 items-center justify-center rounded-full text-xs ${
                    active ? "bg-white/20" : "bg-white"
                  }`}
                >
                  {done ? <CheckCircle2 className="h-4 w-4" /> : n}
                </span>
                {label}
              </button>
              {n < STEPS.length && <ChevronRight className="h-4 w-4 text-adminMuted/50" />}
            </li>
          );
        })}
      </ol>

      <div className="rounded-xl2 border border-adminBorder bg-white p-5 sm:p-6">
        {step === 1 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-lg font-semibold text-carbon">1. Seleccionar productos</h2>
              <p className="mt-1 text-sm text-adminMuted">
                Elegí qué productos van a recibir el cambio de precio.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {(
                [
                  { id: "todos", label: "Todos los productos" },
                  { id: "categoria", label: "Una categoría" },
                  { id: "marca", label: "Una marca" },
                  { id: "manual", label: "Seleccionar productos" },
                ] as { id: SelectionMode; label: string }[]
              ).map((opt) => (
                <label
                  key={opt.id}
                  className={`flex cursor-pointer items-center gap-2.5 rounded-lg border px-4 py-3 text-sm transition-colors ${
                    mode === opt.id
                      ? "border-borgona bg-borgona/5 font-medium text-borgona"
                      : "border-adminBorder text-carbon hover:bg-adminBg"
                  }`}
                >
                  <input
                    type="radio"
                    name="selection-mode"
                    className="h-4 w-4 accent-borgona"
                    checked={mode === opt.id}
                    onChange={() => setMode(opt.id)}
                  />
                  {opt.label}
                </label>
              ))}
            </div>

            {mode === "categoria" && (
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="w-full max-w-sm rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
              >
                <option value="">Todas las categorías</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            )}

            {mode === "marca" && (
              <select
                value={brandId}
                onChange={(e) => setBrandId(e.target.value)}
                className="w-full max-w-sm rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
              >
                <option value="">Todas las marcas</option>
                {brands.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            )}

            {/* Filtros adicionales, combinables con cualquier modo */}
            <div className="grid grid-cols-2 gap-3 rounded-lg bg-adminBg p-4 sm:grid-cols-3 lg:grid-cols-6">
              <select
                value={estado}
                onChange={(e) => setEstado(e.target.value as Estado)}
                className="rounded-lg border border-adminBorder px-2.5 py-2 text-xs text-carbon outline-none focus:border-borgona sm:text-sm"
              >
                <option value="">Estado: todos</option>
                <option value="activo">Activo</option>
                <option value="inactivo">Inactivo</option>
                <option value="sin_stock">Sin stock</option>
              </select>
              <select
                value={availability}
                onChange={(e) => setAvailability(e.target.value as Availability)}
                className="rounded-lg border border-adminBorder px-2.5 py-2 text-xs text-carbon outline-none focus:border-borgona sm:text-sm"
              >
                <option value="">Disponibilidad: todas</option>
                <option value="en_stock">En stock</option>
                <option value="sin_stock">Sin stock</option>
              </select>
              <input
                type="number"
                placeholder="Precio mín."
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                className="rounded-lg border border-adminBorder px-2.5 py-2 text-xs outline-none focus:border-borgona sm:text-sm"
              />
              <input
                type="number"
                placeholder="Precio máx."
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                className="rounded-lg border border-adminBorder px-2.5 py-2 text-xs outline-none focus:border-borgona sm:text-sm"
              />
              <label className="flex items-center gap-2 rounded-lg border border-adminBorder bg-white px-2.5 py-2 text-xs sm:text-sm">
                <input
                  type="checkbox"
                  checked={onlyOffer}
                  onChange={(e) => setOnlyOffer(e.target.checked)}
                  className="h-4 w-4 accent-borgona"
                />
                Solo ofertas
              </label>
              <label className="flex items-center gap-2 rounded-lg border border-adminBorder bg-white px-2.5 py-2 text-xs sm:text-sm">
                <input
                  type="checkbox"
                  checked={onlyFeatured}
                  onChange={(e) => setOnlyFeatured(e.target.checked)}
                  className="h-4 w-4 accent-borgona"
                />
                Solo destacados
              </label>
            </div>

            {mode === "manual" && (
              <div className="rounded-lg border border-adminBorder">
                <div className="flex flex-wrap items-center gap-3 border-b border-adminBorder p-3">
                  <div className="relative flex-1 min-w-[200px]">
                    <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-adminMuted" />
                    <input
                      type="text"
                      value={manualQuery}
                      onChange={(e) => setManualQuery(e.target.value)}
                      placeholder="Buscar por nombre, SKU o código de barras..."
                      className="w-full rounded-lg border border-adminBorder py-2 pl-9 pr-3 text-sm outline-none focus:border-borgona"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={selectAllVisible}
                    className="rounded-full border border-adminBorder px-3 py-1.5 text-xs font-medium text-carbon hover:bg-adminBg"
                  >
                    Seleccionar visibles
                  </button>
                  <button
                    type="button"
                    onClick={() => setManualIds(new Set())}
                    className="rounded-full border border-adminBorder px-3 py-1.5 text-xs font-medium text-carbon hover:bg-adminBg"
                  >
                    Limpiar selección
                  </button>
                </div>
                <div className="max-h-72 overflow-y-auto divide-y divide-adminBorder">
                  {manualVisible.length === 0 && (
                    <p className="px-4 py-6 text-center text-sm text-adminMuted">
                      No hay productos que coincidan.
                    </p>
                  )}
                  {manualVisible.map((p) => (
                    <label
                      key={p.id}
                      className="flex cursor-pointer items-center gap-3 px-4 py-2.5 text-sm hover:bg-adminBg"
                    >
                      <input
                        type="checkbox"
                        checked={manualIds.has(p.id)}
                        onChange={() => toggleManual(p.id)}
                        className="h-4 w-4 accent-borgona"
                      />
                      <span className="flex-1 truncate text-carbon">{p.name}</span>
                      <span className="text-xs text-adminMuted">{formatPrice(p.price)}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            <div className="flex items-center gap-2 rounded-lg bg-borgona/5 px-4 py-3 text-sm font-medium text-borgona">
              <ListChecks className="h-4 w-4 shrink-0" />
              {selectedProducts.length} producto{selectedProducts.length === 1 ? "" : "s"} coincide
              {selectedProducts.length === 1 ? "" : "n"} con la selección.
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-lg font-semibold text-carbon">2. Método de actualización</h2>
              <p className="mt-1 text-sm text-adminMuted">
                Elegí cómo se van a recalcular los {selectedProducts.length} precios seleccionados.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              {(
                [
                  { id: "porcentaje", label: "Porcentaje", icon: Percent, hint: "Ej: +10% o -15%" },
                  { id: "monto_fijo", label: "Monto fijo", icon: Banknote, hint: "Ej: +$500 o -$200" },
                  { id: "precio_especifico", label: "Precio específico", icon: Tag, hint: "Asigna un precio directo" },
                ] as { id: PriceUpdateType; label: string; icon: typeof Percent; hint: string }[]
              ).map((opt) => (
                <label
                  key={opt.id}
                  className={`flex cursor-pointer flex-col gap-1 rounded-lg border px-4 py-3 text-sm transition-colors ${
                    type === opt.id
                      ? "border-borgona bg-borgona/5"
                      : "border-adminBorder hover:bg-adminBg"
                  }`}
                >
                  <span className="flex items-center gap-2 font-medium text-carbon">
                    <input
                      type="radio"
                      name="update-type"
                      checked={type === opt.id}
                      onChange={() => setType(opt.id)}
                      className="h-4 w-4 accent-borgona"
                    />
                    <opt.icon className="h-4 w-4 text-borgona" /> {opt.label}
                  </span>
                  <span className="pl-6 text-xs text-adminMuted">{opt.hint}</span>
                </label>
              ))}
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-carbon">
                  {type === "porcentaje"
                    ? "Porcentaje (usá negativo para descuento)"
                    : type === "monto_fijo"
                    ? "Monto (usá negativo para descuento)"
                    : "Precio nuevo"}
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    className="w-full rounded-lg border border-adminBorder px-3 py-2.5 pr-10 text-sm outline-none focus:border-borgona"
                  />
                  <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-sm text-adminMuted">
                    {type === "porcentaje" ? "%" : "$"}
                  </span>
                </div>
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-medium text-carbon">Redondeo</label>
                <select
                  value={rounding}
                  onChange={(e) => setRounding(Number(e.target.value) as RoundingOption)}
                  className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
                >
                  {ROUNDING_OPTIONS.map((r) => (
                    <option key={r} value={r}>
                      {ROUNDING_LABELS[r]}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {selectedProducts[0] && !Number.isNaN(numericValue) && (
              <div className="rounded-lg border border-dashed border-adminBorder bg-adminBg/60 px-4 py-3 text-sm text-carbon">
                Ejemplo — <span className="font-medium">{selectedProducts[0].name}</span>:{" "}
                {formatPrice(selectedProducts[0].price)} → {" "}
                <span className="font-semibold text-borgona">
                  {formatPrice(computeNewPrice(selectedProducts[0].price, type, numericValue || 0, rounding))}
                </span>
              </div>
            )}
          </div>
        )}

        {step === 3 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-lg font-semibold text-carbon">3. Revisar y confirmar</h2>
              <p className="mt-1 text-sm text-adminMuted">
                Ningún precio se modifica todavía. Revisá el resumen antes de confirmar.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
              {[
                { label: "Seleccionados", value: selectedProducts.length },
                { label: "En stock", value: totals.enStock },
                { label: "Sin stock", value: totals.sinStock },
                {
                  label: "Precio actual",
                  value: formatPrice(totals.currentTotal),
                },
                {
                  label: "Nuevo total",
                  value: formatPrice(totals.newTotal),
                },
                {
                  label: "Diferencia",
                  value: `${totals.diff >= 0 ? "+" : ""}${formatPrice(totals.diff)}`,
                },
              ].map((s) => (
                <div key={s.label} className="rounded-lg border border-adminBorder bg-adminBg/60 p-3">
                  <p className="text-[11px] uppercase tracking-wide text-adminMuted">{s.label}</p>
                  <p className="mt-1 font-display text-lg font-semibold text-carbon">{s.value}</p>
                </div>
              ))}
            </div>

            <div className="overflow-x-auto rounded-lg border border-adminBorder">
              <div className="max-h-80 overflow-y-auto">
                <table className="w-full text-left text-sm">
                  <thead className="sticky top-0 border-b border-adminBorder bg-adminBg text-xs uppercase tracking-wide text-adminMuted">
                    <tr>
                      <th className="px-4 py-2.5 font-medium">Producto</th>
                      <th className="px-4 py-2.5 font-medium">Actual</th>
                      <th className="px-4 py-2.5 font-medium">Nuevo</th>
                      <th className="px-4 py-2.5 font-medium text-right">Cambio</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-adminBorder">
                    {preview.slice(0, 60).map(({ product, newPrice }) => {
                      const diffPct =
                        product.price > 0 ? Math.round(((newPrice - product.price) / product.price) * 100) : 0;
                      return (
                        <tr key={product.id}>
                          <td className="px-4 py-2.5 text-carbon">{product.name}</td>
                          <td className="px-4 py-2.5 text-adminMuted">{formatPrice(product.price)}</td>
                          <td className="px-4 py-2.5 font-medium text-carbon">{formatPrice(newPrice)}</td>
                          <td
                            className={`px-4 py-2.5 text-right font-medium ${
                              diffPct > 0 ? "text-exito" : diffPct < 0 ? "text-error" : "text-adminMuted"
                            }`}
                          >
                            {diffPct > 0 ? "+" : ""}
                            {diffPct}%
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {preview.length > 60 && (
                <p className="border-t border-adminBorder bg-adminBg/60 px-4 py-2 text-xs text-adminMuted">
                  Mostrando 60 de {preview.length} productos afectados.
                </p>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Navegación */}
      <div className="flex justify-between">
        <button
          type="button"
          onClick={() => setStep((s) => Math.max(1, s - 1))}
          disabled={step === 1}
          className="flex items-center gap-1.5 rounded-full border border-adminBorder px-5 py-2.5 text-sm font-medium text-carbon hover:bg-adminBg disabled:opacity-40"
        >
          <ChevronLeft className="h-4 w-4" /> Atrás
        </button>

        {step < 3 ? (
          <button
            type="button"
            onClick={() => setStep((s) => Math.min(3, s + 1))}
            disabled={(step === 1 && !canGoStep2) || (step === 2 && !canGoStep3)}
            className="flex items-center gap-1.5 rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-40"
          >
            Siguiente <ChevronRight className="h-4 w-4" />
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setConfirmOpen(true)}
            className="rounded-full bg-borgona px-6 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark"
          >
            Confirmar actualización
          </button>
        )}
      </div>

      {confirmOpen && (
        <ConfirmDialog
          title="Confirmar actualización de precios"
          description={`Esta acción modificará ${selectedProducts.length} producto${
            selectedProducts.length === 1 ? "" : "s"
          }. Vas a poder revertirla después desde el historial.`}
          confirmLabel="Confirmar actualización"
          danger={false}
          pending={pending}
          onConfirm={handleConfirm}
          onClose={() => setConfirmOpen(false)}
        />
      )}
    </div>
  );
}
