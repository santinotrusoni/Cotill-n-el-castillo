"use client";

import { useMemo, useState } from "react";
import { Download, FileSpreadsheet, Shapes, Tags } from "lucide-react";
import { Product, Category, Brand } from "@/lib/types";
import { toCSV, downloadCSV } from "@/lib/csv";

type Scope = "todos" | "categoria" | "marca" | "ofertas" | "destacados" | "sin_stock";

export function ExportPanel({
  products,
  categories,
  brands,
}: {
  products: Product[];
  categories: Category[];
  brands: Brand[];
}) {
  const [scope, setScope] = useState<Scope>("todos");
  const [categoryId, setCategoryId] = useState("");
  const [brandId, setBrandId] = useState("");

  const categoryById = useMemo(() => new Map(categories.map((c) => [c.id, c])), [categories]);
  const brandById = useMemo(() => new Map(brands.map((b) => [b.id, b])), [brands]);

  const filtered = useMemo(() => {
    return products.filter((p) => {
      if (scope === "categoria" && categoryId && p.categoryId !== categoryId) return false;
      if (scope === "marca" && brandId && p.brandId !== brandId) return false;
      if (scope === "ofertas" && !p.onOffer) return false;
      if (scope === "destacados" && !p.featured) return false;
      if (scope === "sin_stock" && p.status !== "sin_stock" && p.stock !== 0) return false;
      return true;
    });
  }, [products, scope, categoryId, brandId]);

  function exportProducts() {
    const headers = [
      "nombre",
      "sku",
      "codigo_barras",
      "categoria",
      "marca",
      "precio",
      "precio_anterior",
      "stock",
      "estado",
      "destacado",
      "oferta",
      "descripcion",
    ];
    const rows = filtered.map((p) => [
      p.name,
      p.sku,
      p.barcode,
      categoryById.get(p.categoryId)?.name ?? "",
      brandById.get(p.brandId)?.name ?? "",
      p.price,
      p.previousPrice ?? "",
      p.stock,
      p.status,
      p.featured ? "si" : "no",
      p.onOffer ? "si" : "no",
      p.shortDescription,
    ]);
    downloadCSV(`cotillon-el-castillo-productos-${Date.now()}.csv`, toCSV(headers, rows));
  }

  function exportCategories() {
    const headers = ["nombre", "slug", "descripcion"];
    const rows = categories.map((c) => [c.name, c.slug, c.description]);
    downloadCSV(`cotillon-el-castillo-categorias-${Date.now()}.csv`, toCSV(headers, rows));
  }

  function exportBrands() {
    const headers = ["nombre", "slug"];
    const rows = brands.map((b) => [b.name, b.slug]);
    downloadCSV(`cotillon-el-castillo-marcas-${Date.now()}.csv`, toCSV(headers, rows));
  }

  return (
    <div className="space-y-6">
      <div className="rounded-xl2 border border-adminBorder bg-white p-5 sm:p-6">
        <h2 className="font-display text-lg font-semibold text-carbon">Exportar productos</h2>
        <p className="mt-1 text-sm text-adminMuted">Elegí qué parte del catálogo querés exportar.</p>

        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {(
            [
              { id: "todos", label: "Todos" },
              { id: "categoria", label: "Una categoría" },
              { id: "marca", label: "Una marca" },
              { id: "ofertas", label: "Solo ofertas" },
              { id: "destacados", label: "Solo destacados" },
              { id: "sin_stock", label: "Sin stock" },
            ] as { id: Scope; label: string }[]
          ).map((opt) => (
            <label
              key={opt.id}
              className={`flex cursor-pointer items-center gap-2 rounded-lg border px-3 py-2.5 text-xs font-medium transition-colors sm:text-sm ${
                scope === opt.id ? "border-borgona bg-borgona/5 text-borgona" : "border-adminBorder text-carbon hover:bg-adminBg"
              }`}
            >
              <input
                type="radio"
                name="export-scope"
                checked={scope === opt.id}
                onChange={() => setScope(opt.id)}
                className="h-4 w-4 accent-borgona"
              />
              {opt.label}
            </label>
          ))}
        </div>

        {scope === "categoria" && (
          <select
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            className="mt-4 w-full max-w-sm rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          >
            <option value="">Todas las categorías</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        )}
        {scope === "marca" && (
          <select
            value={brandId}
            onChange={(e) => setBrandId(e.target.value)}
            className="mt-4 w-full max-w-sm rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          >
            <option value="">Todas las marcas</option>
            {brands.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
        )}

        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-lg bg-adminBg px-4 py-3">
          <p className="text-sm text-carbon">
            <span className="font-semibold">{filtered.length}</span> producto{filtered.length === 1 ? "" : "s"} listo
            {filtered.length === 1 ? "" : "s"} para exportar.
          </p>
          <button
            type="button"
            onClick={exportProducts}
            disabled={filtered.length === 0}
            className="flex items-center gap-2 rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-40"
          >
            <Download className="h-4 w-4" /> Descargar CSV
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <button
          type="button"
          onClick={exportCategories}
          className="flex items-center gap-3 rounded-xl2 border border-adminBorder bg-white p-5 text-left hover:border-borgona"
        >
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-borgona/10">
            <Shapes className="h-5 w-5 text-borgona" />
          </span>
          <span>
            <span className="block text-sm font-semibold text-carbon">Exportar categorías</span>
            <span className="block text-xs text-adminMuted">{categories.length} categorías en CSV</span>
          </span>
        </button>
        <button
          type="button"
          onClick={exportBrands}
          className="flex items-center gap-3 rounded-xl2 border border-adminBorder bg-white p-5 text-left hover:border-borgona"
        >
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-borgona/10">
            <Tags className="h-5 w-5 text-borgona" />
          </span>
          <span>
            <span className="block text-sm font-semibold text-carbon">Exportar marcas</span>
            <span className="block text-xs text-adminMuted">{brands.length} marcas en CSV</span>
          </span>
        </button>
      </div>

      <p className="flex items-center gap-2 text-xs text-adminMuted">
        <FileSpreadsheet className="h-3.5 w-3.5" /> Los archivos se descargan en formato CSV, compatible con Excel
        y Google Sheets.
      </p>
    </div>
  );
}
