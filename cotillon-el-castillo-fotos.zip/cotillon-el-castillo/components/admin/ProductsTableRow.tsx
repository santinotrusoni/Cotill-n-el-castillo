"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { Pencil, Trash2, Power } from "lucide-react";
import { Product } from "@/lib/types";
import { AdminStatusBadge } from "@/components/admin/AdminStatusBadge";
import { ConfirmDialog } from "@/components/admin/ConfirmDialog";
import { useAdminToast } from "@/lib/admin-toast-context";
import { deleteProductAction, toggleProductStatusAction } from "@/lib/admin-actions";

export function ProductsTableRow({
  product,
  categoryName,
  formattedPrice,
}: {
  product: Product;
  categoryName: string;
  formattedPrice: string;
}) {
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function handleDelete() {
    startTransition(async () => {
      try {
        await deleteProductAction(product.id);
        showToast(`"${product.name}" fue eliminado.`);
        setConfirmingDelete(false);
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo eliminar.", "error");
      }
    });
  }

  function handleToggle() {
    startTransition(async () => {
      try {
        await toggleProductStatusAction(product.id);
        showToast(
          product.status === "activo"
            ? `"${product.name}" fue desactivado.`
            : `"${product.name}" fue activado.`
        );
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo actualizar.", "error");
      }
    });
  }

  return (
    <>
      <tr className="transition-colors hover:bg-adminBg/50">
        <td className="px-5 py-3">
          <div className="flex items-center gap-3">
            <div className="relative h-11 w-11 shrink-0 overflow-hidden rounded-lg bg-adminBg">
              <Image src={product.images[0]} alt={product.name} fill className="object-cover" sizes="44px" />
            </div>
            <div className="min-w-0">
              <p className="truncate font-medium text-carbon">{product.name}</p>
              <p className="text-xs text-adminMuted">SKU {product.sku}</p>
            </div>
          </div>
        </td>
        <td className="px-5 py-3 text-carbon/70">{categoryName}</td>
        <td className="px-5 py-3 text-carbon/70">{formattedPrice}</td>
        <td className="px-5 py-3 text-carbon/70">{product.stock}</td>
        <td className="px-5 py-3">
          <AdminStatusBadge status={product.status} />
        </td>
        <td className="px-5 py-3">
          <div className="flex items-center justify-end gap-1">
            <button
              type="button"
              onClick={handleToggle}
              disabled={pending}
              title={product.status === "activo" ? "Desactivar" : "Activar"}
              className="rounded-lg p-2 text-adminMuted transition-colors hover:bg-adminBg hover:text-carbon disabled:opacity-40"
            >
              <Power className="h-4 w-4" />
            </button>
            <Link
              href={`/admin/productos/${product.id}/editar`}
              title="Editar"
              className="rounded-lg p-2 text-adminMuted transition-colors hover:bg-adminBg hover:text-carbon"
            >
              <Pencil className="h-4 w-4" />
            </Link>
            <button
              type="button"
              onClick={() => setConfirmingDelete(true)}
              title="Eliminar"
              className="rounded-lg p-2 text-adminMuted transition-colors hover:bg-error/10 hover:text-error"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </td>
      </tr>

      {confirmingDelete && (
        <tr>
          <td colSpan={6} className="p-0">
            <ConfirmDialog
              title="Eliminar producto"
              description={`¿Seguro que querés eliminar "${product.name}"? Esta acción no se puede deshacer.`}
              confirmLabel="Eliminar"
              pending={pending}
              onConfirm={handleDelete}
              onClose={() => setConfirmingDelete(false)}
            />
          </td>
        </tr>
      )}
    </>
  );
}
