"use client";

import { useState } from "react";
import { AdminSidebar } from "./AdminSidebar";
import { AdminHeader } from "./AdminHeader";

export function AdminShell({
  children,
  user,
}: {
  children: React.ReactNode;
  user: { name: string; role: string };
}) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-adminBg">
      <AdminSidebar mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} role={user.role} />
      <div className="flex min-h-screen flex-1 flex-col lg:ml-64">
        <AdminHeader onMenuClick={() => setMobileOpen(true)} user={user} />
        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8 lg:py-8">{children}</main>
      </div>
    </div>
  );
}
