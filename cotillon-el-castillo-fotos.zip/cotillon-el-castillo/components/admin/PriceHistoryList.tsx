"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { History, Undo2, Eye, ShieldCheck } from "lucide-react";
import { PriceHistoryEntry, Product } from "@/lib/types";
import { formatPrice } from "@/lib/utils";
import { changeLabel } from "@/lib/pricing";
import { revertPriceUpdateAction } from "@/lib/admin-actions";
import { useAdminToast } from "@/lib/admin-toast-context";
import { Modal } from "@/components/admin/Modal";
import { ConfirmDialog } from "@/components/admin/ConfirmDialog";

function formatDate(iso: string): string {
  const d = new Date(iso);
  return `${d.toLocaleDateString("es-AR")} · ${d.toLocaleTimeString("es-AR", {
    hour: "2-digit",
    minute: "2-digit",
  })}`;
}

export function PriceHistoryList({ history, products }: { history: PriceHistoryEntry[]; products: Product[] }) {
  const router = useRouter();
  const { showToast } = useAdminToast();
  const [pending, startTransition] = useTransition();
  const [detail, setDetail] = useState<PriceHistoryEntry | null>(null);
  const [reverting, setReverting] = useState<PriceHistoryEntry | null>(null);

  const productsById = useMemo(() => new Map(products.map((p) => [p.id, p])), [products]);

  function handleRevert() {
    if (!reverting) return;
    startTransition(async () => {
      try {
        await revertPriceUpdateAction(reverting.id);
        showToast(`Se revirtió la actualización de ${reverting.affectedProductIds.length} productos.`);
        setReverting(null);
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo revertir.", "error");
      }
    });
  }

  if (history.length === 0) {
    return (
      <div className="flex flex-col items-center gap-3 rounded-xl2 border border-dashed border-adminBorder bg-white px-6 py-16 text-center">
        <History className="h-8 w-8 text-adminMuted" aria-hidden />
        <p className="text-sm text-adminMuted">
          Todavía no aplicaste ninguna actualización masiva de precios.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {history.map((entry) => (
        <div
          key={entry.id}
          className="flex flex-col gap-3 rounded-xl2 border border-adminBorder bg-white p-4 sm:flex-row sm:items-center sm:justify-between"
        >
          <div>
            <p className="text-sm font-medium text-carbon">{formatDate(entry.date)}</p>
            <p className="mt-0.5 text-sm text-adminMuted">
              <span className="font-semibold text-borgona">{changeLabel(entry.type as any, entry.value)}</span> ·{" "}
              {entry.affectedProductIds.length} producto{entry.affectedProductIds.length === 1 ? "" : "s"} · Usuario:{" "}
              {entry.user}
              {entry.ruleName && <> · Regla &quot;{entry.ruleName}&quot;</>}
            </p>
            {entry.reverted && (
              <span className="mt-1.5 inline-flex items-center gap-1 rounded-full bg-adminBg px-2 py-0.5 text-[11px] font-medium text-adminMuted">
                <ShieldCheck className="h-3 w-3" /> Revertida
              </span>
            )}
          </div>
          <div className="flex shrink-0 gap-2">
            <button
              type="button"
              onClick={() => setDetail(entry)}
              className="flex items-center gap-1.5 rounded-full border border-adminBorder px-4 py-2 text-xs font-medium text-carbon hover:bg-adminBg"
            >
              <Eye className="h-3.5 w-3.5" /> Ver cambios
            </button>
            {!entry.reverted && (
              <button
                type="button"
                onClick={() => setReverting(entry)}
                className="flex items-center gap-1.5 rounded-full border border-adminBorder px-4 py-2 text-xs font-medium text-carbon hover:bg-error/10 hover:text-error"
              >
                <Undo2 className="h-3.5 w-3.5" /> Revertir
              </button>
            )}
          </div>
        </div>
      ))}

      {detail && (
        <Modal title="Detalle de la actualización" onClose={() => setDetail(null)} maxWidth="lg">
          <p className="mb-4 text-sm text-adminMuted">
            {changeLabel(detail.type as any, detail.value)} aplicado el {formatDate(detail.date)} a{" "}
            {detail.affectedProductIds.length} productos.
          </p>
          <div className="max-h-96 overflow-auto rounded-lg border border-adminBorder">
            <table className="w-full text-left text-sm">
              <thead className="sticky top-0 border-b border-adminBorder bg-adminBg text-xs uppercase tracking-wide text-adminMuted">
                <tr>
                  <th className="px-4 py-2.5 font-medium">Producto</th>
                  <th className="px-4 py-2.5 font-medium">Precio anterior</th>
                  <th className="px-4 py-2.5 font-medium">Precio actual</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-adminBorder">
                {detail.affectedProductIds.slice(0, 100).map((id) => {
                  const product = productsById.get(id);
                  return (
                    <tr key={id}>
                      <td className="px-4 py-2.5 text-carbon">{product?.name ?? "(producto eliminado)"}</td>
                      <td className="px-4 py-2.5 text-adminMuted">{formatPrice(detail.previousPrices[id])}</td>
                      <td className="px-4 py-2.5 font-medium text-carbon">
                        {product ? formatPrice(product.price) : "—"}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Modal>
      )}

      {reverting && (
        <ConfirmDialog
          title="¿Revertir esta actualización?"
          description={`${reverting.affectedProductIds.length} productos volverán a su precio anterior.`}
          confirmLabel="Revertir actualización"
          pending={pending}
          onConfirm={handleRevert}
          onClose={() => setReverting(null)}
        />
      )}
    </div>
  );
}
