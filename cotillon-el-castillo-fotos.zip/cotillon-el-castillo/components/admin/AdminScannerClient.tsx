"use client";

import { useState } from "react";
import Link from "next/link";
import { ScanLine, Search, PackageSearch, Pencil, Plus, AlertTriangle, X } from "lucide-react";
import { Product } from "@/lib/types";
import { BarcodeScanner } from "@/components/scanner/BarcodeScanner";

type State =
  | { view: "idle" }
  | { view: "scanning" }
  | { view: "camera_error"; message: string }
  | { view: "found"; product: Product }
  | { view: "not_found"; code: string };

export function AdminScannerClient({ products }: { products: Product[] }) {
  const [state, setState] = useState<State>({ view: "idle" });
  const [manualCode, setManualCode] = useState("");

  function resolveCode(raw: string) {
    const code = raw.trim();
    if (!code) return;
    const product = products.find((p) => p.barcode === code);
    setState(product ? { view: "found", product } : { view: "not_found", code });
  }

  function reset() {
    setManualCode("");
    setState({ view: "idle" });
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2 lg:items-start">
      <div className="overflow-hidden rounded-xl2 border border-adminBorder bg-white shadow-card">
        {state.view === "idle" && (
          <div className="flex flex-col items-center gap-4 px-6 py-14 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-borgona/10">
              <ScanLine className="h-7 w-7 text-borgona" />
            </div>
            <h1 className="font-display text-xl font-semibold text-carbon">
              Escanear código de barras
            </h1>
            <p className="max-w-xs text-sm text-adminMuted">
              Escaneá un producto para editarlo directamente, o para crear uno nuevo con el
              código ya cargado.
            </p>
            <button
              type="button"
              onClick={() => setState({ view: "scanning" })}
              className="mt-1 rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark"
            >
              Iniciar escaneo
            </button>
          </div>
        )}

        {state.view === "scanning" && (
          <div className="p-3">
            <BarcodeScanner
              onDetected={resolveCode}
              onError={(message) => setState({ view: "camera_error", message })}
            />
            <button
              type="button"
              onClick={reset}
              className="mx-auto mt-3 flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-medium text-adminMuted hover:text-carbon"
            >
              <X className="h-3.5 w-3.5" /> Cancelar
            </button>
          </div>
        )}

        {state.view === "camera_error" && (
          <div className="flex flex-col items-center gap-3 px-6 py-14 text-center">
            <AlertTriangle className="h-7 w-7 text-error" />
            <p className="max-w-xs text-sm text-adminMuted">{state.message}</p>
            <button
              type="button"
              onClick={() => setState({ view: "scanning" })}
              className="rounded-full border border-adminBorder px-5 py-2 text-sm font-medium text-carbon hover:bg-adminBg"
            >
              Reintentar
            </button>
          </div>
        )}

        {state.view === "found" && (
          <div className="flex flex-col items-center gap-3 px-6 py-14 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-exito/10">
              <PackageSearch className="h-7 w-7 text-exito" />
            </div>
            <h2 className="font-display text-lg font-semibold text-carbon">{state.product.name}</h2>
            <p className="text-sm text-adminMuted">
              SKU {state.product.sku} · Código {state.product.barcode}
            </p>
            <Link
              href={`/admin/productos/${state.product.id}/editar`}
              className="mt-1 flex items-center gap-2 rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark"
            >
              <Pencil className="h-4 w-4" /> Editar producto
            </Link>
            <button type="button" onClick={reset} className="text-xs font-medium text-adminMuted hover:text-carbon">
              Escanear otro código
            </button>
          </div>
        )}

        {state.view === "not_found" && (
          <div className="flex flex-col items-center gap-3 px-6 py-14 text-center">
            <PackageSearch className="h-7 w-7 text-adminMuted" />
            <p className="text-sm text-adminMuted">
              Ningún producto usa el código <span className="font-mono text-carbon">{state.code}</span>.
            </p>
            <Link
              href={`/admin/productos/nuevo?barcode=${encodeURIComponent(state.code)}`}
              className="flex items-center gap-2 rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark"
            >
              <Plus className="h-4 w-4" /> Crear producto con este código
            </Link>
            <button type="button" onClick={reset} className="text-xs font-medium text-adminMuted hover:text-carbon">
              Intentar de nuevo
            </button>
          </div>
        )}
      </div>

      <div className="rounded-xl2 border border-adminBorder bg-white p-6 shadow-card">
        <h2 className="font-display text-base font-semibold text-carbon">Ingreso manual</h2>
        <p className="mt-1 text-sm text-adminMuted">Funciona aunque la cámara no esté disponible.</p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            resolveCode(manualCode);
          }}
          className="mt-4 flex gap-2"
        >
          <input
            value={manualCode}
            onChange={(e) => setManualCode(e.target.value)}
            inputMode="numeric"
            placeholder="7791234567890"
            className="flex-1 rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          />
          <button
            type="submit"
            disabled={!manualCode.trim()}
            className="flex items-center gap-2 rounded-lg bg-borgona px-4 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-50"
          >
            <Search className="h-4 w-4" /> Buscar
          </button>
        </form>
      </div>
    </div>
  );
}
