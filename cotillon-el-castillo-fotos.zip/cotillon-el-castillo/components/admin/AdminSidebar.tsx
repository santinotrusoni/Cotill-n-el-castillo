"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LogoBadge } from "@/components/layout/Logo";
import {
  LayoutDashboard,
  Package,
  Shapes,
  Tag,
  Percent,
  ShoppingBag,
  Users,
  SlidersHorizontal,
  ScanLine,
  Upload,
  Download,
  DollarSign,
  UserCog,
  Settings,
  Building2,
  X,
  type LucideIcon,
} from "lucide-react";

interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
  soon?: boolean;
  adminOnly?: boolean;
}

const GROUPS: { title: string; items: NavItem[] }[] = [
  {
    title: "Principal",
    items: [
      { label: "Dashboard", href: "/admin", icon: LayoutDashboard },
      { label: "Productos", href: "/admin/productos", icon: Package },
      { label: "Categorías", href: "/admin/categorias", icon: Shapes },
      { label: "Marcas", href: "/admin/marcas", icon: Tag },
      { label: "Ofertas", href: "/admin/ofertas", icon: Percent },
      { label: "Pedidos", href: "/admin/pedidos", icon: ShoppingBag },
      { label: "Clientes", href: "/admin/clientes", icon: Users },
      { label: "Atributos", href: "/admin/atributos", icon: SlidersHorizontal },
    ],
  },
  {
    title: "Herramientas",
    items: [
      { label: "Escanear código", href: "/admin/escanear", icon: ScanLine },
      { label: "Importar productos", href: "/admin/importar", icon: Upload },
      { label: "Exportar datos", href: "/admin/exportar", icon: Download },
      { label: "Actualización de precios", href: "/admin/precios", icon: DollarSign },
    ],
  },
  {
    title: "Configuración",
    items: [
      { label: "Usuarios", href: "/admin/usuarios", icon: UserCog, adminOnly: true },
      { label: "Ajustes", href: "/admin/ajustes", icon: Settings, adminOnly: true },
      { label: "Sucursales", href: "/admin/sucursales", icon: Building2 },
    ],
  },
];

export function AdminSidebar({
  mobileOpen,
  onClose,
  role,
}: {
  mobileOpen: boolean;
  onClose: () => void;
  role: string;
}) {
  const pathname = usePathname();

  function isActive(href: string) {
    if (href === "/admin") return pathname === "/admin";
    return pathname === href || pathname?.startsWith(href + "/");
  }

  const visibleGroups = GROUPS.map((group) => ({
    ...group,
    items: group.items.filter((item) => !item.adminOnly || role === "admin"),
  })).filter((group) => group.items.length > 0);

  const content = (
    <div className="flex h-full flex-col bg-carbon text-crema">
      <div className="flex items-center justify-between px-5 py-5">
        <Link href="/admin" aria-label="Cotillón El Castillo, panel admin" className="flex items-center gap-3">
          <LogoBadge className="h-12" />
          <span className="text-sm font-sans text-crema/50">admin</span>
        </Link>
        <button
          type="button"
          onClick={onClose}
          aria-label="Cerrar menú"
          className="rounded-full p-1.5 text-crema/60 hover:bg-white/10 lg:hidden"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <nav className="flex-1 space-y-6 overflow-y-auto px-3 pb-6">
        {visibleGroups.map((group) => (
          <div key={group.title}>
            <p className="mb-2 px-3 text-[11px] font-semibold uppercase tracking-wider text-crema/35">
              {group.title}
            </p>
            <ul className="space-y-0.5">
              {group.items.map((item) => {
                const active = isActive(item.href);
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      onClick={onClose}
                      className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                        active
                          ? "bg-borgona text-crema font-medium"
                          : "text-crema/65 hover:bg-white/5 hover:text-crema"
                      }`}
                    >
                      <item.icon className="h-4 w-4 shrink-0" aria-hidden />
                      <span className="flex-1">{item.label}</span>
                      {item.soon && (
                        <span className="rounded-full bg-white/10 px-1.5 py-0.5 text-[10px] font-medium text-crema/50">
                          Pronto
                        </span>
                      )}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      <div className="border-t border-white/10 px-5 py-4">
        <Link href="/" className="text-xs font-medium text-crema/50 hover:text-crema">
          ← Volver a la tienda
        </Link>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop */}
      <aside className="hidden w-64 shrink-0 lg:block">
        <div className="fixed h-screen w-64">{content}</div>
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={onClose} role="presentation" />
          <div className="absolute inset-y-0 left-0 w-72 shadow-2xl">{content}</div>
        </div>
      )}
    </>
  );
}
