import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  tone?: "default" | "warning" | "success";
}

const TONE_STYLES = {
  default: "bg-borgona/10 text-borgona",
  warning: "bg-error/10 text-error",
  success: "bg-exito/10 text-exito",
};

export function StatsCard({ label, value, icon: Icon, tone = "default" }: StatsCardProps) {
  return (
    <div className="rounded-xl2 border border-adminBorder bg-white p-5 shadow-card">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-adminMuted">{label}</span>
        <span className={`flex h-9 w-9 items-center justify-center rounded-full ${TONE_STYLES[tone]}`}>
          <Icon className="h-4.5 w-4.5" aria-hidden />
        </span>
      </div>
      <p className="mt-3 font-display text-3xl font-semibold text-carbon">{value}</p>
    </div>
  );
}
