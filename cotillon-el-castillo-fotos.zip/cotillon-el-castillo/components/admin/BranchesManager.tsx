"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Plus, Pencil, Trash2, MapPin, Power } from "lucide-react";
import { Branch, BranchInput } from "@/lib/types";
import { createBranchAction, updateBranchAction, deleteBranchAction } from "@/lib/admin-actions";
import { useAdminToast } from "@/lib/admin-toast-context";
import { Modal } from "@/components/admin/Modal";
import { ConfirmDialog } from "@/components/admin/ConfirmDialog";

export function BranchesManager({ branches }: { branches: Branch[] }) {
  const [editing, setEditing] = useState<Branch | null | "new">(null);
  const [deleting, setDeleting] = useState<Branch | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function handleDelete() {
    if (!deleting) return;
    startTransition(async () => {
      try {
        await deleteBranchAction(deleting.id);
        showToast(`Sucursal "${deleting.name}" eliminada.`);
        setDeleting(null);
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo eliminar.", "error");
      }
    });
  }

  function handleToggleActive(branch: Branch) {
    startTransition(async () => {
      try {
        await updateBranchAction(branch.id, { active: !branch.active });
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo actualizar.", "error");
      }
    });
  }

  return (
    <div>
      <div className="mb-4 flex justify-end">
        <button
          type="button"
          onClick={() => setEditing("new")}
          className="flex items-center gap-2 rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark"
        >
          <Plus className="h-4 w-4" /> Nueva sucursal
        </button>
      </div>

      {branches.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-xl2 border border-dashed border-adminBorder bg-white px-6 py-20 text-center">
          <MapPin className="h-8 w-8 text-adminMuted" />
          <p className="text-sm text-adminMuted">Todavía no cargaste ninguna sucursal.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {branches.map((b) => (
            <div
              key={b.id}
              className="flex flex-col gap-3 rounded-xl2 border border-adminBorder bg-white p-4 sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-display text-base font-semibold text-carbon">{b.name}</h3>
                  <span
                    className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${
                      b.active ? "bg-exito/10 text-exito" : "bg-adminBg text-adminMuted"
                    }`}
                  >
                    {b.active ? "Activa" : "Inactiva"}
                  </span>
                </div>
                <p className="mt-0.5 text-sm text-adminMuted">{b.address}</p>
                <p className="text-sm text-adminMuted">
                  {[b.phone, b.hours].filter(Boolean).join(" · ") || "Sin teléfono ni horario cargado"}
                </p>
              </div>
              <div className="flex shrink-0 gap-2">
                <button
                  type="button"
                  onClick={() => handleToggleActive(b)}
                  className="flex items-center gap-1.5 rounded-full border border-adminBorder px-3 py-2 text-xs font-medium text-carbon hover:bg-adminBg"
                >
                  <Power className="h-3.5 w-3.5" /> {b.active ? "Desactivar" : "Activar"}
                </button>
                <button
                  type="button"
                  onClick={() => setEditing(b)}
                  className="flex items-center justify-center rounded-full border border-adminBorder p-2 text-carbon hover:bg-adminBg"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setDeleting(b)}
                  className="flex items-center justify-center rounded-full border border-adminBorder p-2 text-adminMuted hover:bg-error/10 hover:text-error"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing && <BranchFormModal branch={editing === "new" ? undefined : editing} onClose={() => setEditing(null)} />}

      {deleting && (
        <ConfirmDialog
          title="Eliminar sucursal"
          description={`¿Seguro que querés eliminar "${deleting.name}"?`}
          confirmLabel="Eliminar"
          pending={pending}
          onConfirm={handleDelete}
          onClose={() => setDeleting(null)}
        />
      )}
    </div>
  );
}

function BranchFormModal({ branch, onClose }: { branch?: Branch; onClose: () => void }) {
  const isEdit = !!branch;
  const [name, setName] = useState(branch?.name ?? "");
  const [address, setAddress] = useState(branch?.address ?? "");
  const [phone, setPhone] = useState(branch?.phone ?? "");
  const [hours, setHours] = useState(branch?.hours ?? "");
  const [active, setActive] = useState(branch?.active ?? true);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !address.trim()) {
      showToast("Nombre y dirección son obligatorios.", "error");
      return;
    }
    const payload: BranchInput = {
      name: name.trim(),
      address: address.trim(),
      phone: phone.trim() || undefined,
      hours: hours.trim() || undefined,
      active,
    };
    startTransition(async () => {
      try {
        if (isEdit && branch) {
          await updateBranchAction(branch.id, payload);
          showToast("Sucursal actualizada.");
        } else {
          await createBranchAction(payload);
          showToast("Sucursal creada.");
        }
        onClose();
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo guardar.", "error");
      }
    });
  }

  return (
    <Modal title={isEdit ? "Editar sucursal" : "Nueva sucursal"} onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-carbon/80">Nombre</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ej: Casa Central"
            className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          />
        </label>
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-carbon/80">Dirección</span>
          <input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          />
        </label>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <label className="block text-sm">
            <span className="mb-1.5 block font-medium text-carbon/80">Teléfono (opcional)</span>
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
            />
          </label>
          <label className="block text-sm">
            <span className="mb-1.5 block font-medium text-carbon/80">Horario (opcional)</span>
            <input
              value={hours}
              onChange={(e) => setHours(e.target.value)}
              placeholder="Lun a Sáb de 9 a 19 h"
              className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
            />
          </label>
        </div>
        <label className="flex items-center gap-2.5 text-sm">
          <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} className="h-4 w-4 accent-borgona" />
          <span className="font-medium text-carbon/80">Sucursal activa</span>
        </label>
        <div className="flex justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded-full border border-adminBorder px-5 py-2.5 text-sm font-medium text-carbon hover:bg-adminBg"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={pending}
            className="rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-60"
          >
            {pending ? "Guardando..." : isEdit ? "Guardar cambios" : "Crear sucursal"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
