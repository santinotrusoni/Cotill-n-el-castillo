"use client";

import { useState, useTransition } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { Plus, Pencil, Trash2, Package } from "lucide-react";
import { Category } from "@/lib/types";
import { placeholderImage, slugify } from "@/lib/utils";
import { createCategoryAction, updateCategoryAction, deleteCategoryAction } from "@/lib/admin-actions";
import { useAdminToast } from "@/lib/admin-toast-context";
import { Modal } from "@/components/admin/Modal";
import { ConfirmDialog } from "@/components/admin/ConfirmDialog";

type CategoryWithCount = Category & { productCount: number };

export function CategoriesManager({ categories }: { categories: CategoryWithCount[] }) {
  const [editing, setEditing] = useState<Category | null | "new">(null);
  const [deleting, setDeleting] = useState<CategoryWithCount | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function handleDelete() {
    if (!deleting) return;
    startTransition(async () => {
      try {
        await deleteCategoryAction(deleting.id);
        showToast(`Categoría "${deleting.name}" eliminada.`);
        setDeleting(null);
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo eliminar.", "error");
      }
    });
  }

  return (
    <div>
      <div className="mb-4 flex justify-end">
        <button
          type="button"
          onClick={() => setEditing("new")}
          className="flex items-center gap-2 rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark"
        >
          <Plus className="h-4 w-4" /> Nueva categoría
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map((c) => (
          <div
            key={c.id}
            className="overflow-hidden rounded-xl2 border border-adminBorder bg-white shadow-card"
          >
            <div className="relative h-28 w-full bg-adminBg">
              <Image src={c.image} alt={c.name} fill className="object-cover" sizes="400px" />
            </div>
            <div className="p-4">
              <div className="flex items-start justify-between gap-2">
                <h3 className="font-display text-base font-semibold text-carbon">{c.name}</h3>
                <span className="flex shrink-0 items-center gap-1 rounded-full bg-adminBg px-2 py-1 text-xs text-adminMuted">
                  <Package className="h-3 w-3" /> {c.productCount}
                </span>
              </div>
              <p className="mt-1 line-clamp-2 text-xs text-adminMuted">{c.description}</p>
              <div className="mt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => setEditing(c)}
                  className="flex flex-1 items-center justify-center gap-1.5 rounded-full border border-adminBorder py-2 text-xs font-medium text-carbon hover:bg-adminBg"
                >
                  <Pencil className="h-3.5 w-3.5" /> Editar
                </button>
                <button
                  type="button"
                  onClick={() => setDeleting(c)}
                  className="flex items-center justify-center rounded-full border border-adminBorder p-2 text-adminMuted hover:bg-error/10 hover:text-error"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {editing && (
        <CategoryFormModal
          category={editing === "new" ? undefined : editing}
          onClose={() => setEditing(null)}
        />
      )}

      {deleting && (
        <ConfirmDialog
          title="Eliminar categoría"
          description={
            deleting.productCount > 0
              ? `"${deleting.name}" tiene ${deleting.productCount} producto(s) asignados. Reasignalos antes de eliminarla.`
              : `¿Seguro que querés eliminar "${deleting.name}"?`
          }
          confirmLabel="Eliminar"
          pending={pending}
          onConfirm={handleDelete}
          onClose={() => setDeleting(null)}
        />
      )}
    </div>
  );
}

function CategoryFormModal({ category, onClose }: { category?: Category; onClose: () => void }) {
  const isEdit = !!category;
  const [name, setName] = useState(category?.name ?? "");
  const [description, setDescription] = useState(category?.description ?? "");
  const [image, setImage] = useState(category?.image ?? "");
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      showToast("El nombre es obligatorio.", "error");
      return;
    }
    const payload = {
      name: name.trim(),
      slug: slugify(name.trim()),
      description: description.trim(),
      image: image.trim() || placeholderImage(name.trim()),
    };
    startTransition(async () => {
      try {
        if (isEdit && category) {
          await updateCategoryAction(category.id, payload);
          showToast("Categoría actualizada.");
        } else {
          await createCategoryAction(payload);
          showToast("Categoría creada.");
        }
        onClose();
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo guardar.", "error");
      }
    });
  }

  return (
    <Modal title={isEdit ? "Editar categoría" : "Nueva categoría"} onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-carbon/80">Nombre</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          />
        </label>
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-carbon/80">Descripción</span>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          />
        </label>
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-carbon/80">Imagen (URL, opcional)</span>
          <input
            value={image}
            onChange={(e) => setImage(e.target.value)}
            placeholder="Se genera un placeholder si lo dejás vacío"
            className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          />
        </label>
        <div className="flex justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded-full border border-adminBorder px-5 py-2.5 text-sm font-medium text-carbon hover:bg-adminBg"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={pending}
            className="rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-60"
          >
            {pending ? "Guardando..." : isEdit ? "Guardar cambios" : "Crear categoría"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
