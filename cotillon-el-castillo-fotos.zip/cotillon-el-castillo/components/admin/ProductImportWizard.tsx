"use client";

import { useMemo, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  Upload,
  FileText,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  ChevronLeft,
  ChevronRight,
  PackageCheck,
} from "lucide-react";
import { ProductImportRow } from "@/lib/types";
import { parseCSV } from "@/lib/csv";
import { formatPrice } from "@/lib/utils";
import { bulkImportProductsAction } from "@/lib/admin-actions";
import { useAdminToast } from "@/lib/admin-toast-context";
import { ConfirmDialog } from "@/components/admin/ConfirmDialog";

type SystemFieldKey = "name" | "barcode" | "sku" | "price" | "stock" | "categoryName" | "brandName" | "description";

const SYSTEM_FIELDS: { key: SystemFieldKey; label: string; required: boolean; synonyms: string[] }[] = [
  { key: "name", label: "Nombre", required: true, synonyms: ["nombre", "name", "producto"] },
  { key: "barcode", label: "Código de barras", required: true, synonyms: ["codigo_barras", "código de barras", "barcode", "ean"] },
  { key: "sku", label: "SKU", required: false, synonyms: ["sku", "codigo", "código"] },
  { key: "price", label: "Precio", required: true, synonyms: ["precio", "price"] },
  { key: "stock", label: "Stock", required: true, synonyms: ["stock", "cantidad"] },
  { key: "categoryName", label: "Categoría", required: false, synonyms: ["categoria", "categoría", "category"] },
  { key: "brandName", label: "Marca", required: false, synonyms: ["marca", "brand"] },
  { key: "description", label: "Descripción", required: false, synonyms: ["descripcion", "descripción", "description"] },
];

type Mapping = Record<SystemFieldKey, string>;

interface ValidatedRow {
  index: number;
  row: ProductImportRow;
  status: "ok" | "warning" | "error";
  messages: string[];
}

const STEPS = ["Subir archivo", "Mapear columnas", "Validar e importar"];

function normalize(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();
}

function autoMap(headers: string[]): Mapping {
  const mapping = {} as Mapping;
  for (const field of SYSTEM_FIELDS) {
    const match = headers.find((h) => field.synonyms.some((syn) => normalize(h) === normalize(syn)));
    mapping[field.key] = match ?? "";
  }
  return mapping;
}

export function ProductImportWizard({
  existingCategoryNames,
  existingBrandNames,
  existingBarcodes,
}: {
  existingCategoryNames: string[];
  existingBrandNames: string[];
  existingBarcodes: string[];
}) {
  const router = useRouter();
  const { showToast } = useAdminToast();
  const [pending, startTransition] = useTransition();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [step, setStep] = useState(1);
  const [fileName, setFileName] = useState("");
  const [headers, setHeaders] = useState<string[]>([]);
  const [rawRows, setRawRows] = useState<string[][]>([]);
  const [mapping, setMapping] = useState<Mapping | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [result, setResult] = useState<{ createdCount: number; updatedCount: number; skippedCount: number } | null>(
    null
  );

  const categorySet = useMemo(() => new Set(existingCategoryNames.map(normalize)), [existingCategoryNames]);
  const brandSet = useMemo(() => new Set(existingBrandNames.map(normalize)), [existingBrandNames]);
  const barcodeSet = useMemo(() => new Set(existingBarcodes), [existingBarcodes]);

  function handleFile(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result ?? "");
      const parsed = parseCSV(text);
      if (parsed.headers.length === 0 || parsed.rows.length === 0) {
        showToast("No se pudo leer el archivo. Verificá que sea un CSV válido.", "error");
        return;
      }
      setFileName(file.name);
      setHeaders(parsed.headers);
      setRawRows(parsed.rows);
      setMapping(autoMap(parsed.headers));
      setStep(2);
    };
    reader.onerror = () => showToast("No se pudo leer el archivo.", "error");
    reader.readAsText(file, "utf-8");
  }

  function handleDrop(e: React.DragEvent<HTMLDivElement>) {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  }

  const requiredMapped = useMemo(() => {
    if (!mapping) return false;
    return SYSTEM_FIELDS.filter((f) => f.required).every((f) => mapping[f.key]);
  }, [mapping]);

  const validated: ValidatedRow[] = useMemo(() => {
    if (!mapping) return [];
    const seenBarcodes = new Set<string>();
    const colIndex = (col: string) => headers.indexOf(col);

    return rawRows.map((cells, index) => {
      const get = (key: SystemFieldKey) => {
        const col = mapping[key];
        if (!col) return "";
        const i = colIndex(col);
        return i >= 0 ? (cells[i] ?? "").trim() : "";
      };

      const name = get("name");
      const barcode = get("barcode");
      const priceRaw = get("price").replace(",", ".").replace(/[^0-9.-]/g, "");
      const stockRaw = get("stock").replace(/[^0-9-]/g, "");
      const price = priceRaw ? Number(priceRaw) : NaN;
      const stock = stockRaw ? Number(stockRaw) : NaN;
      const categoryName = get("categoryName") || undefined;
      const brandName = get("brandName") || undefined;
      const description = get("description") || undefined;
      const sku = get("sku") || undefined;

      const messages: string[] = [];
      let status: ValidatedRow["status"] = "ok";

      if (!name) {
        messages.push("Falta el nombre.");
        status = "error";
      }
      if (!barcode) {
        messages.push("Falta el código de barras.");
        status = "error";
      } else if (seenBarcodes.has(barcode)) {
        messages.push("Código de barras duplicado dentro del archivo.");
        status = "error";
      }
      if (Number.isNaN(price) || price <= 0) {
        messages.push("Precio inválido.");
        status = "error";
      }
      if (Number.isNaN(stock) || stock < 0) {
        messages.push("Stock inválido.");
        status = "error";
      }

      if (status !== "error") {
        seenBarcodes.add(barcode);
        if (categoryName && !categorySet.has(normalize(categoryName))) {
          messages.push(`Categoría "${categoryName}" no encontrada, se usará la primera disponible.`);
          if (status === "ok") status = "warning";
        }
        if (brandName && !brandSet.has(normalize(brandName))) {
          messages.push(`Marca "${brandName}" no encontrada, se usará la primera disponible.`);
          if (status === "ok") status = "warning";
        }
        if (barcodeSet.has(barcode)) {
          messages.push("Ya existe un producto con este código — se va a actualizar.");
          if (status === "ok") status = "warning";
        }
      }

      return {
        index,
        row: { name, barcode, sku, price, stock, categoryName, brandName, description },
        status,
        messages,
      };
    });
  }, [mapping, rawRows, headers, categorySet, brandSet, barcodeSet]);

  const okCount = validated.filter((r) => r.status === "ok").length;
  const warningCount = validated.filter((r) => r.status === "warning").length;
  const errorCount = validated.filter((r) => r.status === "error").length;
  const importableCount = okCount + warningCount;

  function resetWizard() {
    setStep(1);
    setFileName("");
    setHeaders([]);
    setRawRows([]);
    setMapping(null);
    setResult(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  function handleConfirmImport() {
    const rowsToImport = validated.filter((r) => r.status !== "error").map((r) => r.row);
    startTransition(async () => {
      try {
        const res = await bulkImportProductsAction(rowsToImport);
        setConfirmOpen(false);
        setResult({ ...res, skippedCount: errorCount });
        showToast(`Importación completa: ${res.createdCount} creados, ${res.updatedCount} actualizados.`);
        router.refresh();
      } catch (err) {
        setConfirmOpen(false);
        showToast(err instanceof Error ? err.message : "No se pudo importar el archivo.", "error");
      }
    });
  }

  if (result) {
    return (
      <div className="flex flex-col items-center gap-4 rounded-xl2 border border-adminBorder bg-white px-6 py-16 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-exito/10">
          <PackageCheck className="h-7 w-7 text-exito" aria-hidden />
        </div>
        <div>
          <h2 className="font-display text-xl font-semibold text-carbon">¡Importación completa!</h2>
          <p className="mt-1 max-w-md text-sm text-adminMuted">
            {result.createdCount} producto{result.createdCount === 1 ? "" : "s"} creado
            {result.createdCount === 1 ? "" : "s"}, {result.updatedCount} actualizado
            {result.updatedCount === 1 ? "" : "s"}
            {result.skippedCount > 0 && (
              <>
                {" "}
                y {result.skippedCount} fila{result.skippedCount === 1 ? "" : "s"} con errores omitida
                {result.skippedCount === 1 ? "" : "s"}
              </>
            )}
            .
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-3">
          <button
            type="button"
            onClick={resetWizard}
            className="rounded-full border border-adminBorder px-5 py-2.5 text-sm font-medium text-carbon hover:bg-adminBg"
          >
            Importar otro archivo
          </button>
          <Link
            href="/admin/productos"
            className="rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark"
          >
            Ver productos
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <ol className="flex flex-wrap gap-2">
        {STEPS.map((label, i) => {
          const n = i + 1;
          const active = step === n;
          const done = step > n;
          return (
            <li key={label} className="flex items-center gap-2">
              <span
                className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium ${
                  active ? "bg-borgona text-white" : done ? "bg-exito/10 text-exito" : "bg-adminBg text-adminMuted"
                }`}
              >
                <span className={`flex h-5 w-5 items-center justify-center rounded-full text-xs ${active ? "bg-white/20" : "bg-white"}`}>
                  {done ? <CheckCircle2 className="h-4 w-4" /> : n}
                </span>
                {label}
              </span>
              {n < STEPS.length && <ChevronRight className="h-4 w-4 text-adminMuted/50" />}
            </li>
          );
        })}
      </ol>

      <div className="rounded-xl2 border border-adminBorder bg-white p-5 sm:p-6">
        {step === 1 && (
          <div className="space-y-4">
            <div>
              <h2 className="font-display text-lg font-semibold text-carbon">1. Subir archivo</h2>
              <p className="mt-1 text-sm text-adminMuted">
                Subí un CSV con tus productos. La primera fila debe tener los encabezados de columna.
              </p>
            </div>
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className="flex cursor-pointer flex-col items-center gap-3 rounded-xl2 border-2 border-dashed border-adminBorder bg-adminBg/60 px-6 py-14 text-center transition-colors hover:border-borgona"
            >
              <Upload className="h-8 w-8 text-adminMuted" aria-hidden />
              <p className="text-sm font-medium text-carbon">Arrastrá tu archivo CSV acá, o hacé clic para elegirlo</p>
              <p className="text-xs text-adminMuted">Columnas esperadas: nombre, código de barras, precio, stock, categoría, marca...</p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,text/csv"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFile(file);
                }}
              />
            </div>
          </div>
        )}

        {step === 2 && mapping && (
          <div className="space-y-5">
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-borgona" aria-hidden />
              <div>
                <h2 className="font-display text-lg font-semibold text-carbon">2. Mapear columnas</h2>
                <p className="text-sm text-adminMuted">
                  {fileName} · {rawRows.length} fila{rawRows.length === 1 ? "" : "s"} detectada
                  {rawRows.length === 1 ? "" : "s"}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {SYSTEM_FIELDS.map((field) => (
                <label key={field.key} className="block text-sm">
                  <span className="mb-1.5 block font-medium text-carbon/80">
                    {field.label} {field.required && <span className="text-error">*</span>}
                  </span>
                  <select
                    value={mapping[field.key]}
                    onChange={(e) => setMapping({ ...mapping, [field.key]: e.target.value })}
                    className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
                  >
                    <option value="">{field.required ? "Seleccionar columna..." : "No mapear"}</option>
                    {headers.map((h) => (
                      <option key={h} value={h}>
                        {h}
                      </option>
                    ))}
                  </select>
                </label>
              ))}
            </div>
            {!requiredMapped && (
              <p className="flex items-center gap-1.5 text-sm text-error">
                <AlertTriangle className="h-4 w-4" /> Mapeá todos los campos obligatorios (*) para continuar.
              </p>
            )}
          </div>
        )}

        {step === 3 && (
          <div className="space-y-5">
            <div>
              <h2 className="font-display text-lg font-semibold text-carbon">3. Validar e importar</h2>
              <p className="mt-1 text-sm text-adminMuted">
                Revisá el resultado antes de confirmar. Las filas con error se omiten automáticamente.
              </p>
            </div>

            <div className="flex flex-wrap gap-3">
              <span className="flex items-center gap-1.5 rounded-full bg-exito/10 px-3 py-1.5 text-sm font-medium text-exito">
                <CheckCircle2 className="h-4 w-4" /> {okCount} válidos
              </span>
              <span className="flex items-center gap-1.5 rounded-full bg-dorado/15 px-3 py-1.5 text-sm font-medium text-dorado">
                <AlertTriangle className="h-4 w-4" /> {warningCount} con advertencias
              </span>
              <span className="flex items-center gap-1.5 rounded-full bg-error/10 px-3 py-1.5 text-sm font-medium text-error">
                <XCircle className="h-4 w-4" /> {errorCount} con errores
              </span>
            </div>

            <div className="overflow-x-auto rounded-lg border border-adminBorder">
              <div className="max-h-96 overflow-y-auto">
                <table className="w-full text-left text-sm">
                  <thead className="sticky top-0 border-b border-adminBorder bg-adminBg text-xs uppercase tracking-wide text-adminMuted">
                    <tr>
                      <th className="px-3 py-2.5 font-medium">Estado</th>
                      <th className="px-3 py-2.5 font-medium">Nombre</th>
                      <th className="px-3 py-2.5 font-medium">Código</th>
                      <th className="px-3 py-2.5 font-medium">Precio</th>
                      <th className="px-3 py-2.5 font-medium">Stock</th>
                      <th className="px-3 py-2.5 font-medium">Notas</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-adminBorder">
                    {validated.slice(0, 80).map((r) => (
                      <tr key={r.index}>
                        <td className="px-3 py-2.5">
                          {r.status === "ok" && <CheckCircle2 className="h-4 w-4 text-exito" />}
                          {r.status === "warning" && <AlertTriangle className="h-4 w-4 text-dorado" />}
                          {r.status === "error" && <XCircle className="h-4 w-4 text-error" />}
                        </td>
                        <td className="px-3 py-2.5 text-carbon">{r.row.name || "—"}</td>
                        <td className="px-3 py-2.5 text-adminMuted">{r.row.barcode || "—"}</td>
                        <td className="px-3 py-2.5 text-adminMuted">
                          {Number.isNaN(r.row.price) ? "—" : formatPrice(r.row.price)}
                        </td>
                        <td className="px-3 py-2.5 text-adminMuted">
                          {Number.isNaN(r.row.stock) ? "—" : r.row.stock}
                        </td>
                        <td className="px-3 py-2.5 text-xs text-adminMuted">{r.messages.join(" ")}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {validated.length > 80 && (
                <p className="border-t border-adminBorder bg-adminBg/60 px-4 py-2 text-xs text-adminMuted">
                  Mostrando 80 de {validated.length} filas.
                </p>
              )}
            </div>
          </div>
        )}
      </div>

      <div className="flex justify-between">
        <button
          type="button"
          onClick={() => setStep((s) => Math.max(1, s - 1))}
          disabled={step === 1}
          className="flex items-center gap-1.5 rounded-full border border-adminBorder px-5 py-2.5 text-sm font-medium text-carbon hover:bg-adminBg disabled:opacity-40"
        >
          <ChevronLeft className="h-4 w-4" /> Atrás
        </button>

        {step < 3 ? (
          <button
            type="button"
            onClick={() => setStep((s) => Math.min(3, s + 1))}
            disabled={step === 2 && !requiredMapped}
            className="flex items-center gap-1.5 rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-40"
          >
            Siguiente <ChevronRight className="h-4 w-4" />
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setConfirmOpen(true)}
            disabled={importableCount === 0}
            className="rounded-full bg-borgona px-6 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-40"
          >
            Confirmar importación
          </button>
        )}
      </div>

      {confirmOpen && (
        <ConfirmDialog
          title="Confirmar importación"
          description={`Se van a importar ${importableCount} producto${importableCount === 1 ? "" : "s"} (${okCount} nuevos sin advertencias, ${warningCount} con advertencias). ${errorCount} fila${errorCount === 1 ? "" : "s"} con errores se van a omitir.`}
          confirmLabel="Confirmar importación"
          danger={false}
          pending={pending}
          onConfirm={handleConfirmImport}
          onClose={() => setConfirmOpen(false)}
        />
      )}
    </div>
  );
}
