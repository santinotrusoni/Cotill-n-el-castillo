"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Plus, Pencil, Trash2, Zap, Power } from "lucide-react";
import { Category, Brand, PriceRule, PriceRuleInput, PriceUpdateType, RoundingOption } from "@/lib/types";
import { ROUNDING_OPTIONS, changeLabel } from "@/lib/pricing";
import {
  createPriceRuleAction,
  updatePriceRuleAction,
  deletePriceRuleAction,
  applyPriceRuleNowAction,
} from "@/lib/admin-actions";
import { useAdminToast } from "@/lib/admin-toast-context";
import { Modal } from "@/components/admin/Modal";
import { ConfirmDialog } from "@/components/admin/ConfirmDialog";

const ROUNDING_LABELS: Record<RoundingOption, string> = {
  0: "Sin redondeo",
  10: "$10",
  50: "$50",
  100: "$100",
  500: "$500",
  1000: "$1.000",
};

export function PriceRulesManager({
  rules,
  categories,
  brands,
}: {
  rules: PriceRule[];
  categories: Category[];
  brands: Brand[];
}) {
  const router = useRouter();
  const { showToast } = useAdminToast();
  const [editing, setEditing] = useState<PriceRule | "new" | null>(null);
  const [deleting, setDeleting] = useState<PriceRule | null>(null);
  const [applying, setApplying] = useState<PriceRule | null>(null);
  const [pending, startTransition] = useTransition();

  function scopeLabel(rule: PriceRule): string {
    const cat = rule.categoryId ? categories.find((c) => c.id === rule.categoryId)?.name : null;
    const brand = rule.brandId ? brands.find((b) => b.id === rule.brandId)?.name : null;
    if (cat && brand) return `${cat} · ${brand}`;
    if (cat) return `Categoría: ${cat}`;
    if (brand) return `Marca: ${brand}`;
    return "Todo el catálogo";
  }

  function handleToggleActive(rule: PriceRule) {
    startTransition(async () => {
      try {
        await updatePriceRuleAction(rule.id, { active: !rule.active });
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo actualizar la regla.", "error");
      }
    });
  }

  function handleDelete() {
    if (!deleting) return;
    startTransition(async () => {
      try {
        await deletePriceRuleAction(deleting.id);
        showToast(`Regla "${deleting.name}" eliminada.`);
        setDeleting(null);
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo eliminar.", "error");
      }
    });
  }

  function handleApplyNow() {
    if (!applying) return;
    startTransition(async () => {
      try {
        const entry = await applyPriceRuleNowAction(applying.id);
        showToast(`Regla aplicada a ${entry.affectedProductIds.length} productos.`);
        setApplying(null);
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo aplicar la regla.", "error");
      }
    });
  }

  return (
    <div>
      <div className="mb-4 flex justify-end">
        <button
          type="button"
          onClick={() => setEditing("new")}
          className="flex items-center gap-2 rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark"
        >
          <Plus className="h-4 w-4" /> Nueva regla
        </button>
      </div>

      {rules.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-xl2 border border-dashed border-adminBorder bg-white px-6 py-16 text-center">
          <Zap className="h-8 w-8 text-adminMuted" aria-hidden />
          <p className="max-w-sm text-sm text-adminMuted">
            Creá reglas para aplicar el mismo ajuste de precios a una categoría o marca cuando quieras,
            sin repetir el wizard.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {rules.map((rule) => (
            <div
              key={rule.id}
              className="flex flex-col gap-3 rounded-xl2 border border-adminBorder bg-white p-4 sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-display text-base font-semibold text-carbon">{rule.name}</h3>
                  <span
                    className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${
                      rule.active ? "bg-exito/10 text-exito" : "bg-adminBg text-adminMuted"
                    }`}
                  >
                    {rule.active ? "Activa" : "Inactiva"}
                  </span>
                </div>
                <p className="mt-0.5 text-sm text-adminMuted">
                  {scopeLabel(rule)} · <span className="font-medium text-borgona">{changeLabel(rule.type, rule.value)}</span> ·{" "}
                  {ROUNDING_LABELS[rule.rounding]}
                  {rule.lastAppliedAt && (
                    <> · Última vez: {new Date(rule.lastAppliedAt).toLocaleDateString("es-AR")}</>
                  )}
                </p>
              </div>
              <div className="flex shrink-0 flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => setApplying(rule)}
                  disabled={!rule.active}
                  className="flex items-center gap-1.5 rounded-full bg-borgona px-4 py-2 text-xs font-medium text-white hover:bg-borgona-dark disabled:opacity-40"
                >
                  <Zap className="h-3.5 w-3.5" /> Aplicar ahora
                </button>
                <button
                  type="button"
                  onClick={() => handleToggleActive(rule)}
                  className="flex items-center gap-1.5 rounded-full border border-adminBorder px-3 py-2 text-xs font-medium text-carbon hover:bg-adminBg"
                >
                  <Power className="h-3.5 w-3.5" /> {rule.active ? "Desactivar" : "Activar"}
                </button>
                <button
                  type="button"
                  onClick={() => setEditing(rule)}
                  className="flex items-center justify-center rounded-full border border-adminBorder p-2 text-carbon hover:bg-adminBg"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setDeleting(rule)}
                  className="flex items-center justify-center rounded-full border border-adminBorder p-2 text-adminMuted hover:bg-error/10 hover:text-error"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing && (
        <RuleFormModal
          rule={editing === "new" ? undefined : editing}
          categories={categories}
          brands={brands}
          onClose={() => setEditing(null)}
        />
      )}

      {deleting && (
        <ConfirmDialog
          title="Eliminar regla"
          description={`¿Seguro que querés eliminar la regla "${deleting.name}"? Esto no afecta los precios ya aplicados.`}
          confirmLabel="Eliminar"
          pending={pending}
          onConfirm={handleDelete}
          onClose={() => setDeleting(null)}
        />
      )}

      {applying && (
        <ConfirmDialog
          title="Aplicar regla ahora"
          description={`Se aplicará "${changeLabel(applying.type, applying.value)}" a todos los productos de: ${scopeLabel(
            applying
          )}. Vas a poder revertirlo desde el historial.`}
          confirmLabel="Aplicar regla"
          danger={false}
          pending={pending}
          onConfirm={handleApplyNow}
          onClose={() => setApplying(null)}
        />
      )}
    </div>
  );
}

function RuleFormModal({
  rule,
  categories,
  brands,
  onClose,
}: {
  rule?: PriceRule;
  categories: Category[];
  brands: Brand[];
  onClose: () => void;
}) {
  const isEdit = !!rule;
  const [name, setName] = useState(rule?.name ?? "");
  const [categoryId, setCategoryId] = useState(rule?.categoryId ?? "");
  const [brandId, setBrandId] = useState(rule?.brandId ?? "");
  const [type, setType] = useState<PriceUpdateType>(rule?.type ?? "porcentaje");
  const [value, setValue] = useState(rule ? String(rule.value) : "10");
  const [rounding, setRounding] = useState<RoundingOption>(rule?.rounding ?? 0);
  const [active, setActive] = useState(rule?.active ?? true);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      showToast("El nombre de la regla es obligatorio.", "error");
      return;
    }
    const numericValue = Number(value);
    if (Number.isNaN(numericValue)) {
      showToast("Ingresá un valor numérico válido.", "error");
      return;
    }
    const payload: PriceRuleInput = {
      name: name.trim(),
      categoryId: categoryId || undefined,
      brandId: brandId || undefined,
      type,
      value: numericValue,
      rounding,
      active,
    };
    startTransition(async () => {
      try {
        if (isEdit && rule) {
          await updatePriceRuleAction(rule.id, payload);
          showToast("Regla actualizada.");
        } else {
          await createPriceRuleAction(payload);
          showToast("Regla creada.");
        }
        onClose();
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo guardar la regla.", "error");
      }
    });
  }

  return (
    <Modal title={isEdit ? "Editar regla" : "Nueva regla automática"} onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-carbon/80">Nombre</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder='Ej: "Aumento Cotillón"'
            className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          />
        </label>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <label className="block text-sm">
            <span className="mb-1.5 block font-medium text-carbon/80">Categoría (opcional)</span>
            <select
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
            >
              <option value="">Todas</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-sm">
            <span className="mb-1.5 block font-medium text-carbon/80">Marca (opcional)</span>
            <select
              value={brandId}
              onChange={(e) => setBrandId(e.target.value)}
              className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
            >
              <option value="">Todas</option>
              {brands.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <label className="block text-sm">
            <span className="mb-1.5 block font-medium text-carbon/80">Tipo</span>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as PriceUpdateType)}
              className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
            >
              <option value="porcentaje">Porcentaje</option>
              <option value="monto_fijo">Monto fijo</option>
              <option value="precio_especifico">Precio específico</option>
            </select>
          </label>
          <label className="block text-sm">
            <span className="mb-1.5 block font-medium text-carbon/80">Valor</span>
            <input
              type="number"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
            />
          </label>
          <label className="block text-sm">
            <span className="mb-1.5 block font-medium text-carbon/80">Redondeo</span>
            <select
              value={rounding}
              onChange={(e) => setRounding(Number(e.target.value) as RoundingOption)}
              className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
            >
              {ROUNDING_OPTIONS.map((r) => (
                <option key={r} value={r}>
                  {ROUNDING_LABELS[r]}
                </option>
              ))}
            </select>
          </label>
        </div>

        <label className="flex items-center gap-2.5 text-sm">
          <input
            type="checkbox"
            checked={active}
            onChange={(e) => setActive(e.target.checked)}
            className="h-4 w-4 accent-borgona"
          />
          <span className="font-medium text-carbon/80">Regla activa</span>
        </label>

        <div className="flex justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded-full border border-adminBorder px-5 py-2.5 text-sm font-medium text-carbon hover:bg-adminBg"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={pending}
            className="rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-60"
          >
            {pending ? "Guardando..." : isEdit ? "Guardar cambios" : "Crear regla"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
