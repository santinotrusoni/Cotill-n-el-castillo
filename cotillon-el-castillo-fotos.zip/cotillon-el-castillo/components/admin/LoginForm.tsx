"use client";

import { useState, useTransition } from "react";
import { Mail, Lock, ArrowRight } from "lucide-react";
import { loginAction } from "@/lib/admin-auth-actions";

export function LoginForm({ next }: { next: string }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [pending, startTransition] = useTransition();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    startTransition(async () => {
      const result = await loginAction(email, password, next);
      if (result?.error) setError(result.error);
    });
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="email" className="mb-1.5 block text-sm font-medium text-carbon">
          Email
        </label>
        <div className="relative">
          <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-adminMuted" />
          <input
            id="email"
            type="email"
            autoFocus
            autoComplete="username"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="vos@elcastillocotillon.com.ar"
            className={`w-full rounded-lg border py-2.5 pl-9 pr-3 text-sm outline-none transition-colors ${
              error ? "border-error" : "border-adminBorder focus:border-borgona"
            }`}
          />
        </div>
      </div>

      <div>
        <label htmlFor="password" className="mb-1.5 block text-sm font-medium text-carbon">
          Contraseña
        </label>
        <div className="relative">
          <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-adminMuted" />
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            className={`w-full rounded-lg border py-2.5 pl-9 pr-3 text-sm outline-none transition-colors ${
              error ? "border-error" : "border-adminBorder focus:border-borgona"
            }`}
          />
        </div>
        {error && <p className="mt-1.5 text-xs text-error">{error}</p>}
      </div>

      <button
        type="submit"
        disabled={pending || !email || !password}
        className="flex w-full items-center justify-center gap-2 rounded-full bg-borgona py-2.5 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-50"
      >
        {pending ? (
          "Verificando..."
        ) : (
          <>
            Ingresar <ArrowRight className="h-4 w-4" />
          </>
        )}
      </button>
    </form>
  );
}
