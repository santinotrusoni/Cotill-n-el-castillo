"use client";

import { useTransition } from "react";
import { Menu, UserCircle, LogOut } from "lucide-react";
import { logoutAction } from "@/lib/admin-auth-actions";

const ROLE_LABELS: Record<string, string> = {
  admin: "Administrador",
  editor: "Editor",
};

export function AdminHeader({
  onMenuClick,
  user,
}: {
  onMenuClick: () => void;
  user: { name: string; role: string };
}) {
  const [pending, startTransition] = useTransition();

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between border-b border-adminBorder bg-white/90 px-4 py-3 backdrop-blur sm:px-6">
      <button
        type="button"
        onClick={onMenuClick}
        aria-label="Abrir menú"
        className="rounded-lg p-2 text-carbon/70 hover:bg-adminBg lg:hidden"
      >
        <Menu className="h-5 w-5" />
      </button>

      <div className="hidden lg:block" />

      <div className="flex items-center gap-2">
        <div className="flex items-center gap-2.5 rounded-full border border-adminBorder py-1.5 pl-1.5 pr-3.5">
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-borgona/10 text-borgona">
            <UserCircle className="h-5 w-5" aria-hidden />
          </span>
          <div className="leading-tight">
            <p className="text-xs font-semibold text-carbon">{user.name}</p>
            <p className="text-[11px] text-adminMuted">{ROLE_LABELS[user.role] ?? user.role}</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => startTransition(() => logoutAction())}
          disabled={pending}
          aria-label="Cerrar sesión"
          className="flex h-9 w-9 items-center justify-center rounded-full border border-adminBorder text-carbon/60 hover:bg-adminBg hover:text-error disabled:opacity-50"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
}
