"use client";

import { AlertTriangle } from "lucide-react";
import { Modal } from "./Modal";

interface ConfirmDialogProps {
  title: string;
  description: string;
  confirmLabel?: string;
  danger?: boolean;
  pending?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}

export function ConfirmDialog({
  title,
  description,
  confirmLabel = "Confirmar",
  danger = true,
  pending = false,
  onConfirm,
  onClose,
}: ConfirmDialogProps) {
  return (
    <Modal title={title} onClose={onClose} maxWidth="sm">
      <div className="flex flex-col items-center gap-3 text-center">
        <div
          className={`flex h-12 w-12 items-center justify-center rounded-full ${
            danger ? "bg-error/10" : "bg-dorado/10"
          }`}
        >
          <AlertTriangle className={`h-6 w-6 ${danger ? "text-error" : "text-dorado"}`} aria-hidden />
        </div>
        <p className="text-sm text-carbon/70">{description}</p>
      </div>
      <div className="mt-6 flex gap-3">
        <button
          type="button"
          onClick={onClose}
          disabled={pending}
          className="flex-1 rounded-full border border-adminBorder py-2.5 text-sm font-medium text-carbon transition-colors hover:bg-adminBg disabled:opacity-50"
        >
          Cancelar
        </button>
        <button
          type="button"
          onClick={onConfirm}
          disabled={pending}
          className={`flex-1 rounded-full py-2.5 text-sm font-medium text-white transition-colors disabled:opacity-60 ${
            danger ? "bg-error hover:bg-error/90" : "bg-borgona hover:bg-borgona-dark"
          }`}
        >
          {pending ? "Procesando..." : confirmLabel}
        </button>
      </div>
    </Modal>
  );
}
