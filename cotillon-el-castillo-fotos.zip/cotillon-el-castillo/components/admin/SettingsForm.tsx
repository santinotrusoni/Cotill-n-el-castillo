"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Save } from "lucide-react";
import { SiteSettings } from "@/lib/types";
import { updateSiteSettingsAction } from "@/lib/admin-actions";
import { useAdminToast } from "@/lib/admin-toast-context";

export function SettingsForm({ settings }: { settings: SiteSettings }) {
  const [storeName, setStoreName] = useState(settings.storeName);
  const [whatsappNumber, setWhatsappNumber] = useState(settings.whatsappNumber);
  const [contactEmail, setContactEmail] = useState(settings.contactEmail);
  const [address, setAddress] = useState(settings.address);
  const [hours, setHours] = useState(settings.hours);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!storeName.trim() || !whatsappNumber.trim() || !address.trim()) {
      showToast("Nombre, WhatsApp y dirección son obligatorios.", "error");
      return;
    }
    startTransition(async () => {
      try {
        await updateSiteSettingsAction({
          storeName: storeName.trim(),
          whatsappNumber: whatsappNumber.trim(),
          contactEmail: contactEmail.trim(),
          address: address.trim(),
          hours: hours.trim(),
        });
        showToast("Ajustes guardados.");
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo guardar.", "error");
      }
    });
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl space-y-5 rounded-xl2 border border-adminBorder bg-white p-6 shadow-card">
      <label className="block text-sm">
        <span className="mb-1.5 block font-medium text-carbon/80">Nombre del negocio</span>
        <input
          value={storeName}
          onChange={(e) => setStoreName(e.target.value)}
          className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
        />
      </label>

      <label className="block text-sm">
        <span className="mb-1.5 block font-medium text-carbon/80">Número de WhatsApp</span>
        <input
          value={whatsappNumber}
          onChange={(e) => setWhatsappNumber(e.target.value)}
          placeholder="5491123456789"
          className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
        />
        <span className="mt-1 block text-xs text-adminMuted">
          Formato: 54 9 + código de área + número, todo junto y sin espacios. Se usa en los botones de
          WhatsApp del carrito y la confirmación de pedido.
        </span>
      </label>

      <label className="block text-sm">
        <span className="mb-1.5 block font-medium text-carbon/80">Email de contacto</span>
        <input
          type="email"
          value={contactEmail}
          onChange={(e) => setContactEmail(e.target.value)}
          className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
        />
      </label>

      <label className="block text-sm">
        <span className="mb-1.5 block font-medium text-carbon/80">Dirección</span>
        <input
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
        />
      </label>

      <label className="block text-sm">
        <span className="mb-1.5 block font-medium text-carbon/80">Horario de atención</span>
        <input
          value={hours}
          onChange={(e) => setHours(e.target.value)}
          className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
        />
      </label>

      <p className="text-xs text-adminMuted">
        Estos datos se muestran en el pie de página y en /contacto de la tienda pública.
      </p>

      <button
        type="submit"
        disabled={pending}
        className="flex items-center gap-2 rounded-full bg-borgona px-6 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-60"
      >
        <Save className="h-4 w-4" /> {pending ? "Guardando..." : "Guardar cambios"}
      </button>
    </form>
  );
}
