import { ProductStatus } from "@/lib/types";

const STYLES: Record<ProductStatus, string> = {
  activo: "bg-exito/10 text-exito",
  inactivo: "bg-adminMuted/10 text-adminMuted",
  sin_stock: "bg-error/10 text-error",
};

const LABELS: Record<ProductStatus, string> = {
  activo: "Activo",
  inactivo: "Inactivo",
  sin_stock: "Sin stock",
};

export function AdminStatusBadge({ status }: { status: ProductStatus }) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${STYLES[status]}`}
    >
      {LABELS[status]}
    </span>
  );
}
