"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Plus, Pencil, Trash2, UserCog, KeyRound } from "lucide-react";
import { AdminUser, AdminUserInput, AdminRole } from "@/lib/types";
import { createAdminUserAction, updateAdminUserAction, deleteAdminUserAction } from "@/lib/admin-actions";
import { useAdminToast } from "@/lib/admin-toast-context";
import { Modal } from "@/components/admin/Modal";
import { ConfirmDialog } from "@/components/admin/ConfirmDialog";

const ROLE_LABELS: Record<AdminRole, string> = { admin: "Administrador", editor: "Editor" };

export function UsersManager({ users, currentUserId }: { users: AdminUser[]; currentUserId: string }) {
  const [editing, setEditing] = useState<AdminUser | null | "new">(null);
  const [deleting, setDeleting] = useState<AdminUser | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function handleToggleActive(user: AdminUser) {
    startTransition(async () => {
      try {
        await updateAdminUserAction(user.id, { active: !user.active });
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo actualizar.", "error");
      }
    });
  }

  function handleDelete() {
    if (!deleting) return;
    startTransition(async () => {
      try {
        await deleteAdminUserAction(deleting.id);
        showToast(`Usuario "${deleting.name}" eliminado.`);
        setDeleting(null);
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo eliminar.", "error");
      }
    });
  }

  return (
    <div>
      <div className="mb-4 flex justify-end">
        <button
          type="button"
          onClick={() => setEditing("new")}
          className="flex items-center gap-2 rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark"
        >
          <Plus className="h-4 w-4" /> Nuevo usuario
        </button>
      </div>

      <div className="space-y-3">
        {users.map((u) => {
          const isSelf = u.id === currentUserId;
          return (
            <div
              key={u.id}
              className="flex flex-col gap-3 rounded-xl2 border border-adminBorder bg-white p-4 sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-display text-base font-semibold text-carbon">
                    {u.name} {isSelf && <span className="text-xs font-normal text-adminMuted">(vos)</span>}
                  </h3>
                  <span className="rounded-full bg-borgona/10 px-2 py-0.5 text-[11px] font-medium text-borgona">
                    {ROLE_LABELS[u.role]}
                  </span>
                  <span
                    className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${
                      u.active ? "bg-exito/10 text-exito" : "bg-adminBg text-adminMuted"
                    }`}
                  >
                    {u.active ? "Activo" : "Inactivo"}
                  </span>
                </div>
                <p className="mt-0.5 text-sm text-adminMuted">{u.email}</p>
              </div>
              <div className="flex shrink-0 gap-2">
                <button
                  type="button"
                  onClick={() => handleToggleActive(u)}
                  disabled={isSelf}
                  title={isSelf ? "No podés desactivar tu propia cuenta" : undefined}
                  className="flex items-center gap-1.5 rounded-full border border-adminBorder px-3 py-2 text-xs font-medium text-carbon hover:bg-adminBg disabled:opacity-40"
                >
                  {u.active ? "Desactivar" : "Activar"}
                </button>
                <button
                  type="button"
                  onClick={() => setEditing(u)}
                  className="flex items-center justify-center rounded-full border border-adminBorder p-2 text-carbon hover:bg-adminBg"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setDeleting(u)}
                  disabled={isSelf}
                  title={isSelf ? "No podés eliminar tu propia cuenta" : undefined}
                  className="flex items-center justify-center rounded-full border border-adminBorder p-2 text-adminMuted hover:bg-error/10 hover:text-error disabled:opacity-40"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {editing && <UserFormModal user={editing === "new" ? undefined : editing} onClose={() => setEditing(null)} />}

      {deleting && (
        <ConfirmDialog
          title="Eliminar usuario"
          description={`¿Seguro que querés eliminar a "${deleting.name}"? Va a perder el acceso al panel inmediatamente.`}
          confirmLabel="Eliminar"
          pending={pending}
          onConfirm={handleDelete}
          onClose={() => setDeleting(null)}
        />
      )}
    </div>
  );
}

function UserFormModal({ user, onClose }: { user?: AdminUser; onClose: () => void }) {
  const isEdit = !!user;
  const [name, setName] = useState(user?.name ?? "");
  const [email, setEmail] = useState(user?.email ?? "");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<AdminRole>(user?.role ?? "editor");
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !email.trim()) {
      showToast("Nombre y email son obligatorios.", "error");
      return;
    }
    if (!isEdit && password.length < 8) {
      showToast("La contraseña debe tener al menos 8 caracteres.", "error");
      return;
    }
    if (isEdit && password && password.length < 8) {
      showToast("La nueva contraseña debe tener al menos 8 caracteres.", "error");
      return;
    }

    startTransition(async () => {
      try {
        if (isEdit && user) {
          await updateAdminUserAction(user.id, {
            name: name.trim(),
            role,
            password: password || undefined,
          });
          showToast("Usuario actualizado.");
        } else {
          const payload: AdminUserInput = { name: name.trim(), email: email.trim(), password, role };
          await createAdminUserAction(payload);
          showToast("Usuario creado.");
        }
        onClose();
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo guardar.", "error");
      }
    });
  }

  return (
    <Modal title={isEdit ? "Editar usuario" : "Nuevo usuario"} onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-carbon/80">Nombre</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          />
        </label>
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-carbon/80">Email</span>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={isEdit}
            className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona disabled:bg-adminBg disabled:text-adminMuted"
          />
          {isEdit && <span className="mt-1 block text-xs text-adminMuted">El email no se puede cambiar.</span>}
        </label>
        <label className="block text-sm">
          <span className="mb-1.5 flex items-center gap-1.5 font-medium text-carbon/80">
            {isEdit && <KeyRound className="h-3.5 w-3.5" />}
            {isEdit ? "Nueva contraseña (opcional)" : "Contraseña"}
          </span>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder={isEdit ? "Dejar en blanco para no cambiarla" : "Mínimo 8 caracteres"}
            className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          />
        </label>
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-carbon/80">Rol</span>
          <select
            value={role}
            onChange={(e) => setRole(e.target.value as AdminRole)}
            className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          >
            <option value="editor">Editor — todo menos Usuarios y Ajustes</option>
            <option value="admin">Administrador — acceso completo</option>
          </select>
        </label>
        <div className="flex justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded-full border border-adminBorder px-5 py-2.5 text-sm font-medium text-carbon hover:bg-adminBg"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={pending}
            className="rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-60"
          >
            {pending ? "Guardando..." : isEdit ? "Guardar cambios" : "Crear usuario"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
