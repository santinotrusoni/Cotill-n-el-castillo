"use client";

import { useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Eye, Store, Truck } from "lucide-react";
import { Order, OrderStatus } from "@/lib/types";
import { formatPrice } from "@/lib/utils";
import { updateOrderStatusAction } from "@/lib/admin-actions";
import { useAdminToast } from "@/lib/admin-toast-context";
import { ORDER_STATUS_OPTIONS, ORDER_STATUS_TONE, formatOrderDate } from "@/lib/order-status";

export function OrdersTable({ orders }: { orders: Order[] }) {
  const router = useRouter();
  const { showToast } = useAdminToast();
  const [pending, startTransition] = useTransition();

  function handleStatusChange(id: string, status: OrderStatus) {
    startTransition(async () => {
      try {
        await updateOrderStatusAction(id, status);
        showToast("Estado del pedido actualizado.");
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo actualizar el estado.", "error");
      }
    });
  }

  return (
    <div className="overflow-hidden rounded-xl2 border border-adminBorder bg-white shadow-card">
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-adminBorder bg-adminBg/60 text-xs uppercase tracking-wide text-adminMuted">
            <tr>
              <th className="px-5 py-3 font-medium">Pedido</th>
              <th className="px-5 py-3 font-medium">Cliente</th>
              <th className="px-5 py-3 font-medium">Fecha</th>
              <th className="px-5 py-3 font-medium">Entrega</th>
              <th className="px-5 py-3 font-medium">Total</th>
              <th className="px-5 py-3 font-medium">Estado</th>
              <th className="px-5 py-3 font-medium text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-adminBorder">
            {orders.map((order) => (
              <tr key={order.id} className="align-middle">
                <td className="px-5 py-3 font-medium text-carbon">#{order.orderNumber}</td>
                <td className="px-5 py-3">
                  <p className="text-carbon">{order.customerName}</p>
                  <p className="text-xs text-adminMuted">{order.customerPhone}</p>
                </td>
                <td className="px-5 py-3 text-adminMuted">{formatOrderDate(order.createdAt)}</td>
                <td className="px-5 py-3 text-adminMuted">
                  <span className="flex items-center gap-1.5">
                    {order.deliveryMethod === "envio" ? <Truck className="h-3.5 w-3.5" /> : <Store className="h-3.5 w-3.5" />}
                    {order.deliveryMethod === "envio" ? "Envío" : "Retiro"}
                  </span>
                </td>
                <td className="px-5 py-3 font-medium text-carbon">{formatPrice(order.total)}</td>
                <td className="px-5 py-3">
                  <select
                    value={order.status}
                    disabled={pending}
                    onChange={(e) => handleStatusChange(order.id, e.target.value as OrderStatus)}
                    className={`rounded-full border-0 px-2.5 py-1 text-xs font-medium outline-none ${ORDER_STATUS_TONE[order.status]}`}
                  >
                    {ORDER_STATUS_OPTIONS.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </td>
                <td className="px-5 py-3 text-right">
                  <Link
                    href={`/admin/pedidos/${order.id}`}
                    className="inline-flex items-center gap-1.5 rounded-full border border-adminBorder px-3 py-1.5 text-xs font-medium text-carbon hover:bg-adminBg"
                  >
                    <Eye className="h-3.5 w-3.5" /> Ver
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
