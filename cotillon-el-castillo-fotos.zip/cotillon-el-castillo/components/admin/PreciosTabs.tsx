"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Wand2, History, Repeat } from "lucide-react";

const TABS = [
  { href: "/admin/precios", label: "Actualización masiva", icon: Wand2, exact: true },
  { href: "/admin/precios/historial", label: "Historial", icon: History, exact: false },
  { href: "/admin/precios/reglas", label: "Reglas automáticas", icon: Repeat, exact: false },
];

export function PreciosTabs() {
  const pathname = usePathname();

  return (
    <div className="flex flex-wrap gap-2 border-b border-adminBorder pb-3">
      {TABS.map((tab) => {
        const active = tab.exact ? pathname === tab.href : pathname?.startsWith(tab.href);
        return (
          <Link
            key={tab.href}
            href={tab.href}
            className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors ${
              active
                ? "bg-borgona text-white"
                : "text-adminMuted hover:bg-adminBg hover:text-carbon"
            }`}
          >
            <tab.icon className="h-4 w-4" aria-hidden />
            {tab.label}
          </Link>
        );
      })}
    </div>
  );
}
