"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Plus, Pencil, Trash2, SlidersHorizontal } from "lucide-react";
import { Attribute, AttributeInput } from "@/lib/types";
import { createAttributeAction, updateAttributeAction, deleteAttributeAction } from "@/lib/admin-actions";
import { useAdminToast } from "@/lib/admin-toast-context";
import { Modal } from "@/components/admin/Modal";
import { ConfirmDialog } from "@/components/admin/ConfirmDialog";

export function AttributesManager({ attributes }: { attributes: Attribute[] }) {
  const [editing, setEditing] = useState<Attribute | null | "new">(null);
  const [deleting, setDeleting] = useState<Attribute | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function handleDelete() {
    if (!deleting) return;
    startTransition(async () => {
      try {
        await deleteAttributeAction(deleting.id);
        showToast(`Atributo "${deleting.name}" eliminado.`);
        setDeleting(null);
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo eliminar.", "error");
      }
    });
  }

  return (
    <div>
      <div className="mb-4 flex justify-end">
        <button
          type="button"
          onClick={() => setEditing("new")}
          className="flex items-center gap-2 rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark"
        >
          <Plus className="h-4 w-4" /> Nuevo atributo
        </button>
      </div>

      {attributes.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-xl2 border border-dashed border-adminBorder bg-white px-6 py-20 text-center">
          <SlidersHorizontal className="h-8 w-8 text-adminMuted" />
          <p className="max-w-sm text-sm text-adminMuted">
            Creá atributos como "Color" o "Tamaño" para asignarles valores estructurados a tus productos.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {attributes.map((attr) => (
            <div
              key={attr.id}
              className="flex flex-col gap-3 rounded-xl2 border border-adminBorder bg-white p-4 sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <h3 className="font-display text-base font-semibold text-carbon">{attr.name}</h3>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {attr.values.length === 0 ? (
                    <span className="text-sm text-adminMuted">Sin valores cargados</span>
                  ) : (
                    attr.values.map((v) => (
                      <span key={v} className="rounded-full bg-adminBg px-2.5 py-1 text-xs text-carbon/70">
                        {v}
                      </span>
                    ))
                  )}
                </div>
              </div>
              <div className="flex shrink-0 gap-2">
                <button
                  type="button"
                  onClick={() => setEditing(attr)}
                  className="flex items-center justify-center rounded-full border border-adminBorder p-2 text-carbon hover:bg-adminBg"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setDeleting(attr)}
                  className="flex items-center justify-center rounded-full border border-adminBorder p-2 text-adminMuted hover:bg-error/10 hover:text-error"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing && (
        <AttributeFormModal attribute={editing === "new" ? undefined : editing} onClose={() => setEditing(null)} />
      )}

      {deleting && (
        <ConfirmDialog
          title="Eliminar atributo"
          description={`¿Seguro que querés eliminar "${deleting.name}"? Los productos que ya tengan un valor asignado de este atributo lo conservan como texto, pero no vas a poder asignarlo a productos nuevos.`}
          confirmLabel="Eliminar"
          pending={pending}
          onConfirm={handleDelete}
          onClose={() => setDeleting(null)}
        />
      )}
    </div>
  );
}

function AttributeFormModal({ attribute, onClose }: { attribute?: Attribute; onClose: () => void }) {
  const isEdit = !!attribute;
  const [name, setName] = useState(attribute?.name ?? "");
  const [valuesText, setValuesText] = useState(attribute?.values.join(", ") ?? "");
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      showToast("El nombre es obligatorio.", "error");
      return;
    }
    const values = Array.from(
      new Set(
        valuesText
          .split(",")
          .map((v) => v.trim())
          .filter(Boolean)
      )
    );
    const payload: AttributeInput = { name: name.trim(), values };
    startTransition(async () => {
      try {
        if (isEdit && attribute) {
          await updateAttributeAction(attribute.id, payload);
          showToast("Atributo actualizado.");
        } else {
          await createAttributeAction(payload);
          showToast("Atributo creado.");
        }
        onClose();
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo guardar.", "error");
      }
    });
  }

  return (
    <Modal title={isEdit ? "Editar atributo" : "Nuevo atributo"} onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-carbon/80">Nombre</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder='Ej: "Color"'
            className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          />
        </label>
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-carbon/80">Valores posibles</span>
          <textarea
            value={valuesText}
            onChange={(e) => setValuesText(e.target.value)}
            rows={3}
            placeholder="Separados por coma: Rojo, Azul, Verde"
            className="w-full resize-none rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          />
        </label>
        <div className="flex justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded-full border border-adminBorder px-5 py-2.5 text-sm font-medium text-carbon hover:bg-adminBg"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={pending}
            className="rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-60"
          >
            {pending ? "Guardando..." : isEdit ? "Guardar cambios" : "Crear atributo"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
