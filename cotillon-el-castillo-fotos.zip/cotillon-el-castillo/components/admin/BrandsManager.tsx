"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { Brand } from "@/lib/types";
import { slugify } from "@/lib/utils";
import { createBrandAction, updateBrandAction, deleteBrandAction } from "@/lib/admin-actions";
import { useAdminToast } from "@/lib/admin-toast-context";
import { Modal } from "@/components/admin/Modal";
import { ConfirmDialog } from "@/components/admin/ConfirmDialog";

type BrandWithCount = Brand & { productCount: number };

export function BrandsManager({ brands }: { brands: BrandWithCount[] }) {
  const [editing, setEditing] = useState<Brand | null | "new">(null);
  const [deleting, setDeleting] = useState<BrandWithCount | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function handleDelete() {
    if (!deleting) return;
    startTransition(async () => {
      try {
        await deleteBrandAction(deleting.id);
        showToast(`Marca "${deleting.name}" eliminada.`);
        setDeleting(null);
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo eliminar.", "error");
      }
    });
  }

  return (
    <div>
      <div className="mb-4 flex justify-end">
        <button
          type="button"
          onClick={() => setEditing("new")}
          className="flex items-center gap-2 rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark"
        >
          <Plus className="h-4 w-4" /> Nueva marca
        </button>
      </div>

      <div className="overflow-hidden rounded-xl2 border border-adminBorder bg-white shadow-card">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
          <thead className="border-b border-adminBorder bg-adminBg/60 text-xs uppercase tracking-wide text-adminMuted">
            <tr>
              <th className="px-5 py-3 font-medium">Marca</th>
              <th className="px-5 py-3 font-medium">Productos</th>
              <th className="px-5 py-3 font-medium text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-adminBorder">
            {brands.map((b) => (
              <tr key={b.id} className="hover:bg-adminBg/50">
                <td className="px-5 py-3 font-medium text-carbon">{b.name}</td>
                <td className="px-5 py-3 text-carbon/70">{b.productCount}</td>
                <td className="px-5 py-3">
                  <div className="flex justify-end gap-1">
                    <button
                      type="button"
                      onClick={() => setEditing(b)}
                      className="rounded-lg p-2 text-adminMuted hover:bg-adminBg hover:text-carbon"
                    >
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeleting(b)}
                      className="rounded-lg p-2 text-adminMuted hover:bg-error/10 hover:text-error"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </div>

      {editing && <BrandFormModal brand={editing === "new" ? undefined : editing} onClose={() => setEditing(null)} />}

      {deleting && (
        <ConfirmDialog
          title="Eliminar marca"
          description={
            deleting.productCount > 0
              ? `"${deleting.name}" tiene ${deleting.productCount} producto(s) asignados. Reasignalos antes de eliminarla.`
              : `¿Seguro que querés eliminar "${deleting.name}"?`
          }
          confirmLabel="Eliminar"
          pending={pending}
          onConfirm={handleDelete}
          onClose={() => setDeleting(null)}
        />
      )}
    </div>
  );
}

function BrandFormModal({ brand, onClose }: { brand?: Brand; onClose: () => void }) {
  const isEdit = !!brand;
  const [name, setName] = useState(brand?.name ?? "");
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { showToast } = useAdminToast();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      showToast("El nombre es obligatorio.", "error");
      return;
    }
    const payload = { name: name.trim(), slug: slugify(name.trim()) };
    startTransition(async () => {
      try {
        if (isEdit && brand) {
          await updateBrandAction(brand.id, payload);
          showToast("Marca actualizada.");
        } else {
          await createBrandAction(payload);
          showToast("Marca creada.");
        }
        onClose();
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo guardar.", "error");
      }
    });
  }

  return (
    <Modal title={isEdit ? "Editar marca" : "Nueva marca"} maxWidth="sm" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-carbon/80">Nombre</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full rounded-lg border border-adminBorder px-3 py-2.5 text-sm outline-none focus:border-borgona"
          />
        </label>
        <div className="flex justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded-full border border-adminBorder px-5 py-2.5 text-sm font-medium text-carbon hover:bg-adminBg"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={pending}
            className="rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white hover:bg-borgona-dark disabled:opacity-60"
          >
            {pending ? "Guardando..." : isEdit ? "Guardar cambios" : "Crear marca"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
