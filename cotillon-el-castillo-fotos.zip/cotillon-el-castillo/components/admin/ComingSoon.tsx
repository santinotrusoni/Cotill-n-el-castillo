import { LucideIcon, Construction } from "lucide-react";

interface ComingSoonProps {
  title: string;
  description: string;
  phase: string;
  icon?: LucideIcon;
}

export function ComingSoon({ title, description, phase, icon: Icon = Construction }: ComingSoonProps) {
  return (
    <div className="flex flex-col items-center gap-4 rounded-xl2 border border-dashed border-adminBorder bg-white px-6 py-20 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-dorado/10">
        <Icon className="h-7 w-7 text-dorado" aria-hidden />
      </div>
      <div>
        <span className="mb-1 inline-block rounded-full bg-carbon/5 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-carbon/50">
          {phase}
        </span>
        <h1 className="font-display text-xl font-semibold text-carbon">{title}</h1>
      </div>
      <p className="max-w-sm text-sm text-adminMuted">{description}</p>
    </div>
  );
}
