"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { Store, Truck, Banknote, Landmark, Phone } from "lucide-react";
import { Order, OrderStatus } from "@/lib/types";
import { formatPrice } from "@/lib/utils";
import { updateOrderStatusAction } from "@/lib/admin-actions";
import { useAdminToast } from "@/lib/admin-toast-context";
import { ORDER_STATUS_OPTIONS, ORDER_STATUS_TONE, formatOrderDate } from "@/lib/order-status";

export function OrderDetail({ order }: { order: Order }) {
  const router = useRouter();
  const { showToast } = useAdminToast();
  const [pending, startTransition] = useTransition();

  function handleStatusChange(status: OrderStatus) {
    startTransition(async () => {
      try {
        await updateOrderStatusAction(order.id, status);
        showToast("Estado del pedido actualizado.");
        router.refresh();
      } catch (err) {
        showToast(err instanceof Error ? err.message : "No se pudo actualizar el estado.", "error");
      }
    });
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
      <div className="space-y-6">
        <div className="rounded-xl2 border border-adminBorder bg-white p-5 shadow-card sm:p-6">
          <h2 className="mb-4 font-display text-base font-semibold text-carbon">Productos</h2>
          <ul className="divide-y divide-adminBorder">
            {order.items.map((item) => (
              <li key={item.productId} className="flex justify-between py-3 text-sm">
                <div>
                  <p className="text-carbon">{item.name}</p>
                  <p className="text-xs text-adminMuted">
                    {item.quantity} x {formatPrice(item.price)}
                  </p>
                </div>
                <span className="font-medium text-carbon">{formatPrice(item.price * item.quantity)}</span>
              </li>
            ))}
          </ul>
          <div className="mt-2 flex justify-between py-1 text-sm text-adminMuted">
            <span>Subtotal</span>
            <span>{formatPrice(order.subtotal)}</span>
          </div>
          {order.discount > 0 && (
            <div className="flex justify-between py-1 text-sm text-exito">
              <span>Descuento</span>
              <span>-{formatPrice(order.discount)}</span>
            </div>
          )}
          <div className="mt-2 flex justify-between border-t border-adminBorder pt-3 font-display text-lg font-semibold text-carbon">
            <span>Total</span>
            <span>{formatPrice(order.total)}</span>
          </div>
        </div>

        {order.notes && (
          <div className="rounded-xl2 border border-adminBorder bg-white p-5 shadow-card sm:p-6">
            <h2 className="mb-2 font-display text-base font-semibold text-carbon">Notas del cliente</h2>
            <p className="text-sm text-carbon/70">{order.notes}</p>
          </div>
        )}
      </div>

      <div className="space-y-4">
        <div className="rounded-xl2 border border-adminBorder bg-white p-5 shadow-card">
          <p className="text-xs font-medium uppercase tracking-wide text-adminMuted">Estado</p>
          <select
            value={order.status}
            disabled={pending}
            onChange={(e) => handleStatusChange(e.target.value as OrderStatus)}
            className={`mt-2 w-full rounded-lg border-0 px-3 py-2 text-sm font-medium outline-none ${ORDER_STATUS_TONE[order.status]}`}
          >
            {ORDER_STATUS_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
          <p className="mt-3 text-xs text-adminMuted">Creado el {formatOrderDate(order.createdAt)}</p>
          {order.updatedAt !== order.createdAt && (
            <p className="text-xs text-adminMuted">Actualizado el {formatOrderDate(order.updatedAt)}</p>
          )}
        </div>

        <div className="rounded-xl2 border border-adminBorder bg-white p-5 shadow-card">
          <p className="text-xs font-medium uppercase tracking-wide text-adminMuted">Cliente</p>
          <p className="mt-2 font-medium text-carbon">{order.customerName}</p>
          <p className="flex items-center gap-1.5 text-sm text-adminMuted">
            <Phone className="h-3.5 w-3.5" /> {order.customerPhone}
          </p>
        </div>

        <div className="rounded-xl2 border border-adminBorder bg-white p-5 shadow-card">
          <p className="text-xs font-medium uppercase tracking-wide text-adminMuted">Entrega</p>
          <p className="mt-2 flex items-center gap-2 text-sm text-carbon">
            {order.deliveryMethod === "envio" ? <Truck className="h-4 w-4" /> : <Store className="h-4 w-4" />}
            {order.deliveryMethod === "envio" ? "Envío a domicilio" : "Retiro en el local"}
          </p>
          {order.address && <p className="mt-1 text-sm text-adminMuted">{order.address}</p>}
        </div>

        <div className="rounded-xl2 border border-adminBorder bg-white p-5 shadow-card">
          <p className="text-xs font-medium uppercase tracking-wide text-adminMuted">Pago</p>
          <p className="mt-2 flex items-center gap-2 text-sm text-carbon">
            {order.paymentMethod === "transferencia" ? <Landmark className="h-4 w-4" /> : <Banknote className="h-4 w-4" />}
            {order.paymentMethod === "transferencia" ? "Transferencia" : "Efectivo"}
          </p>
        </div>
      </div>
    </div>
  );
}
