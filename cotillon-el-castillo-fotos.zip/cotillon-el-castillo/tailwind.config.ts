import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        borgona: {
          DEFAULT: "#2FAECD",
          dark: "#207593",
          light: "#44C5E2",
        },
        crema: {
          DEFAULT: "#DBCED0",
          dark: "#C0B5B7",
        },
        carbon: "#1B252C",
        exito: {
          DEFAULT: "#4ED075",
          dark: "#3CA25B",
          light: "#71D990",
        },
        error: "#C15B5B",
        dorado: "#CED46F",
        rosa: {
          DEFAULT: "#E7439B",
          dark: "#B43478",
          light: "#ED72B4",
        },
        halloween: {
          night: "#0E0813",
          plum: "#1D1030",
          purple: "#7B3FBF",
          orange: "#FF7A1A",
          ember: "#FFA24D",
        },
        adminBg: "#F2F3F5",
        adminBorder: "#E3E5E9",
        adminMuted: "#6B7280",
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        sans: ["var(--font-inter)", "sans-serif"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(33,29,27,0.06), 0 8px 24px -12px rgba(33,29,27,0.12)",
        cardHover: "0 4px 8px rgba(33,29,27,0.08), 0 16px 32px -12px rgba(144,53,61,0.18)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
    },
  },
  plugins: [],
};

export default config;
