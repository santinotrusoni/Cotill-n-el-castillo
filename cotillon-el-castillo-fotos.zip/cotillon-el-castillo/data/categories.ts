import { Category } from "@/lib/types";
import { placeholderImage } from "@/lib/utils";

export const categories: Category[] = [
  {
    id: "cat-cotillon",
    name: "Cotillón",
    slug: "cotillon",
    description: "Todo para animar la fiesta: velas, confeti, bengalas y más.",
    image: placeholderImage("Cotillón"),
  },
  {
    id: "cat-descartables",
    name: "Descartables",
    slug: "descartables",
    description: "Vasos, platos y cubiertos descartables para cualquier evento.",
    image: placeholderImage("Descartables"),
  },
  {
    id: "cat-reposteria",
    name: "Repostería",
    slug: "reposteria",
    description: "Insumos para tortas, cajas y decoración de mesa dulce.",
    image: placeholderImage("Repostería"),
  },
  {
    id: "cat-decoracion",
    name: "Decoración",
    slug: "decoracion",
    description: "Guirnaldas, banderines y ambientación para tu evento.",
    image: placeholderImage("Decoración"),
  },
  {
    id: "cat-globos",
    name: "Globos",
    slug: "globos",
    description: "Globos metalizados, de látex y arcos para decorar.",
    image: placeholderImage("Globos"),
  },
  {
    id: "cat-bazar",
    name: "Bazar",
    slug: "bazar",
    description: "Artículos de bazar para el hogar y el evento.",
    image: placeholderImage("Bazar"),
  },
  {
    id: "cat-jugueteria",
    name: "Juguetería",
    slug: "jugueteria",
    description: "Juguetes y souvenirs para cumpleaños infantiles.",
    image: placeholderImage("Juguetería"),
  },
  {
    id: "cat-libreria",
    name: "Librería",
    slug: "libreria",
    description: "Artículos de librería y papelería para eventos.",
    image: placeholderImage("Librería"),
  },
  {
    id: "cat-fiestas-tematicas",
    name: "Fiestas temáticas",
    slug: "fiestas-tematicas",
    description: "Kits completos con temática para cumpleaños.",
    image: placeholderImage("Fiestas Temáticas"),
  },
  {
    id: "cat-disfraces",
    name: "Disfraces",
    slug: "disfraces",
    description: "Disfraces y accesorios para todas las edades.",
    image: placeholderImage("Disfraces"),
  },
];

export function getCategoryBySlug(slug: string): Category | undefined {
  return categories.find((c) => c.slug === slug);
}

export function getCategoryById(id: string): Category | undefined {
  return categories.find((c) => c.id === id);
}
