import { Brand } from "@/lib/types";

export const brands: Brand[] = [
  { id: "brand-el-castillo", name: "El Castillo", slug: "el-castillo" },
  { id: "brand-fiesta-plus", name: "Fiesta Plus", slug: "fiesta-plus" },
  { id: "brand-dulce-hogar", name: "Dulce Hogar", slug: "dulce-hogar" },
  { id: "brand-globo-art", name: "Globo Art", slug: "globo-art" },
];

export function getBrandById(id: string): Brand | undefined {
  return brands.find((b) => b.id === id);
}
