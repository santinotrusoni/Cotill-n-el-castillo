/**
 * export-seed.ts
 * -----------------------------------------------------------------
 * Genera supabase/seed.sql a partir de los datos mock actuales
 * (/data/products.ts, /data/categories.ts, /data/brands.ts), para
 * no tener que reescribir a mano ~30 productos de ejemplo como SQL.
 *
 * Uso: npm run export-seed
 * (vuelve a correrlo si agregás/editás productos de muestra en /data
 * antes de conectar Supabase por primera vez).
 * -----------------------------------------------------------------
 */
import { writeFileSync } from "node:fs";
import { products } from "../data/products";
import { categories } from "../data/categories";
import { brands } from "../data/brands";

function sqlString(value: string | undefined | null): string {
  if (value === undefined || value === null) return "NULL";
  return `'${value.replace(/'/g, "''")}'`;
}

function sqlArray(values: string[]): string {
  if (values.length === 0) return "'{}'";
  const escaped = values.map((v) => v.replace(/'/g, "''").replace(/"/g, '\\"'));
  return `'{${escaped.map((v) => `"${v}"`).join(",")}}'`;
}

function sqlNumber(value: number | undefined | null): string {
  return value === undefined || value === null ? "NULL" : String(value);
}

function sqlBool(value: boolean): string {
  return value ? "true" : "false";
}

function sqlJson(value: unknown): string {
  return `'${JSON.stringify(value).replace(/'/g, "''")}'::jsonb`;
}

const lines: string[] = [
  "-- Generado por scripts/export-seed.ts — datos de muestra iniciales.",
  "-- Volver a correr `npm run export-seed` si cambian los datos en /data.",
  "",
  "insert into categories (id, name, slug, description, image) values",
];

lines.push(
  categories
    .map(
      (c, i) =>
        `  (${sqlString(c.id)}, ${sqlString(c.name)}, ${sqlString(c.slug)}, ${sqlString(c.description)}, ${sqlString(c.image)})${
          i === categories.length - 1 ? ";" : ","
        }`
    )
    .join("\n")
);

lines.push("", "insert into brands (id, name, slug) values");
lines.push(
  brands
    .map(
      (b, i) =>
        `  (${sqlString(b.id)}, ${sqlString(b.name)}, ${sqlString(b.slug)})${i === brands.length - 1 ? ";" : ","}`
    )
    .join("\n")
);

lines.push(
  "",
  "insert into products (id, sku, barcode, slug, name, short_description, description, features, category_id, brand_id, price, previous_price, cost, stock, min_stock, status, featured, is_new, on_offer, images, tags, attribute_values, created_at) values"
);
lines.push(
  products
    .map((p, i) => {
      const row = [
        sqlString(p.id),
        sqlString(p.sku),
        sqlString(p.barcode),
        sqlString(p.slug),
        sqlString(p.name),
        sqlString(p.shortDescription),
        sqlString(p.description),
        sqlArray(p.features),
        sqlString(p.categoryId),
        sqlString(p.brandId),
        sqlNumber(p.price),
        sqlNumber(p.previousPrice),
        sqlNumber(p.cost),
        sqlNumber(p.stock),
        sqlNumber(p.minStock),
        sqlString(p.status),
        sqlBool(p.featured),
        sqlBool(p.isNew),
        sqlBool(p.onOffer),
        sqlArray(p.images),
        sqlArray(p.tags),
        sqlJson(p.attributeValues ?? []),
        sqlString(p.createdAt),
      ].join(", ");
      return `  (${row})${i === products.length - 1 ? ";" : ","}`;
    })
    .join("\n")
);

writeFileSync("supabase/seed.sql", lines.join("\n") + "\n", "utf-8");
console.log(`✓ supabase/seed.sql generado con ${categories.length} categorías, ${brands.length} marcas y ${products.length} productos.`);
