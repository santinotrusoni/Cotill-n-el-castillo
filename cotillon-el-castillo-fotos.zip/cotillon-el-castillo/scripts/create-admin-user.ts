/**
 * create-admin-user.ts
 * -----------------------------------------------------------------
 * Crea un usuario administrativo directamente en Supabase. Hace falta
 * para el primer usuario (la tabla `admin_users` arranca vacía a
 * propósito — nunca hay una contraseña por defecto embebida en el
 * código ni en el SQL). También sirve para crear usuarios adicionales
 * sin depender de que ya haya alguien logueado en /admin/usuarios.
 *
 * Uso: npm run create-admin
 * (te va a pedir nombre, email, contraseña y rol por consola)
 *
 * Lee NEXT_PUBLIC_SUPABASE_URL y SUPABASE_SERVICE_ROLE_KEY desde
 * .env.local — asegurate de tenerlo configurado (ver .env.example).
 * -----------------------------------------------------------------
 */
import { existsSync, readFileSync } from "node:fs";
import { createInterface } from "node:readline/promises";
import { createClient } from "@supabase/supabase-js";
import bcrypt from "bcryptjs";

function loadEnvLocal() {
  if (!existsSync(".env.local")) return;
  const content = readFileSync(".env.local", "utf-8");
  for (const line of content.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eq = trimmed.indexOf("=");
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    const value = trimmed.slice(eq + 1).trim();
    if (!(key in process.env)) process.env[key] = value;
  }
}

async function main() {
  loadEnvLocal();

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !serviceRoleKey) {
    console.error(
      "✗ Faltan NEXT_PUBLIC_SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY en .env.local. Revisá .env.example."
    );
    process.exit(1);
  }

  const supabase = createClient(supabaseUrl, serviceRoleKey);
  const rl = createInterface({ input: process.stdin, output: process.stdout });

  console.log("Crear usuario administrativo\n-----------------------------");
  const name = (await rl.question("Nombre: ")).trim();
  const emailRaw = (await rl.question("Email: ")).trim();
  const email = emailRaw.toLowerCase();
  const password = await rl.question("Contraseña (mínimo 8 caracteres): ");
  const roleAnswer = (await rl.question('Rol ["admin" / "editor", default "admin"]: ')).trim().toLowerCase();
  const role = roleAnswer === "editor" ? "editor" : "admin";
  rl.close();

  if (!name || !email || password.length < 8) {
    console.error("✗ Nombre, email y una contraseña de al menos 8 caracteres son obligatorios.");
    process.exit(1);
  }

  const { data: existing } = await supabase.from("admin_users").select("id").eq("email", email).maybeSingle();
  if (existing) {
    console.error(`✗ Ya existe un usuario con el email ${email}.`);
    process.exit(1);
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const id = `user_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;

  const { error } = await supabase.from("admin_users").insert({
    id,
    name,
    email,
    password_hash: passwordHash,
    role,
    active: true,
    created_at: new Date().toISOString(),
  });

  if (error) {
    console.error(`✗ No se pudo crear el usuario: ${error.message}`);
    console.error("  (¿Corriste supabase/migration-usuarios.sql en el SQL Editor de Supabase?)");
    process.exit(1);
  }

  console.log(`\n✓ Usuario "${name}" (${email}) creado con rol "${role}". Ya podés loguearte en /admin/login.`);
}

main();
