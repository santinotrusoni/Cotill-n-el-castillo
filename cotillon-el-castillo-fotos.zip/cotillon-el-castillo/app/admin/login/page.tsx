import { Logo } from "@/components/layout/Logo";
import { Metadata } from "next";
import { LoginForm } from "@/components/admin/LoginForm";

export const metadata: Metadata = { title: "Ingresar | Admin | Cotillón El Castillo" };

export default function AdminLoginPage({
  searchParams,
}: {
  searchParams: { next?: string };
}) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-carbon px-4">
      <div className="w-full max-w-sm rounded-xl2 bg-white p-8 shadow-card">
        <div className="mb-6 text-center">
          <Logo className="mx-auto h-28" priority />
          <p className="mt-2 text-sm text-adminMuted">Panel de administración</p>
        </div>
        <LoginForm next={searchParams.next ?? "/admin"} />
      </div>
    </div>
  );
}
