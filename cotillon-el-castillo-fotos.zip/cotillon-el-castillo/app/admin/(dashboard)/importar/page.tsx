import { Metadata } from "next";
import { getProducts, getCategories, getBrands } from "@/lib/mock-service";
import { ProductImportWizard } from "@/components/admin/ProductImportWizard";

export const metadata: Metadata = { title: "Importar productos | Admin | Cotillón El Castillo" };

export default async function AdminImportarPage() {
  const [products, categories, brands] = await Promise.all([getProducts(), getCategories(), getBrands()]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Importar productos</h1>
        <p className="mt-1 text-sm text-adminMuted">
          Subí un CSV para crear productos nuevos o actualizar los existentes (por código de barras), con
          preview y validación antes de confirmar.
        </p>
      </div>
      <ProductImportWizard
        existingCategoryNames={categories.map((c) => c.name)}
        existingBrandNames={brands.map((b) => b.name)}
        existingBarcodes={products.map((p) => p.barcode)}
      />
    </div>
  );
}
