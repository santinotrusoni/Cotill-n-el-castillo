import { Metadata } from "next";
import { getAttributes } from "@/lib/mock-service";
import { AttributesManager } from "@/components/admin/AttributesManager";

export const metadata: Metadata = { title: "Atributos | Admin | Cotillón El Castillo" };

export default async function AdminAtributosPage() {
  const attributes = await getAttributes();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Atributos</h1>
        <p className="mt-1 text-sm text-adminMuted">
          {attributes.length} atributo{attributes.length === 1 ? "" : "s"} definido{attributes.length === 1 ? "" : "s"}.
          Asignalos a un producto desde su formulario de edición.
        </p>
      </div>
      <AttributesManager attributes={attributes} />
    </div>
  );
}
