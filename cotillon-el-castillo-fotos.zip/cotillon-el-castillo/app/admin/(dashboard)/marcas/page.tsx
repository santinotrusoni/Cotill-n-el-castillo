import { Metadata } from "next";
import { getBrands, productCountByBrand } from "@/lib/mock-service";
import { BrandsManager } from "@/components/admin/BrandsManager";

export const metadata: Metadata = { title: "Marcas | Admin | Cotillón El Castillo" };

export default async function AdminMarcasPage() {
  const rawBrands = await getBrands();
  const brands = await Promise.all(rawBrands.map(async (b) => ({ ...b, productCount: await productCountByBrand(b.id) })));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Marcas</h1>
        <p className="mt-1 text-sm text-adminMuted">{brands.length} marcas creadas.</p>
      </div>
      <BrandsManager brands={brands} />
    </div>
  );
}
