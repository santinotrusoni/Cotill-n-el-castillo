import { Metadata } from "next";
import { getProducts, getCategories, getBrands } from "@/lib/mock-service";
import { ExportPanel } from "@/components/admin/ExportPanel";

export const metadata: Metadata = { title: "Exportar datos | Admin | Cotillón El Castillo" };

export default async function AdminExportarPage() {
  const [products, categories, brands] = await Promise.all([getProducts(), getCategories(), getBrands()]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Exportar datos</h1>
        <p className="mt-1 text-sm text-adminMuted">
          Descargá tu catálogo en CSV para respaldos, análisis externos o para editarlo y volver a importarlo.
        </p>
      </div>
      <ExportPanel products={products} categories={categories} brands={brands} />
    </div>
  );
}
