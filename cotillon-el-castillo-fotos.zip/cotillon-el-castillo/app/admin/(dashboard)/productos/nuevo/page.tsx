import { Metadata } from "next";
import Link from "next/link";
import { ChevronRight } from "lucide-react";
import { getCategories, getBrands, getAttributes } from "@/lib/mock-service";
import { ProductForm } from "@/components/admin/ProductForm";

export const metadata: Metadata = { title: "Nuevo producto | Admin | Cotillón El Castillo" };

export default async function NuevoProductoPage({
  searchParams,
}: {
  searchParams: { barcode?: string };
}) {
  const [categories, brands, attributes] = await Promise.all([getCategories(), getBrands(), getAttributes()]);

  return (
    <div className="space-y-6">
      <Breadcrumb current="Nuevo producto" />
      <h1 className="font-display text-2xl font-semibold text-carbon">Nuevo producto</h1>
      <ProductForm
        mode="create"
        categories={categories}
        brands={brands}
        attributes={attributes}
        initialBarcode={searchParams.barcode}
      />
    </div>
  );
}

function Breadcrumb({ current }: { current: string }) {
  return (
    <nav className="flex items-center gap-1 text-xs text-adminMuted">
      <Link href="/admin/productos" className="hover:text-borgona">
        Productos
      </Link>
      <ChevronRight className="h-3 w-3" />
      <span className="text-carbon/70">{current}</span>
    </nav>
  );
}
