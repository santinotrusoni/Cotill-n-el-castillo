import Link from "next/link";
import { Metadata } from "next";
import { Plus, Search } from "lucide-react";
import { getProducts, getCategories, getBrands } from "@/lib/mock-service";
import { formatPrice } from "@/lib/utils";
import { ProductsTableRow } from "@/components/admin/ProductsTableRow";

export const metadata: Metadata = { title: "Productos | Admin | Cotillón El Castillo" };

const PAGE_SIZE = 10;

interface PageProps {
  searchParams: {
    q?: string;
    categoria?: string;
    marca?: string;
    estado?: string;
    page?: string;
  };
}

export default async function AdminProductosPage({ searchParams }: PageProps) {
  const [allProducts, categories, brands] = await Promise.all([getProducts(), getCategories(), getBrands()]);

  const q = (searchParams.q || "").trim().toLowerCase();
  const categoria = searchParams.categoria || "";
  const marca = searchParams.marca || "";
  const estado = searchParams.estado || "";
  const page = Math.max(1, Number(searchParams.page) || 1);

  let filtered = allProducts;
  if (q) {
    filtered = filtered.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.barcode.includes(q)
    );
  }
  if (categoria) filtered = filtered.filter((p) => p.categoryId === categoria);
  if (marca) filtered = filtered.filter((p) => p.brandId === marca);
  if (estado) filtered = filtered.filter((p) => p.status === estado);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const paged = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  function buildPageHref(targetPage: number) {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (categoria) params.set("categoria", categoria);
    if (marca) params.set("marca", marca);
    if (estado) params.set("estado", estado);
    params.set("page", String(targetPage));
    return `/admin/productos?${params.toString()}`;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-semibold text-carbon">Productos</h1>
          <p className="mt-1 text-sm text-adminMuted">
            {filtered.length} producto{filtered.length === 1 ? "" : "s"}
            {filtered.length !== allProducts.length ? ` de ${allProducts.length} totales` : ""}
          </p>
        </div>
        <Link
          href="/admin/productos/nuevo"
          className="flex items-center gap-2 rounded-full bg-borgona px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-borgona-dark"
        >
          <Plus className="h-4 w-4" /> Nuevo producto
        </Link>
      </div>

      {/* Filtros */}
      <form
        method="get"
        className="grid grid-cols-1 gap-3 rounded-xl2 border border-adminBorder bg-white p-4 sm:grid-cols-2 lg:grid-cols-5"
      >
        <div className="relative sm:col-span-2 lg:col-span-2">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-adminMuted" />
          <input
            type="text"
            name="q"
            defaultValue={searchParams.q}
            placeholder="Buscar por nombre, SKU o código de barras..."
            className="w-full rounded-lg border border-adminBorder py-2.5 pl-9 pr-3 text-sm outline-none focus:border-borgona"
          />
        </div>
        <select
          name="categoria"
          defaultValue={categoria}
          className="rounded-lg border border-adminBorder px-3 py-2.5 text-sm text-carbon outline-none focus:border-borgona"
        >
          <option value="">Todas las categorías</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
        <select
          name="marca"
          defaultValue={marca}
          className="rounded-lg border border-adminBorder px-3 py-2.5 text-sm text-carbon outline-none focus:border-borgona"
        >
          <option value="">Todas las marcas</option>
          {brands.map((b) => (
            <option key={b.id} value={b.id}>
              {b.name}
            </option>
          ))}
        </select>
        <select
          name="estado"
          defaultValue={estado}
          className="rounded-lg border border-adminBorder px-3 py-2.5 text-sm text-carbon outline-none focus:border-borgona"
        >
          <option value="">Todos los estados</option>
          <option value="activo">Activo</option>
          <option value="inactivo">Inactivo</option>
          <option value="sin_stock">Sin stock</option>
        </select>
        <div className="flex gap-2 sm:col-span-2 lg:col-span-5 lg:justify-end">
          <button
            type="submit"
            className="rounded-full bg-carbon px-5 py-2 text-sm font-medium text-white hover:bg-carbon/90"
          >
            Aplicar filtros
          </button>
          {(q || categoria || marca || estado) && (
            <Link
              href="/admin/productos"
              className="rounded-full border border-adminBorder px-5 py-2 text-sm font-medium text-carbon hover:bg-adminBg"
            >
              Limpiar
            </Link>
          )}
        </div>
      </form>

      {/* Tabla */}
      <div className="overflow-hidden rounded-xl2 border border-adminBorder bg-white shadow-card">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-adminBorder bg-adminBg/60 text-xs uppercase tracking-wide text-adminMuted">
              <tr>
                <th className="px-5 py-3 font-medium">Producto</th>
                <th className="px-5 py-3 font-medium">Categoría</th>
                <th className="px-5 py-3 font-medium">Precio</th>
                <th className="px-5 py-3 font-medium">Stock</th>
                <th className="px-5 py-3 font-medium">Estado</th>
                <th className="px-5 py-3 font-medium text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-adminBorder">
              {paged.map((product) => (
                <ProductsTableRow
                  key={product.id}
                  product={product}
                  categoryName={categories.find((c) => c.id === product.categoryId)?.name ?? "—"}
                  formattedPrice={formatPrice(product.price)}
                />
              ))}
            </tbody>
          </table>
        </div>

        {paged.length === 0 && (
          <div className="px-6 py-16 text-center text-sm text-adminMuted">
            No encontramos productos con esos filtros.
          </div>
        )}

        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t border-adminBorder px-5 py-3 text-sm">
            <span className="text-adminMuted">
              Página {currentPage} de {totalPages}
            </span>
            <div className="flex gap-2">
              <Link
                href={buildPageHref(Math.max(1, currentPage - 1))}
                aria-disabled={currentPage === 1}
                className={`rounded-full border border-adminBorder px-3 py-1.5 ${
                  currentPage === 1
                    ? "pointer-events-none opacity-40"
                    : "hover:bg-adminBg text-carbon"
                }`}
              >
                Anterior
              </Link>
              <Link
                href={buildPageHref(Math.min(totalPages, currentPage + 1))}
                aria-disabled={currentPage === totalPages}
                className={`rounded-full border border-adminBorder px-3 py-1.5 ${
                  currentPage === totalPages
                    ? "pointer-events-none opacity-40"
                    : "hover:bg-adminBg text-carbon"
                }`}
              >
                Siguiente
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
