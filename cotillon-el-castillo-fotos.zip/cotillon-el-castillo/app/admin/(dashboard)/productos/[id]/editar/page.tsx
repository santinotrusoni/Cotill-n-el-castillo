import { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ChevronRight } from "lucide-react";
import { getProductById, getCategories, getBrands, getAttributes } from "@/lib/mock-service";
import { ProductForm } from "@/components/admin/ProductForm";

export const metadata: Metadata = { title: "Editar producto | Admin | Cotillón El Castillo" };

export default async function EditarProductoPage({ params }: { params: { id: string } }) {
  const product = await getProductById(params.id);
  if (!product) notFound();

  const [categories, brands, attributes] = await Promise.all([getCategories(), getBrands(), getAttributes()]);

  return (
    <div className="space-y-6">
      <nav className="flex items-center gap-1 text-xs text-adminMuted">
        <Link href="/admin/productos" className="hover:text-borgona">
          Productos
        </Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-carbon/70">{product.name}</span>
      </nav>
      <h1 className="font-display text-2xl font-semibold text-carbon">Editar producto</h1>
      <ProductForm mode="edit" product={product} categories={categories} brands={brands} attributes={attributes} />
    </div>
  );
}
