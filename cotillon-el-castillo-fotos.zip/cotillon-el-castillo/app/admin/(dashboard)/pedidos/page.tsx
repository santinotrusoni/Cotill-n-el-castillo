import { Metadata } from "next";
import { ShoppingBag } from "lucide-react";
import { getOrders } from "@/lib/mock-service";
import { OrdersTable } from "@/components/admin/OrdersTable";

export const metadata: Metadata = { title: "Pedidos | Admin | Cotillón El Castillo" };

export default async function AdminPedidosPage() {
  const orders = await getOrders();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Pedidos</h1>
        <p className="mt-1 text-sm text-adminMuted">
          {orders.length} pedido{orders.length === 1 ? "" : "s"} recibido{orders.length === 1 ? "" : "s"} desde el
          checkout de la tienda.
        </p>
      </div>

      {orders.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-xl2 border border-dashed border-adminBorder bg-white px-6 py-20 text-center">
          <ShoppingBag className="h-8 w-8 text-adminMuted" />
          <p className="text-sm text-adminMuted">Todavía no llegó ningún pedido.</p>
        </div>
      ) : (
        <OrdersTable orders={orders} />
      )}
    </div>
  );
}
