import Link from "next/link";
import { Metadata } from "next";
import { notFound } from "next/navigation";
import { ChevronLeft } from "lucide-react";
import { getOrderById } from "@/lib/mock-service";
import { OrderDetail } from "@/components/admin/OrderDetail";

export const metadata: Metadata = { title: "Detalle de pedido | Admin | Cotillón El Castillo" };

export default async function AdminPedidoDetailPage({ params }: { params: { id: string } }) {
  const order = await getOrderById(params.id);
  if (!order) notFound();

  return (
    <div className="space-y-6">
      <div>
        <Link href="/admin/pedidos" className="mb-2 flex items-center gap-1 text-sm text-adminMuted hover:text-borgona">
          <ChevronLeft className="h-4 w-4" /> Volver a pedidos
        </Link>
        <h1 className="font-display text-2xl font-semibold text-carbon">Pedido #{order.orderNumber}</h1>
      </div>
      <OrderDetail order={order} />
    </div>
  );
}
