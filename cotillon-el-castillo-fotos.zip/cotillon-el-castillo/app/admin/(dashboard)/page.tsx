import Link from "next/link";
import { Metadata } from "next";
import {
  Package,
  CheckCircle2,
  XCircle,
  Shapes,
  Percent,
  Star,
  Clock,
  ArrowRight,
  Zap,
  ShoppingBag,
} from "lucide-react";
import { getDashboardStats, getRecentActivity } from "@/lib/mock-service";
import { StatsCard } from "@/components/admin/StatsCard";

export const metadata: Metadata = { title: "Dashboard | Admin | Cotillón El Castillo" };

function timeAgo(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diffMs / 60000);
  if (minutes < 1) return "ahora mismo";
  if (minutes < 60) return `hace ${minutes} min`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `hace ${hours} h`;
  const days = Math.floor(hours / 24);
  return `hace ${days} d`;
}

export default async function AdminDashboardPage() {
  const [stats, activity] = await Promise.all([getDashboardStats(), getRecentActivity()]);
  const maxCategoryCount = Math.max(1, ...stats.stockPorCategoria.map((c) => c.count));

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Dashboard</h1>
        <p className="mt-1 text-sm text-adminMuted">
          Estado actual del catálogo de Cotillón El Castillo.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-8">
        <StatsCard label="Total productos" value={stats.total} icon={Package} />
        <StatsCard label="En stock" value={stats.enStock} icon={CheckCircle2} tone="success" />
        <StatsCard label="Sin stock" value={stats.sinStock} icon={XCircle} tone="warning" />
        <StatsCard label="Categorías" value={stats.categorias} icon={Shapes} />
        <StatsCard label="Destacados" value={stats.destacados} icon={Star} />
        <StatsCard label="Ofertas activas" value={stats.ofertas} icon={Percent} />
        <StatsCard label="Reglas de precios activas" value={stats.reglasActivas} icon={Zap} />
        <StatsCard label="Pedidos pendientes" value={stats.pedidosPendientes} icon={ShoppingBag} tone="warning" />
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        {/* Stock por categoría */}
        <div className="rounded-xl2 border border-adminBorder bg-white p-6 shadow-card lg:col-span-3">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-semibold text-carbon">
              Stock por categoría
            </h2>
            <Link
              href="/admin/categorias"
              className="flex items-center gap-1 text-xs font-medium text-borgona hover:underline"
            >
              Ver categorías <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
          <ul className="mt-5 space-y-3">
            {stats.stockPorCategoria.map(({ category, count }) => (
              <li key={category.id} className="flex items-center gap-3">
                <span className="w-28 shrink-0 truncate text-sm text-carbon/70">
                  {category.name}
                </span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-adminBg">
                  <div
                    className="h-full rounded-full bg-borgona"
                    style={{ width: `${(count / maxCategoryCount) * 100}%` }}
                  />
                </div>
                <span className="w-8 shrink-0 text-right text-sm font-medium text-carbon">
                  {count}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Actividad reciente */}
        <div className="rounded-xl2 border border-adminBorder bg-white p-6 shadow-card lg:col-span-2">
          <h2 className="font-display text-base font-semibold text-carbon">Actividad reciente</h2>
          {activity.length === 0 ? (
            <p className="mt-8 text-center text-sm text-adminMuted">
              Todavía no hiciste cambios en esta sesión. Creá, editá o eliminá un producto para
              verlo reflejado acá.
            </p>
          ) : (
            <ul className="mt-4 space-y-4">
              {activity.map((entry) => (
                <li key={entry.id} className="flex gap-3">
                  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-adminBg text-adminMuted">
                    <Clock className="h-3.5 w-3.5" />
                  </span>
                  <div>
                    <p className="text-sm text-carbon/80">{entry.message}</p>
                    <p className="text-xs text-adminMuted">{timeAgo(entry.date)}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Sin stock */}
      {stats.sinStockList.length > 0 && (
        <div className="rounded-xl2 border border-adminBorder bg-white p-6 shadow-card">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-semibold text-carbon">
              Productos sin stock
            </h2>
            <Link
              href="/admin/productos?estado=sin_stock"
              className="flex items-center gap-1 text-xs font-medium text-borgona hover:underline"
            >
              Ver todos <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
          <ul className="mt-4 divide-y divide-adminBorder">
            {stats.sinStockList.map((p) => (
              <li key={p.id} className="flex items-center justify-between py-3 text-sm">
                <span className="text-carbon/80">{p.name}</span>
                <Link
                  href={`/admin/productos/${p.id}/editar`}
                  className="font-medium text-borgona hover:underline"
                >
                  Reponer stock
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
