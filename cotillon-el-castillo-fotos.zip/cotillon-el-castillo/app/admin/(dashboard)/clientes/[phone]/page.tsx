import Link from "next/link";
import { Metadata } from "next";
import { notFound } from "next/navigation";
import { ChevronLeft, Phone } from "lucide-react";
import { getCustomerOrders, getCustomers } from "@/lib/mock-service";
import { formatPrice } from "@/lib/utils";
import { OrdersTable } from "@/components/admin/OrdersTable";

export const metadata: Metadata = { title: "Cliente | Admin | Cotillón El Castillo" };

export default async function AdminClienteDetailPage({ params }: { params: { phone: string } }) {
  const phone = decodeURIComponent(params.phone);
  const [orders, customers] = await Promise.all([getCustomerOrders(phone), getCustomers()]);
  const customer = customers.find((c) => c.phone === phone);
  if (!customer) notFound();

  return (
    <div className="space-y-6">
      <div>
        <Link href="/admin/clientes" className="mb-2 flex items-center gap-1 text-sm text-adminMuted hover:text-borgona">
          <ChevronLeft className="h-4 w-4" /> Volver a clientes
        </Link>
        <h1 className="font-display text-2xl font-semibold text-carbon">{customer.name}</h1>
        <p className="mt-1 flex items-center gap-1.5 text-sm text-adminMuted">
          <Phone className="h-3.5 w-3.5" /> {customer.phone}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        <div className="rounded-xl2 border border-adminBorder bg-white p-4">
          <p className="text-xs uppercase tracking-wide text-adminMuted">Pedidos</p>
          <p className="mt-1 font-display text-xl font-semibold text-carbon">{customer.orderCount}</p>
        </div>
        <div className="rounded-xl2 border border-adminBorder bg-white p-4">
          <p className="text-xs uppercase tracking-wide text-adminMuted">Total gastado</p>
          <p className="mt-1 font-display text-xl font-semibold text-carbon">{formatPrice(customer.totalSpent)}</p>
        </div>
        <div className="rounded-xl2 border border-adminBorder bg-white p-4">
          <p className="text-xs uppercase tracking-wide text-adminMuted">Primer pedido</p>
          <p className="mt-1 font-display text-xl font-semibold text-carbon">
            {new Date(customer.firstOrderAt).toLocaleDateString("es-AR")}
          </p>
        </div>
      </div>

      <OrdersTable orders={orders} />
    </div>
  );
}
