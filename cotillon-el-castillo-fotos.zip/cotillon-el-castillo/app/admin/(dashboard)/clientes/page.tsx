import Link from "next/link";
import { Metadata } from "next";
import { Users, Eye } from "lucide-react";
import { getCustomers } from "@/lib/mock-service";
import { formatPrice } from "@/lib/utils";

export const metadata: Metadata = { title: "Clientes | Admin | Cotillón El Castillo" };

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("es-AR");
}

export default async function AdminClientesPage() {
  const customers = await getCustomers();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Clientes</h1>
        <p className="mt-1 text-sm text-adminMuted">
          {customers.length} cliente{customers.length === 1 ? "" : "s"} — se arman automáticamente a partir de
          los pedidos recibidos, agrupados por teléfono.
        </p>
      </div>

      {customers.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-xl2 border border-dashed border-adminBorder bg-white px-6 py-20 text-center">
          <Users className="h-8 w-8 text-adminMuted" />
          <p className="text-sm text-adminMuted">Todavía no hay clientes — van a aparecer con el primer pedido.</p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl2 border border-adminBorder bg-white shadow-card">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-adminBorder bg-adminBg/60 text-xs uppercase tracking-wide text-adminMuted">
                <tr>
                  <th className="px-5 py-3 font-medium">Cliente</th>
                  <th className="px-5 py-3 font-medium">Pedidos</th>
                  <th className="px-5 py-3 font-medium">Total gastado</th>
                  <th className="px-5 py-3 font-medium">Último pedido</th>
                  <th className="px-5 py-3 font-medium text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-adminBorder">
                {customers.map((c) => (
                  <tr key={c.phone}>
                    <td className="px-5 py-3">
                      <p className="font-medium text-carbon">{c.name}</p>
                      <p className="text-xs text-adminMuted">{c.phone}</p>
                    </td>
                    <td className="px-5 py-3 text-carbon">{c.orderCount}</td>
                    <td className="px-5 py-3 font-medium text-carbon">{formatPrice(c.totalSpent)}</td>
                    <td className="px-5 py-3 text-adminMuted">{formatDate(c.lastOrderAt)}</td>
                    <td className="px-5 py-3 text-right">
                      <Link
                        href={`/admin/clientes/${encodeURIComponent(c.phone)}`}
                        className="inline-flex items-center gap-1.5 rounded-full border border-adminBorder px-3 py-1.5 text-xs font-medium text-carbon hover:bg-adminBg"
                      >
                        <Eye className="h-3.5 w-3.5" /> Ver pedidos
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
