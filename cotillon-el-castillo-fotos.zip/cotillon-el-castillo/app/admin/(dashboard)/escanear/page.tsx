import { Metadata } from "next";
import { getProducts } from "@/lib/mock-service";
import { AdminScannerClient } from "@/components/admin/AdminScannerClient";

export const metadata: Metadata = { title: "Escanear código | Admin | Cotillón El Castillo" };

export default async function AdminEscanearPage() {
  const products = await getProducts();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Escanear código</h1>
        <p className="mt-1 text-sm text-adminMuted">
          Buscá un producto por su código de barras para editarlo o crear uno nuevo.
        </p>
      </div>
      <AdminScannerClient products={products} />
    </div>
  );
}
