import { Metadata } from "next";
import { notFound } from "next/navigation";
import { getAdminUsers } from "@/lib/mock-service";
import { getCurrentAdminUser } from "@/lib/admin-current-user";
import { UsersManager } from "@/components/admin/UsersManager";

export const metadata: Metadata = { title: "Usuarios | Admin | Cotillón El Castillo" };

export default async function AdminUsuariosPage() {
  const currentUser = await getCurrentAdminUser();
  if (currentUser?.role !== "admin") notFound();

  const users = await getAdminUsers();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Usuarios</h1>
        <p className="mt-1 text-sm text-adminMuted">
          {users.length} usuario{users.length === 1 ? "" : "s"} con acceso al panel.
        </p>
      </div>
      <UsersManager users={users} currentUserId={currentUser.userId} />
    </div>
  );
}
