import { Metadata } from "next";
import { notFound } from "next/navigation";
import { getSiteSettings } from "@/lib/mock-service";
import { getCurrentAdminUser } from "@/lib/admin-current-user";
import { SettingsForm } from "@/components/admin/SettingsForm";

export const metadata: Metadata = { title: "Ajustes | Admin | Cotillón El Castillo" };

export default async function AdminAjustesPage() {
  const user = await getCurrentAdminUser();
  if (user?.role !== "admin") notFound();

  const settings = await getSiteSettings();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Ajustes</h1>
        <p className="mt-1 text-sm text-adminMuted">Datos generales del negocio.</p>
      </div>
      <SettingsForm settings={settings} />
    </div>
  );
}
