import { Metadata } from "next";
import { getBranches } from "@/lib/mock-service";
import { BranchesManager } from "@/components/admin/BranchesManager";

export const metadata: Metadata = { title: "Sucursales | Admin | Cotillón El Castillo" };

export default async function AdminSucursalesPage() {
  const branches = await getBranches();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Sucursales</h1>
        <p className="mt-1 text-sm text-adminMuted">
          {branches.length} sucursal{branches.length === 1 ? "" : "es"} cargada{branches.length === 1 ? "" : "s"}.
        </p>
      </div>
      <BranchesManager branches={branches} />
    </div>
  );
}
