import { Metadata } from "next";
import { getCategories, productCountByCategory } from "@/lib/mock-service";
import { CategoriesManager } from "@/components/admin/CategoriesManager";

export const metadata: Metadata = { title: "Categorías | Admin | Cotillón El Castillo" };

export default async function AdminCategoriasPage() {
  const rawCategories = await getCategories();
  const categories = await Promise.all(
    rawCategories.map(async (c) => ({ ...c, productCount: await productCountByCategory(c.id) }))
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Categorías</h1>
        <p className="mt-1 text-sm text-adminMuted">{categories.length} categorías creadas.</p>
      </div>
      <CategoriesManager categories={categories} />
    </div>
  );
}
