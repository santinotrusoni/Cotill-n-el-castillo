import Link from "next/link";
import { Metadata } from "next";
import { Percent } from "lucide-react";
import { getOfferProducts, getCategories } from "@/lib/mock-service";
import { formatPrice } from "@/lib/utils";
import { ProductsTableRow } from "@/components/admin/ProductsTableRow";

export const metadata: Metadata = { title: "Ofertas | Admin | Cotillón El Castillo" };

export default async function AdminOfertasPage() {
  const [offers, categories] = await Promise.all([getOfferProducts(), getCategories()]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Ofertas</h1>
        <p className="mt-1 text-sm text-adminMuted">
          {offers.length} producto{offers.length === 1 ? "" : "s"} marcado
          {offers.length === 1 ? "" : "s"} como oferta. Para agregar o quitar una oferta, editá el
          producto y tildá "Marcar como oferta".
        </p>
      </div>

      {offers.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-xl2 border border-dashed border-adminBorder bg-white px-6 py-20 text-center">
          <Percent className="h-8 w-8 text-adminMuted" />
          <p className="text-sm text-adminMuted">Todavía no hay productos marcados como oferta.</p>
          <Link href="/admin/productos" className="text-sm font-medium text-borgona hover:underline">
            Ir a Productos
          </Link>
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl2 border border-adminBorder bg-white shadow-card">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-adminBorder bg-adminBg/60 text-xs uppercase tracking-wide text-adminMuted">
                <tr>
                  <th className="px-5 py-3 font-medium">Producto</th>
                  <th className="px-5 py-3 font-medium">Categoría</th>
                  <th className="px-5 py-3 font-medium">Precio</th>
                  <th className="px-5 py-3 font-medium">Stock</th>
                  <th className="px-5 py-3 font-medium">Estado</th>
                  <th className="px-5 py-3 font-medium text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-adminBorder">
                {offers.map((product) => (
                  <ProductsTableRow
                    key={product.id}
                    product={product}
                    categoryName={categories.find((c) => c.id === product.categoryId)?.name ?? "—"}
                    formattedPrice={formatPrice(product.price)}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
