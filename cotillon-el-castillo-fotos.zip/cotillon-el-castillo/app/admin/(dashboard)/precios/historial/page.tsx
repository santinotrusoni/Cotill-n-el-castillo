import { Metadata } from "next";
import { getPriceHistory, getProducts } from "@/lib/mock-service";
import { PreciosTabs } from "@/components/admin/PreciosTabs";
import { PriceHistoryList } from "@/components/admin/PriceHistoryList";

export const metadata: Metadata = { title: "Historial de precios | Admin | Cotillón El Castillo" };

export default async function AdminPreciosHistorialPage() {
  const [history, products] = await Promise.all([getPriceHistory(), getProducts()]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Historial de precios</h1>
        <p className="mt-1 text-sm text-adminMuted">
          {history.length} actualización{history.length === 1 ? "" : "es"} registrada
          {history.length === 1 ? "" : "s"}. Cada una se puede revertir por completo.
        </p>
      </div>
      <PreciosTabs />
      <PriceHistoryList history={history} products={products} />
    </div>
  );
}
