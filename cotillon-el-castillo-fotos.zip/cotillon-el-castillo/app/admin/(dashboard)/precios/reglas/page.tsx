import { Metadata } from "next";
import { getPriceRules, getCategories, getBrands } from "@/lib/mock-service";
import { PreciosTabs } from "@/components/admin/PreciosTabs";
import { PriceRulesManager } from "@/components/admin/PriceRulesManager";

export const metadata: Metadata = { title: "Reglas de precios | Admin | Cotillón El Castillo" };

export default async function AdminPreciosReglasPage() {
  const [rules, categories, brands] = await Promise.all([getPriceRules(), getCategories(), getBrands()]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Reglas automáticas</h1>
        <p className="mt-1 text-sm text-adminMuted">
          {rules.length} regla{rules.length === 1 ? "" : "s"} configurada{rules.length === 1 ? "" : "s"} para
          aplicar ajustes de precio con un clic, sin repetir el wizard.
        </p>
      </div>
      <PreciosTabs />
      <PriceRulesManager rules={rules} categories={categories} brands={brands} />
    </div>
  );
}
