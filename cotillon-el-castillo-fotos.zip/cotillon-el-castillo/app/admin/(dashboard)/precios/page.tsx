import { Metadata } from "next";
import { getProducts, getCategories, getBrands } from "@/lib/mock-service";
import { PreciosTabs } from "@/components/admin/PreciosTabs";
import { PriceUpdateWizard } from "@/components/admin/PriceUpdateWizard";

export const metadata: Metadata = { title: "Actualización de precios | Admin | Cotillón El Castillo" };

export default async function AdminPreciosPage() {
  const [products, categories, brands] = await Promise.all([getProducts(), getCategories(), getBrands()]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-carbon">Actualización de precios</h1>
        <p className="mt-1 text-sm text-adminMuted">
          Actualizá los precios de tus productos de forma masiva y automática.
        </p>
      </div>
      <PreciosTabs />
      <PriceUpdateWizard products={products} categories={categories} brands={brands} />
    </div>
  );
}
