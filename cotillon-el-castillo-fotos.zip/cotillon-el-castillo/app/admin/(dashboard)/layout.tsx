import { redirect } from "next/navigation";
import { AdminShell } from "@/components/admin/AdminShell";
import { getCurrentAdminUser } from "@/lib/admin-current-user";

// Mismo motivo que en el layout de la tienda: el admin necesita ver
// siempre el dato más reciente de Supabase, nunca una versión cacheada.
export const dynamic = "force-dynamic";

export default async function AdminDashboardLayout({ children }: { children: React.ReactNode }) {
  // El middleware ya filtra esto, pero una segunda verificación acá no
  // cuesta nada y evita un crash si por algún motivo llega sin sesión.
  const user = await getCurrentAdminUser();
  if (!user) redirect("/admin/login");

  return <AdminShell user={user}>{children}</AdminShell>;
}
