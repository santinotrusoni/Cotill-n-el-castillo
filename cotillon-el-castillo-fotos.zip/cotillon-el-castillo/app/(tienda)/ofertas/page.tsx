import { Suspense } from "react";
import { Metadata } from "next";
import { getOfferProducts, getCategories, getBrands } from "@/lib/mock-service";
import { CatalogClient } from "@/components/product/CatalogClient";

export const metadata: Metadata = {
  title: "Ofertas | Cotillón El Castillo",
  description: "Ofertas imperdibles en cotillón, decoración y descartables.",
};

export default async function OfertasPage() {
  const [products, categories, brands] = await Promise.all([getOfferProducts(), getCategories(), getBrands()]);

  return (
    <Suspense fallback={<div className="mx-auto max-w-7xl px-4 py-16 text-center text-carbon/50">Cargando ofertas...</div>}>
      <CatalogClient products={products} categories={categories} brands={brands} />
    </Suspense>
  );
}
