import { Metadata } from "next";
import { ContactForm, ContactInfo } from "@/components/contact/ContactForm";
import { getSiteSettings } from "@/lib/mock-service";

export const metadata: Metadata = {
  title: "Contacto | Cotillón El Castillo",
  description: "Escribinos por consultas de productos, stock o pedidos grandes para tu evento en Villa Dominico.",
};

export default async function ContactoPage() {
  const settings = await getSiteSettings();

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
      <div className="mb-8 max-w-2xl">
        <h1 className="font-display text-3xl font-semibold text-carbon sm:text-4xl">Hablemos de tu evento</h1>
        <p className="mt-2 text-carbon/60">
          ¿Tenés dudas sobre un producto, necesitás una cantidad grande o querés coordinar un retiro?
          Escribinos y te respondemos a la brevedad.
        </p>
      </div>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1.4fr_1fr]">
        <ContactForm />
        <ContactInfo settings={settings} />
      </div>
    </div>
  );
}
