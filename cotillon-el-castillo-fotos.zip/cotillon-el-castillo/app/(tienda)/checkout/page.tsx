import Link from "next/link";
import { Metadata } from "next";
import { CheckoutForm } from "@/components/checkout/CheckoutForm";
import { getCurrentCustomer } from "@/lib/customer-current";

export const metadata: Metadata = { title: "Finalizar pedido | Cotillón El Castillo" };

export default async function CheckoutPage() {
  const account = await getCurrentCustomer();

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="mb-2 font-display text-3xl font-semibold text-carbon">Finalizar pedido</h1>
      {!account && (
        <p className="mb-6 text-sm text-carbon/60">
          ¿Ya tenés cuenta?{" "}
          <Link href="/ingresar?next=/checkout" className="font-medium text-rosa hover:underline">Ingresá</Link>{" "}
          o{" "}
          <Link href="/registrarse?next=/checkout" className="font-medium text-rosa hover:underline">creá una</Link>{" "}
          para guardar tus datos y seguir tus pedidos. También podés comprar sin cuenta.
        </p>
      )}
      <CheckoutForm initialName={account?.name} initialPhone={account?.phone} />
    </div>
  );
}
