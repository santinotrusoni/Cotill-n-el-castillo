import Link from "next/link";
import Image from "next/image";
import { Metadata } from "next";
import { getCategories, getProducts } from "@/lib/mock-service";

export const metadata: Metadata = {
  title: "Categorías | Cotillón El Castillo",
};

export default async function CategoriasPage() {
  const [categories, products] = await Promise.all([getCategories(), getProducts()]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="mb-6 font-display text-3xl font-semibold text-carbon">Categorías</h1>
      <div className="grid grid-cols-2 gap-4 sm:gap-5 md:grid-cols-3 lg:grid-cols-5">
        {categories.map((cat) => {
          const count = products.filter((p) => p.categoryId === cat.id).length;
          return (
            <Link
              key={cat.id}
              href={`/productos?categoria=${cat.slug}`}
              className="group overflow-hidden rounded-xl2 bg-white shadow-card transition-shadow hover:shadow-cardHover"
            >
              <div className="relative aspect-square overflow-hidden bg-crema">
                <Image
                  src={cat.image}
                  alt={cat.name}
                  fill
                  sizes="(max-width: 768px) 50vw, 20vw"
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
              </div>
              <div className="p-3">
                <h2 className="font-medium text-carbon">{cat.name}</h2>
                <p className="text-xs text-carbon/50">{count} productos</p>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
