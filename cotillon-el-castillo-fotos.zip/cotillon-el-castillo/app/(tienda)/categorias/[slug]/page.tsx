import { redirect, notFound } from "next/navigation";
import { getCategoryBySlug } from "@/lib/mock-service";

export default async function CategoriaSlugPage({ params }: { params: { slug: string } }) {
  const category = await getCategoryBySlug(params.slug);
  if (!category) notFound();
  redirect(`/productos?categoria=${category.slug}`);
}
