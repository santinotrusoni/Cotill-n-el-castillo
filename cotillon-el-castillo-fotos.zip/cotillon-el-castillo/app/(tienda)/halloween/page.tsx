import Link from "next/link";
import { Metadata } from "next";
import { ArrowDown, Ghost, PackageSearch } from "lucide-react";
import { getHalloweenProducts } from "@/lib/mock-service";
import { ProductCard } from "@/components/product/ProductCard";
import { HalloweenVideo } from "@/components/halloween/HalloweenVideo";

export const metadata: Metadata = {
  title: "Halloween | Cotillón El Castillo",
  description:
    "Disfraces, decoración, globos y descartables para tu fiesta de Halloween. Cotillón El Castillo, Villa Dominico.",
};

const HALLOWEEN_CATEGORY = "/productos?categoria=halloween";

const QUICK_LINKS = [
  { label: "Decoración", href: "/productos?categoria=decoracion" },
  { label: "Globos", href: "/productos?categoria=globos" },
  { label: "Descartables", href: "/productos?categoria=descartables" },
  { label: "Cotillón", href: "/productos?categoria=cotillon" },
];

export default async function HalloweenPage() {
  const products = await getHalloweenProducts();

  return (
    <div className="bg-halloween-night text-white">
      {/* Hero con video */}
      <section className="relative flex min-h-[70vh] items-center overflow-hidden">
        <HalloweenVideo />
        <div className="absolute inset-0 bg-gradient-to-r from-halloween-night/90 via-halloween-night/50 to-halloween-night/10" />
        <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-halloween-night to-transparent" />

        <div className="relative mx-auto w-full max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <span className="mb-4 inline-flex items-center gap-1.5 rounded-full bg-halloween-orange/15 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-halloween-ember">
            <Ghost className="h-3.5 w-3.5" aria-hidden /> Temporada de Halloween
          </span>
          <h1 className="max-w-2xl font-display text-4xl font-semibold leading-[1.1] sm:text-5xl lg:text-6xl">
            Una noche de brujas
            <br />
            <span className="italic text-halloween-orange">para no olvidar.</span>
          </h1>
          <p className="mt-5 max-w-md text-base text-white/75 sm:text-lg">
            Disfraces, decoración, globos y descartables para armar la fiesta de terror más divertida.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#productos"
              className="inline-flex items-center gap-2 rounded-full bg-halloween-orange px-6 py-3 text-sm font-semibold text-halloween-night transition-colors hover:bg-halloween-ember"
            >
              Ver productos <ArrowDown className="h-4 w-4" aria-hidden />
            </a>
            <Link
              href={HALLOWEEN_CATEGORY}
              className="rounded-full border border-halloween-purple/60 bg-halloween-purple/20 px-6 py-3 text-sm font-medium text-white transition-colors hover:bg-halloween-purple/40"
            >
              Ver categoría Halloween
            </Link>
          </div>
        </div>
      </section>

      {/* Accesos rápidos por categoría */}
      <section className="mx-auto max-w-7xl px-4 pt-6 sm:px-6 lg:px-8">
        <div className="flex flex-wrap gap-2">
          {QUICK_LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="rounded-full border border-white/15 bg-halloween-plum px-4 py-2 text-sm text-white/80 transition-colors hover:border-halloween-orange hover:text-halloween-orange"
            >
              {l.label}
            </Link>
          ))}
        </div>
      </section>

      {/* Productos */}
      <section id="productos" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-12 sm:px-6 lg:px-8">
        <div className="mb-6">
          <span className="text-xs font-semibold uppercase tracking-wide text-halloween-ember">Colección</span>
          <h2 className="font-display text-2xl font-semibold sm:text-3xl">Todo para Halloween</h2>
          {products.length > 0 && (
            <p className="mt-1 text-sm text-white/50">{products.length} productos</p>
          )}
        </div>

        {products.length === 0 ? (
          <div className="flex flex-col items-center gap-3 rounded-xl2 border border-white/10 bg-halloween-plum py-16 text-center">
            <PackageSearch className="h-10 w-10 text-halloween-purple" aria-hidden />
            <p className="font-medium">Estamos preparando la colección de Halloween.</p>
            <p className="max-w-sm text-sm text-white/60">
              Muy pronto vas a encontrar todo acá.
            </p>
            <Link
              href={HALLOWEEN_CATEGORY}
              className="mt-2 rounded-full bg-halloween-orange px-5 py-2.5 text-sm font-semibold text-halloween-night hover:bg-halloween-ember"
            >
              Ver categoría Halloween
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:gap-5 md:grid-cols-3 lg:grid-cols-4">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
