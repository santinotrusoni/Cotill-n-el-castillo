import { Suspense } from "react";
import { Metadata } from "next";
import { getFeaturedProducts, getCategories, getBrands } from "@/lib/mock-service";
import { CatalogClient } from "@/components/product/CatalogClient";

export const metadata: Metadata = {
  title: "Destacados | Cotillón El Castillo",
  description: "Los productos más elegidos de Cotillón El Castillo.",
};

export default async function DestacadosPage() {
  const [products, categories, brands] = await Promise.all([getFeaturedProducts(), getCategories(), getBrands()]);

  return (
    <Suspense fallback={<div className="mx-auto max-w-7xl px-4 py-16 text-center text-carbon/50">Cargando destacados...</div>}>
      <CatalogClient products={products} categories={categories} brands={brands} />
    </Suspense>
  );
}
