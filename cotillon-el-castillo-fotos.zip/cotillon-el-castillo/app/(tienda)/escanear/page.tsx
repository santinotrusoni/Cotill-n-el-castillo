import Link from "next/link";
import { Metadata } from "next";
import { ChevronRight } from "lucide-react";
import { getProducts, getCategories } from "@/lib/mock-service";
import { ScannerClient } from "@/components/scanner/ScannerClient";

export const metadata: Metadata = {
  title: "Escanear código | Cotillón El Castillo",
  description:
    "Escaneá el código de barras de un producto con la cámara de tu teléfono y encontrá precio, stock y detalle al instante.",
};

export default async function EscanearPage() {
  const [products, categories] = await Promise.all([getProducts(), getCategories()]);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <nav aria-label="Breadcrumb" className="mb-6 flex items-center gap-1 text-xs text-carbon/50">
        <Link href="/" className="hover:text-borgona">
          Inicio
        </Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-carbon/70">Escanear código</span>
      </nav>

      <ScannerClient products={products} categories={categories} />
    </div>
  );
}
