import { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/account/AuthForm";
import { getCustomerSession } from "@/lib/customer-current";

export const metadata: Metadata = { title: "Crear cuenta | Cotillón El Castillo" };

export default async function RegistrarsePage({ searchParams }: { searchParams: { next?: string } }) {
  const next = searchParams.next ?? "/cuenta";
  if (await getCustomerSession()) redirect(next.startsWith("/") && !next.startsWith("//") ? next : "/cuenta");

  return (
    <div className="mx-auto max-w-md px-4 py-12 sm:py-16">
      <div className="rounded-xl2 bg-white p-6 shadow-card sm:p-8">
        <h1 className="font-display text-2xl font-semibold text-carbon">Creá tu cuenta</h1>
        <p className="mb-6 mt-1 text-sm text-carbon/60">Guardá tus datos y seguí tus pedidos en un solo lugar.</p>
        <AuthForm mode="register" next={next} />
      </div>
    </div>
  );
}
