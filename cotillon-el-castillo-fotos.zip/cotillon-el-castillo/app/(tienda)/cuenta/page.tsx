import Link from "next/link";
import { Metadata } from "next";
import { redirect } from "next/navigation";
import { LogOut, Mail, Phone, PackageOpen } from "lucide-react";
import { getCurrentCustomer } from "@/lib/customer-current";
import { logoutCustomerAction } from "@/lib/customer-auth-actions";
import { getOrdersByCustomerId } from "@/lib/mock-service";
import { ORDER_STATUS_OPTIONS, ORDER_STATUS_TONE, formatOrderDate } from "@/lib/order-status";
import { formatPrice } from "@/lib/utils";

export const metadata: Metadata = { title: "Mi cuenta | Cotillón El Castillo" };

export default async function CuentaPage() {
  const account = await getCurrentCustomer();
  if (!account) redirect("/ingresar?next=/cuenta");

  const orders = await getOrdersByCustomerId(account.id);
  const statusLabel = Object.fromEntries(ORDER_STATUS_OPTIONS.map((o) => [o.value, o.label]));

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <div className="mb-8 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold text-carbon">Hola, {account.name.split(" ")[0]}</h1>
          <ul className="mt-2 space-y-1 text-sm text-carbon/60">
            <li className="flex items-center gap-2"><Mail className="h-4 w-4" aria-hidden /> {account.email}</li>
            <li className="flex items-center gap-2"><Phone className="h-4 w-4" aria-hidden /> {account.phone}</li>
          </ul>
        </div>
        <form action={logoutCustomerAction}>
          <button
            type="submit"
            className="flex items-center gap-2 rounded-full border border-crema-dark bg-white px-4 py-2 text-sm font-medium text-carbon hover:border-rosa hover:text-rosa"
          >
            <LogOut className="h-4 w-4" aria-hidden /> Cerrar sesión
          </button>
        </form>
      </div>

      <h2 className="mb-4 font-display text-xl font-semibold text-carbon">Mis pedidos</h2>
      {orders.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-xl2 bg-white py-14 text-center shadow-card">
          <PackageOpen className="h-10 w-10 text-carbon/20" aria-hidden />
          <p className="text-sm text-carbon/60">Todavía no hiciste ningún pedido con esta cuenta.</p>
          <Link href="/productos" className="rounded-full bg-rosa px-5 py-2.5 text-sm font-medium text-white hover:bg-rosa-dark">
            Ver productos
          </Link>
        </div>
      ) : (
        <ul className="space-y-3">
          {orders.map((o) => (
            <li key={o.id}>
              <Link
                href={`/pedido/${o.id}`}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl2 bg-white p-4 shadow-card transition-shadow hover:shadow-cardHover"
              >
                <div>
                  <p className="font-medium text-carbon">Pedido #{o.orderNumber}</p>
                  <p className="text-xs text-carbon/50">{formatOrderDate(o.createdAt)}</p>
                </div>
                <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${ORDER_STATUS_TONE[o.status]}`}>
                  {statusLabel[o.status]}
                </span>
                <span className="font-semibold text-carbon">{formatPrice(o.total)}</span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
