import { Metadata } from "next";
import { getSiteSettings } from "@/lib/mock-service";
import { CartPageClient } from "@/components/cart/CartPageClient";

export const metadata: Metadata = { title: "Tu carrito | Cotillón El Castillo" };

export default async function CarritoPage() {
  const settings = await getSiteSettings();
  return <CartPageClient whatsappNumber={settings.whatsappNumber} />;
}
