import { notFound } from "next/navigation";
import Link from "next/link";
import { Metadata } from "next";
import { ChevronRight } from "lucide-react";
import {
  getProductBySlug,
  getRelatedProducts,
  getCategories,
} from "@/lib/mock-service";
import { PriceBadge } from "@/components/product/PriceBadge";
import { StockBadge } from "@/components/product/StockBadge";
import { ProductGallery } from "@/components/product/ProductGallery";
import { ProductDetailActions } from "@/components/product/ProductDetailActions";
import { RelatedProducts } from "@/components/product/RelatedProducts";

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const product = await getProductBySlug(params.slug);
  if (!product) return {};
  return {
    title: `${product.name} | Cotillón El Castillo`,
    description: product.shortDescription,
    openGraph: { title: product.name, description: product.shortDescription },
  };
}

export default async function ProductDetailPage({ params }: { params: { slug: string } }) {
  const product = await getProductBySlug(params.slug);
  if (!product) notFound();

  const [categories, related] = await Promise.all([getCategories(), getRelatedProducts(product)]);
  const category = categories.find((c) => c.id === product.categoryId);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <nav aria-label="Breadcrumb" className="mb-6 flex flex-wrap items-center gap-1 text-xs text-carbon/50">
        <Link href="/" className="hover:text-borgona">Inicio</Link>
        <ChevronRight className="h-3 w-3" />
        <Link href="/productos" className="hover:text-borgona">Productos</Link>
        {category && (
          <>
            <ChevronRight className="h-3 w-3" />
            <Link href={`/productos?categoria=${category.slug}`} className="hover:text-borgona">
              {category.name}
            </Link>
          </>
        )}
        <ChevronRight className="h-3 w-3" />
        <span className="text-carbon/70">{product.name}</span>
      </nav>

      <div className="grid gap-10 lg:grid-cols-2">
        <ProductGallery images={product.images} name={product.name} />

        <div className="flex flex-col gap-4">
          {category && (
            <span className="text-xs font-semibold uppercase tracking-wide text-borgona">{category.name}</span>
          )}
          <h1 className="font-display text-3xl font-semibold text-carbon">{product.name}</h1>

          <PriceBadge price={product.price} previousPrice={product.previousPrice} size="lg" />
          <StockBadge status={product.status} stock={product.stock} />

          <ProductDetailActions product={product} />

          <div className="mt-4 flex flex-wrap gap-x-6 gap-y-1 border-t border-crema-dark pt-4 text-xs text-carbon/50">
            <span>SKU: {product.sku}</span>
            <span>Código de barras: {product.barcode}</span>
          </div>

          <div className="border-t border-crema-dark pt-5">
            <h2 className="mb-2 font-medium text-carbon">Descripción</h2>
            <p className="text-sm leading-relaxed text-carbon/70">{product.description}</p>
          </div>

          {product.attributeValues && product.attributeValues.length > 0 && (
            <div className="border-t border-crema-dark pt-5">
              <h2 className="mb-2 font-medium text-carbon">Especificaciones</h2>
              <dl className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-sm">
                {product.attributeValues.map((av) => (
                  <div key={av.attributeId} className="contents">
                    <dt className="text-carbon/50">{av.attributeName}</dt>
                    <dd className="text-carbon/80">{av.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}

          {product.features.length > 0 && (
            <div className="border-t border-crema-dark pt-5">
              <h2 className="mb-2 font-medium text-carbon">Características</h2>
              <ul className="list-inside list-disc space-y-1 text-sm text-carbon/70">
                {product.features.map((f) => (
                  <li key={f}>{f}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      <RelatedProducts products={related} />
    </div>
  );
}
