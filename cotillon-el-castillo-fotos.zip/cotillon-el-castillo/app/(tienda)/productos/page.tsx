import { Suspense } from "react";
import { Metadata } from "next";
import { getProducts, getCategories, getBrands } from "@/lib/mock-service";
import { CatalogClient } from "@/components/product/CatalogClient";

export const metadata: Metadata = {
  title: "Todos los productos | Cotillón El Castillo",
  description: "Explorá todo el catálogo de cotillón, descartables, repostería y decoración.",
};

export default async function ProductosPage() {
  const [products, categories, brands] = await Promise.all([getProducts(), getCategories(), getBrands()]);

  return (
    <Suspense fallback={<div className="mx-auto max-w-7xl px-4 py-16 text-center text-carbon/50">Cargando productos...</div>}>
      <CatalogClient products={products} categories={categories} brands={brands} />
    </Suspense>
  );
}
