import { Suspense } from "react";
import { Metadata } from "next";
import { getProducts, getCategories, getBrands } from "@/lib/mock-service";
import { CatalogClient } from "@/components/product/CatalogClient";

export const metadata: Metadata = {
  title: "Novedades | Cotillón El Castillo",
};

export default async function NovedadesPage() {
  const [allProducts, categories, brands] = await Promise.all([getProducts(), getCategories(), getBrands()]);
  const products = allProducts.filter((p) => p.isNew).sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  return (
    <Suspense fallback={<div className="mx-auto max-w-7xl px-4 py-16 text-center text-carbon/50">Cargando novedades...</div>}>
      <CatalogClient products={products} categories={categories} brands={brands} />
    </Suspense>
  );
}
