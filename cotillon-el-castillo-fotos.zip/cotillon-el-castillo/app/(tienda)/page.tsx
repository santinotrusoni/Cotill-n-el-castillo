import { Hero } from "@/components/home/Hero";
import { HalloweenBanner } from "@/components/home/HalloweenBanner";
import { Benefits } from "@/components/home/Benefits";
import { FeaturedProducts } from "@/components/home/FeaturedProducts";
import { OffersSection } from "@/components/home/OffersSection";

export default function HomePage() {
  return (
    <>
      <Hero />
      <HalloweenBanner />
      <Benefits />
      <FeaturedProducts />
      <OffersSection />
    </>
  );
}
