import Link from "next/link";
import { notFound } from "next/navigation";
import { CheckCircle2, MessageCircle, Store, Truck } from "lucide-react";
import { getOrderById, getSiteSettings } from "@/lib/mock-service";
import { formatPrice } from "@/lib/utils";

const STATUS_LABELS: Record<string, string> = {
  pendiente: "Pendiente de confirmación",
  confirmado: "Confirmado",
  en_preparacion: "En preparación",
  listo: "Listo para retirar/enviar",
  entregado: "Entregado",
  cancelado: "Cancelado",
};

export default async function PedidoConfirmadoPage({ params }: { params: { id: string } }) {
  const [order, settings] = await Promise.all([getOrderById(params.id), getSiteSettings()]);
  if (!order) notFound();

  const lines = order.items.map(
    (item) => `• ${item.name} x${item.quantity} — ${formatPrice(item.price * item.quantity)}`
  );
  const message = encodeURIComponent(
    `¡Hola! Quiero confirmar mi pedido #${order.orderNumber} en Cotillón El Castillo:\n\n${lines.join("\n")}\n\nTotal: ${formatPrice(
      order.total
    )}\n${order.deliveryMethod === "envio" ? `Envío a: ${order.address}` : "Retiro en el local"}`
  );

  return (
    <div className="mx-auto max-w-2xl px-4 py-14 sm:px-6">
      <div className="flex flex-col items-center gap-3 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-exito/10">
          <CheckCircle2 className="h-7 w-7 text-exito" aria-hidden />
        </div>
        <h1 className="font-display text-2xl font-semibold text-carbon sm:text-3xl">¡Pedido recibido!</h1>
        <p className="text-carbon/60">
          Pedido <span className="font-semibold text-carbon">#{order.orderNumber}</span> —{" "}
          {STATUS_LABELS[order.status] ?? order.status}
        </p>
      </div>

      <div className="mt-8 rounded-xl2 bg-white p-6 shadow-card">
        <h2 className="mb-3 font-display text-lg font-semibold text-carbon">Resumen</h2>
        <ul className="divide-y divide-crema-dark">
          {order.items.map((item) => (
            <li key={item.productId} className="flex justify-between py-2.5 text-sm">
              <span className="text-carbon/80">
                {item.name} <span className="text-carbon/40">x{item.quantity}</span>
              </span>
              <span className="font-medium text-carbon">{formatPrice(item.price * item.quantity)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-2 flex justify-between py-1 text-sm text-carbon/60">
          <span>Subtotal</span>
          <span>{formatPrice(order.subtotal)}</span>
        </div>
        {order.discount > 0 && (
          <div className="flex justify-between py-1 text-sm text-exito">
            <span>Descuento</span>
            <span>-{formatPrice(order.discount)}</span>
          </div>
        )}
        <div className="mt-2 flex justify-between border-t border-crema-dark py-3 font-display text-xl font-semibold text-carbon">
          <span>Total</span>
          <span>{formatPrice(order.total)}</span>
        </div>

        <div className="mt-4 flex items-center gap-2 rounded-lg bg-crema px-4 py-3 text-sm text-carbon/70">
          {order.deliveryMethod === "envio" ? <Truck className="h-4 w-4 shrink-0" /> : <Store className="h-4 w-4 shrink-0" />}
          {order.deliveryMethod === "envio" ? `Envío a: ${order.address}` : "Retiro en el local"}
        </div>
      </div>

      <a
        href={`https://wa.me/${settings.whatsappNumber}?text=${message}`}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-6 flex items-center justify-center gap-2 rounded-full bg-exito py-3 text-sm font-medium text-white hover:bg-exito/90"
      >
        <MessageCircle className="h-4 w-4" />
        Confirmar por WhatsApp
      </a>
      <p className="mt-3 text-center text-xs text-carbon/50">
        Todavía no procesamos pagos online — coordinamos el pago y la entrega por WhatsApp.
      </p>

      <div className="mt-6 text-center">
        <Link href="/productos" className="text-sm font-medium text-borgona hover:underline">
          Seguir comprando
        </Link>
      </div>
    </div>
  );
}
