import type { Metadata } from "next";
import { Fraunces, Inter } from "next/font/google";
import "@/app/globals.css";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CartProvider } from "@/lib/cart-context";
import { CartDrawer } from "@/components/cart/CartDrawer";
import { getProducts, getSiteSettings } from "@/lib/mock-service";
import { getCustomerSession } from "@/lib/customer-current";

// El catálogo vive en Supabase ahora, no en un array en memoria: forzamos
// renderizado dinámico para que un cambio hecho en /admin se vea reflejado
// en la tienda al instante, sin depender del cacheo estático de Next.
export const dynamic = "force-dynamic";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  weight: ["500", "600", "700"],
  style: ["normal", "italic"],
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "Cotillón El Castillo | Todo para tu fiesta en Villa Dominico",
  description:
    "Cotillón, descartables, repostería, decoración y globos para tu fiesta o evento. Envíos y retiro en Villa Dominico, Buenos Aires.",
  openGraph: {
    title: "Cotillón El Castillo",
    description:
      "Todo lo que necesitás para tu fiesta, en un solo lugar. Cotillón, decoración, descartables y más.",
    locale: "es_AR",
    type: "website",
  },
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [products, settings, session] = await Promise.all([getProducts(), getSiteSettings(), getCustomerSession()]);

  return (
    <html lang="es-AR" className={`${fraunces.variable} ${inter.variable}`}>
      <body className="font-sans antialiased flex min-h-screen flex-col">
        <CartProvider products={products}>
          <Header accountName={session?.name ?? null} />
          <main className="flex-1">{children}</main>
          <Footer settings={settings} />
          <CartDrawer />
        </CartProvider>
      </body>
    </html>
  );
}
